package ants;

public abstract interface Surroundings
{
  public abstract Tile getCurrentTile();

  public abstract Tile getTile(Direction paramDirection);
}

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     ants.Surroundings
 * JD-Core Version:    0.6.0
 */