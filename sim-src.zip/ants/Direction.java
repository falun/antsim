/*   */ package ants;
/*   */ 
/*   */ public enum Direction
/*   */ {
/* 9 */   NORTH, EAST, SOUTH, WEST;
/*   */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     ants.Direction
 * JD-Core Version:    0.6.0
 */