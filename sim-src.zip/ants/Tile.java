package ants;

public abstract interface Tile
{
  public abstract int getAmountOfFood();

  public abstract int getNumAnts();

  public abstract boolean isTravelable();
}

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     ants.Tile
 * JD-Core Version:    0.6.0
 */