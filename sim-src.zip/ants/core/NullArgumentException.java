/*   */ package ants.core;
/*   */ 
/*   */ public class NullArgumentException extends RuntimeException
/*   */ {
/*   */   public NullArgumentException(String s)
/*   */   {
/* 6 */     super(s);
/*   */   }
/*   */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     ants.core.NullArgumentException
 * JD-Core Version:    0.6.0
 */