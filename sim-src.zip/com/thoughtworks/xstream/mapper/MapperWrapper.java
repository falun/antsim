/*     */ package com.thoughtworks.xstream.mapper;
/*     */ 
/*     */ import com.thoughtworks.xstream.alias.ClassMapper;
/*     */ import com.thoughtworks.xstream.converters.Converter;
/*     */ import com.thoughtworks.xstream.converters.SingleValueConverter;
/*     */ 
/*     */ public abstract class MapperWrapper
/*     */   implements Mapper
/*     */ {
/*     */   private final Mapper wrapped;
/*     */ 
/*     */   public MapperWrapper(Mapper wrapped)
/*     */   {
/*  23 */     this.wrapped = wrapped;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public MapperWrapper(ClassMapper wrapped)
/*     */   {
/*  30 */     this(wrapped);
/*     */   }
/*     */ 
/*     */   public String serializedClass(Class type) {
/*  34 */     return this.wrapped.serializedClass(type);
/*     */   }
/*     */ 
/*     */   public Class realClass(String elementName) {
/*  38 */     return this.wrapped.realClass(elementName);
/*     */   }
/*     */ 
/*     */   public String serializedMember(Class type, String memberName) {
/*  42 */     return this.wrapped.serializedMember(type, memberName);
/*     */   }
/*     */ 
/*     */   public String realMember(Class type, String serialized) {
/*  46 */     return this.wrapped.realMember(type, serialized);
/*     */   }
/*     */ 
/*     */   public boolean isImmutableValueType(Class type) {
/*  50 */     return this.wrapped.isImmutableValueType(type);
/*     */   }
/*     */ 
/*     */   public Class defaultImplementationOf(Class type) {
/*  54 */     return this.wrapped.defaultImplementationOf(type);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public String attributeForClassDefiningField()
/*     */   {
/*  61 */     return this.wrapped.attributeForClassDefiningField();
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public String attributeForImplementationClass()
/*     */   {
/*  68 */     return this.wrapped.attributeForImplementationClass();
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public String attributeForReadResolveField()
/*     */   {
/*  75 */     return this.wrapped.attributeForReadResolveField();
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public String attributeForEnumType()
/*     */   {
/*  82 */     return this.wrapped.attributeForEnumType();
/*     */   }
/*     */ 
/*     */   public String aliasForAttribute(String attribute) {
/*  86 */     return this.wrapped.aliasForAttribute(attribute);
/*     */   }
/*     */ 
/*     */   public String attributeForAlias(String alias) {
/*  90 */     return this.wrapped.attributeForAlias(alias);
/*     */   }
/*     */ 
/*     */   public String aliasForSystemAttribute(String attribute) {
/*  94 */     return this.wrapped.aliasForSystemAttribute(attribute);
/*     */   }
/*     */ 
/*     */   public String getFieldNameForItemTypeAndName(Class definedIn, Class itemType, String itemFieldName) {
/*  98 */     return this.wrapped.getFieldNameForItemTypeAndName(definedIn, itemType, itemFieldName);
/*     */   }
/*     */ 
/*     */   public Class getItemTypeForItemFieldName(Class definedIn, String itemFieldName) {
/* 102 */     return this.wrapped.getItemTypeForItemFieldName(definedIn, itemFieldName);
/*     */   }
/*     */ 
/*     */   public Mapper.ImplicitCollectionMapping getImplicitCollectionDefForFieldName(Class itemType, String fieldName) {
/* 106 */     return this.wrapped.getImplicitCollectionDefForFieldName(itemType, fieldName);
/*     */   }
/*     */ 
/*     */   public boolean shouldSerializeMember(Class definedIn, String fieldName) {
/* 110 */     return this.wrapped.shouldSerializeMember(definedIn, fieldName);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public SingleValueConverter getConverterFromItemType(String fieldName, Class type)
/*     */   {
/* 117 */     return this.wrapped.getConverterFromItemType(fieldName, type);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public SingleValueConverter getConverterFromItemType(Class type)
/*     */   {
/* 124 */     return this.wrapped.getConverterFromItemType(type);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public SingleValueConverter getConverterFromAttribute(String name)
/*     */   {
/* 131 */     return this.wrapped.getConverterFromAttribute(name);
/*     */   }
/*     */ 
/*     */   public Converter getLocalConverter(Class definedIn, String fieldName) {
/* 135 */     return this.wrapped.getLocalConverter(definedIn, fieldName);
/*     */   }
/*     */ 
/*     */   public Mapper lookupMapperOfType(Class type) {
/* 139 */     return type.isAssignableFrom(getClass()) ? this : this.wrapped.lookupMapperOfType(type);
/*     */   }
/*     */ 
/*     */   public SingleValueConverter getConverterFromItemType(String fieldName, Class type, Class definedIn) {
/* 143 */     return this.wrapped.getConverterFromItemType(fieldName, type, definedIn);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public String aliasForAttribute(Class definedIn, String fieldName)
/*     */   {
/* 150 */     return this.wrapped.aliasForAttribute(definedIn, fieldName);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public String attributeForAlias(Class definedIn, String alias)
/*     */   {
/* 157 */     return this.wrapped.attributeForAlias(definedIn, alias);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public SingleValueConverter getConverterFromAttribute(Class type, String attribute)
/*     */   {
/* 164 */     return this.wrapped.getConverterFromAttribute(type, attribute);
/*     */   }
/*     */ 
/*     */   public SingleValueConverter getConverterFromAttribute(Class definedIn, String attribute, Class type) {
/* 168 */     return this.wrapped.getConverterFromAttribute(definedIn, attribute, type);
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.mapper.MapperWrapper
 * JD-Core Version:    0.6.0
 */