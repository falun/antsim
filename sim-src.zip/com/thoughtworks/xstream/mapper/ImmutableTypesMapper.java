/*    */ package com.thoughtworks.xstream.mapper;
/*    */ 
/*    */ import com.thoughtworks.xstream.alias.ClassMapper;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class ImmutableTypesMapper extends MapperWrapper
/*    */ {
/* 27 */   private final Set immutableTypes = new HashSet();
/*    */ 
/*    */   public ImmutableTypesMapper(Mapper wrapped) {
/* 30 */     super(wrapped);
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public ImmutableTypesMapper(ClassMapper wrapped)
/*    */   {
/* 37 */     this(wrapped);
/*    */   }
/*    */ 
/*    */   public void addImmutableType(Class type) {
/* 41 */     this.immutableTypes.add(type);
/*    */   }
/*    */ 
/*    */   public boolean isImmutableValueType(Class type) {
/* 45 */     if (this.immutableTypes.contains(type)) {
/* 46 */       return true;
/*    */     }
/* 48 */     return super.isImmutableValueType(type);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.mapper.ImmutableTypesMapper
 * JD-Core Version:    0.6.0
 */