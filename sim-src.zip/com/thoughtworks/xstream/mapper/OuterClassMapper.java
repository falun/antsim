/*    */ package com.thoughtworks.xstream.mapper;
/*    */ 
/*    */ import com.thoughtworks.xstream.alias.ClassMapper;
/*    */ 
/*    */ public class OuterClassMapper extends MapperWrapper
/*    */ {
/*    */   private final String alias;
/*    */ 
/*    */   public OuterClassMapper(Mapper wrapped)
/*    */   {
/* 26 */     this(wrapped, "outer-class");
/*    */   }
/*    */ 
/*    */   public OuterClassMapper(Mapper wrapped, String alias) {
/* 30 */     super(wrapped);
/* 31 */     this.alias = alias;
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public OuterClassMapper(ClassMapper wrapped)
/*    */   {
/* 38 */     this(wrapped);
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public OuterClassMapper(ClassMapper wrapped, String alias)
/*    */   {
/* 45 */     this(wrapped, alias);
/*    */   }
/*    */ 
/*    */   public String serializedMember(Class type, String memberName) {
/* 49 */     if (memberName.equals("this$0")) {
/* 50 */       return this.alias;
/*    */     }
/* 52 */     return super.serializedMember(type, memberName);
/*    */   }
/*    */ 
/*    */   public String realMember(Class type, String serialized)
/*    */   {
/* 57 */     if (serialized.equals(this.alias)) {
/* 58 */       return "this$0";
/*    */     }
/* 60 */     return super.realMember(type, serialized);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.mapper.OuterClassMapper
 * JD-Core Version:    0.6.0
 */