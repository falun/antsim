/*    */ package com.thoughtworks.xstream.mapper;
/*    */ 
/*    */ public class XStream11XmlFriendlyMapper extends AbstractXmlFriendlyMapper
/*    */ {
/*    */   public XStream11XmlFriendlyMapper(Mapper wrapped)
/*    */   {
/* 30 */     super(wrapped);
/*    */   }
/*    */ 
/*    */   public Class realClass(String elementName) {
/* 34 */     return super.realClass(unescapeClassName(elementName));
/*    */   }
/*    */ 
/*    */   public String realMember(Class type, String serialized) {
/* 38 */     return unescapeFieldName(super.realMember(type, serialized));
/*    */   }
/*    */ 
/*    */   public String mapNameFromXML(String xmlName) {
/* 42 */     return unescapeFieldName(xmlName);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.mapper.XStream11XmlFriendlyMapper
 * JD-Core Version:    0.6.0
 */