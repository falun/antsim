/*     */ package com.thoughtworks.xstream.mapper;
/*     */ 
/*     */ import com.thoughtworks.xstream.converters.Converter;
/*     */ import com.thoughtworks.xstream.converters.ConverterLookup;
/*     */ import com.thoughtworks.xstream.converters.SingleValueConverter;
/*     */ import com.thoughtworks.xstream.core.util.Fields;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class AttributeMapper extends MapperWrapper
/*     */ {
/*  39 */   private final Map fieldNameToTypeMap = new HashMap();
/*  40 */   private final Set typeSet = new HashSet();
/*     */   private ConverterLookup converterLookup;
/*  42 */   private final Set fieldToUseAsAttribute = new HashSet();
/*     */ 
/*     */   /** @deprecated */
/*     */   public AttributeMapper(Mapper wrapped)
/*     */   {
/*  48 */     this(wrapped, null);
/*     */   }
/*     */ 
/*     */   public AttributeMapper(Mapper wrapped, ConverterLookup converterLookup) {
/*  52 */     super(wrapped);
/*  53 */     this.converterLookup = converterLookup;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public void setConverterLookup(ConverterLookup converterLookup)
/*     */   {
/*  60 */     this.converterLookup = converterLookup;
/*     */   }
/*     */ 
/*     */   public void addAttributeFor(String fieldName, Class type) {
/*  64 */     this.fieldNameToTypeMap.put(fieldName, type);
/*     */   }
/*     */ 
/*     */   public void addAttributeFor(Class type) {
/*  68 */     this.typeSet.add(type);
/*     */   }
/*     */ 
/*     */   private SingleValueConverter getLocalConverterFromItemType(Class type) {
/*  72 */     Converter converter = this.converterLookup.lookupConverterForType(type);
/*  73 */     if ((converter != null) && ((converter instanceof SingleValueConverter))) {
/*  74 */       return (SingleValueConverter)converter;
/*     */     }
/*  76 */     return null;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public SingleValueConverter getConverterFromItemType(String fieldName, Class type)
/*     */   {
/*  84 */     if (this.fieldNameToTypeMap.get(fieldName) == type) {
/*  85 */       return getLocalConverterFromItemType(type);
/*     */     }
/*  87 */     return null;
/*     */   }
/*     */ 
/*     */   public SingleValueConverter getConverterFromItemType(String fieldName, Class type, Class definedIn)
/*     */   {
/*  93 */     if (shouldLookForSingleValueConverter(fieldName, type, definedIn)) {
/*  94 */       SingleValueConverter converter = getLocalConverterFromItemType(type);
/*  95 */       if (converter != null) {
/*  96 */         return converter;
/*     */       }
/*     */     }
/*  99 */     return super.getConverterFromItemType(fieldName, type, definedIn);
/*     */   }
/*     */ 
/*     */   public boolean shouldLookForSingleValueConverter(String fieldName, Class type, Class definedIn) {
/* 103 */     Field field = getField(definedIn, fieldName);
/* 104 */     return (this.fieldToUseAsAttribute.contains(field)) || (this.fieldNameToTypeMap.get(fieldName) == type) || (this.typeSet.contains(type));
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public SingleValueConverter getConverterFromItemType(Class type)
/*     */   {
/* 111 */     if (this.typeSet.contains(type)) {
/* 112 */       return getLocalConverterFromItemType(type);
/*     */     }
/* 114 */     return null;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public SingleValueConverter getConverterFromAttribute(String attributeName)
/*     */   {
/* 122 */     SingleValueConverter converter = null;
/* 123 */     Class type = (Class)this.fieldNameToTypeMap.get(attributeName);
/* 124 */     if (type != null) {
/* 125 */       converter = getLocalConverterFromItemType(type);
/*     */     }
/* 127 */     return converter;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public SingleValueConverter getConverterFromAttribute(Class definedIn, String attribute)
/*     */   {
/* 134 */     Field field = getField(definedIn, attribute);
/* 135 */     return getConverterFromAttribute(definedIn, attribute, field.getType());
/*     */   }
/*     */ 
/*     */   public SingleValueConverter getConverterFromAttribute(Class definedIn, String attribute, Class type) {
/* 139 */     if (shouldLookForSingleValueConverter(attribute, type, definedIn)) {
/* 140 */       SingleValueConverter converter = getLocalConverterFromItemType(type);
/* 141 */       if (converter != null) {
/* 142 */         return converter;
/*     */       }
/*     */     }
/* 145 */     return super.getConverterFromAttribute(definedIn, attribute, type);
/*     */   }
/*     */ 
/*     */   public void addAttributeFor(Field field)
/*     */   {
/* 155 */     this.fieldToUseAsAttribute.add(field);
/*     */   }
/*     */ 
/*     */   public void addAttributeFor(Class definedIn, String fieldName)
/*     */   {
/* 167 */     this.fieldToUseAsAttribute.add(getField(definedIn, fieldName));
/*     */   }
/*     */ 
/*     */   private Field getField(Class definedIn, String fieldName) {
/* 171 */     return Fields.find(definedIn, fieldName);
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.mapper.AttributeMapper
 * JD-Core Version:    0.6.0
 */