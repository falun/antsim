/*     */ package com.thoughtworks.xstream.mapper;
/*     */ 
/*     */ import com.thoughtworks.xstream.alias.ClassMapper;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ 
/*     */ public class ArrayMapper extends MapperWrapper
/*     */ {
/*  27 */   private static final Collection BOXED_TYPES = Arrays.asList(new Class[] { Boolean.class, Byte.class, Character.class, Short.class, Integer.class, Long.class, Float.class, Double.class });
/*     */ 
/*     */   public ArrayMapper(Mapper wrapped)
/*     */   {
/*  40 */     super(wrapped);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public ArrayMapper(ClassMapper wrapped)
/*     */   {
/*  47 */     this(wrapped);
/*     */   }
/*     */ 
/*     */   public String serializedClass(Class type) {
/*  51 */     StringBuffer arraySuffix = new StringBuffer();
/*  52 */     String name = null;
/*  53 */     while (type.isArray()) {
/*  54 */       name = super.serializedClass(type);
/*  55 */       if (!type.getName().equals(name)) break;
/*  56 */       type = type.getComponentType();
/*  57 */       arraySuffix.append("-array");
/*  58 */       name = null;
/*     */     }
/*     */ 
/*  63 */     if (name == null) {
/*  64 */       name = boxedTypeName(type);
/*     */     }
/*  66 */     if (name == null) {
/*  67 */       name = super.serializedClass(type);
/*     */     }
/*  69 */     if (arraySuffix.length() > 0) {
/*  70 */       return name + arraySuffix;
/*     */     }
/*  72 */     return name;
/*     */   }
/*     */ 
/*     */   public Class realClass(String elementName)
/*     */   {
/*  77 */     int dimensions = 0;
/*     */ 
/*  80 */     while (elementName.endsWith("-array")) {
/*  81 */       elementName = elementName.substring(0, elementName.length() - 6);
/*  82 */       dimensions++;
/*     */     }
/*     */ 
/*  85 */     if (dimensions > 0) {
/*  86 */       Class componentType = primitiveClassNamed(elementName);
/*  87 */       if (componentType == null) {
/*  88 */         componentType = super.realClass(elementName);
/*     */       }
/*  90 */       while (componentType.isArray()) {
/*  91 */         componentType = componentType.getComponentType();
/*  92 */         dimensions++;
/*     */       }
/*  94 */       return super.realClass(arrayType(dimensions, componentType));
/*     */     }
/*  96 */     return super.realClass(elementName);
/*     */   }
/*     */ 
/*     */   private String arrayType(int dimensions, Class componentType)
/*     */   {
/* 101 */     StringBuffer className = new StringBuffer();
/* 102 */     for (int i = 0; i < dimensions; i++) {
/* 103 */       className.append('[');
/*     */     }
/* 105 */     if (componentType.isPrimitive()) {
/* 106 */       className.append(charThatJavaUsesToRepresentPrimitiveArrayType(componentType));
/* 107 */       return className.toString();
/*     */     }
/* 109 */     className.append('L').append(componentType.getName()).append(';');
/* 110 */     return className.toString();
/*     */   }
/*     */ 
/*     */   private Class primitiveClassNamed(String name)
/*     */   {
/* 115 */     return name.equals("double") ? Double.TYPE : name.equals("float") ? Float.TYPE : name.equals("long") ? Long.TYPE : name.equals("int") ? Integer.TYPE : name.equals("short") ? Short.TYPE : name.equals("char") ? Character.TYPE : name.equals("byte") ? Byte.TYPE : name.equals("boolean") ? Boolean.TYPE : name.equals("void") ? Void.TYPE : null;
/*     */   }
/*     */ 
/*     */   private char charThatJavaUsesToRepresentPrimitiveArrayType(Class primvCls)
/*     */   {
/* 129 */     return primvCls == Double.TYPE ? 'D' : primvCls == Float.TYPE ? 'F' : primvCls == Long.TYPE ? 'J' : primvCls == Integer.TYPE ? 'I' : primvCls == Short.TYPE ? 'S' : primvCls == Character.TYPE ? 'C' : primvCls == Byte.TYPE ? 'B' : primvCls == Boolean.TYPE ? 'Z' : '\000';
/*     */   }
/*     */ 
/*     */   private String boxedTypeName(Class type)
/*     */   {
/* 142 */     return BOXED_TYPES.contains(type) ? type.getName() : null;
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.mapper.ArrayMapper
 * JD-Core Version:    0.6.0
 */