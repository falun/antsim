/*     */ package com.thoughtworks.xstream.mapper;
/*     */ 
/*     */ import com.thoughtworks.xstream.alias.ClassMapper;
/*     */ import com.thoughtworks.xstream.converters.ConverterLookup;
/*     */ import com.thoughtworks.xstream.converters.SingleValueConverter;
/*     */ import com.thoughtworks.xstream.converters.enums.EnumSingleValueConverter;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ 
/*     */ public class EnumMapper extends MapperWrapper
/*     */ {
/*     */   private transient AttributeMapper attributeMapper;
/*     */   private transient Map enumConverterMap;
/*     */   private final ConverterLookup converterLookup;
/*     */ 
/*     */   /** @deprecated */
/*     */   public EnumMapper(Mapper wrapped, ConverterLookup lookup)
/*     */   {
/*  43 */     super(wrapped);
/*  44 */     this.converterLookup = lookup;
/*  45 */     readResolve();
/*     */   }
/*     */   @Deprecated
/*     */   public EnumMapper(Mapper wrapped) {
/*  50 */     super(wrapped);
/*  51 */     this.converterLookup = null;
/*  52 */     readResolve();
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public EnumMapper(ClassMapper wrapped)
/*     */   {
/*  60 */     this(wrapped);
/*     */   }
/*     */ 
/*     */   public String serializedClass(Class type)
/*     */   {
/*  65 */     if (type == null) {
/*  66 */       return super.serializedClass(type);
/*     */     }
/*  68 */     if ((Enum.class.isAssignableFrom(type)) && (type.getSuperclass() != Enum.class))
/*  69 */       return super.serializedClass(type.getSuperclass());
/*  70 */     if (EnumSet.class.isAssignableFrom(type)) {
/*  71 */       return super.serializedClass(EnumSet.class);
/*     */     }
/*  73 */     return super.serializedClass(type);
/*     */   }
/*     */ 
/*     */   public boolean isImmutableValueType(Class type)
/*     */   {
/*  79 */     return (Enum.class.isAssignableFrom(type)) || (super.isImmutableValueType(type));
/*     */   }
/*     */ 
/*     */   public SingleValueConverter getConverterFromItemType(String fieldName, Class type, Class definedIn)
/*     */   {
/*  85 */     SingleValueConverter converter = getLocalConverter(fieldName, type, definedIn);
/*  86 */     return converter == null ? super.getConverterFromItemType(fieldName, type, definedIn) : converter;
/*     */   }
/*     */ 
/*     */   public SingleValueConverter getConverterFromAttribute(Class definedIn, String attribute, Class type)
/*     */   {
/*  94 */     SingleValueConverter converter = getLocalConverter(attribute, type, definedIn);
/*  95 */     return converter == null ? super.getConverterFromAttribute(definedIn, attribute, type) : converter;
/*     */   }
/*     */ 
/*     */   private SingleValueConverter getLocalConverter(String fieldName, Class type, Class definedIn)
/*     */   {
/* 101 */     if ((this.attributeMapper != null) && (Enum.class.isAssignableFrom(type)) && (this.attributeMapper.shouldLookForSingleValueConverter(fieldName, type, definedIn)))
/*     */     {
/* 104 */       synchronized (this.enumConverterMap) {
/* 105 */         SingleValueConverter singleValueConverter = (SingleValueConverter)this.enumConverterMap.get(type);
/*     */ 
/* 107 */         if (singleValueConverter == null) {
/* 108 */           singleValueConverter = super.getConverterFromItemType(fieldName, type, definedIn);
/* 109 */           if (singleValueConverter == null) {
/* 110 */             singleValueConverter = new EnumSingleValueConverter(type);
/*     */           }
/* 112 */           this.enumConverterMap.put(type, singleValueConverter);
/*     */         }
/* 114 */         return singleValueConverter;
/*     */       }
/*     */     }
/* 117 */     return null;
/*     */   }
/*     */ 
/*     */   private Object readResolve() {
/* 121 */     this.enumConverterMap = new WeakHashMap();
/* 122 */     this.attributeMapper = ((AttributeMapper)lookupMapperOfType(AttributeMapper.class));
/* 123 */     return this;
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.mapper.EnumMapper
 * JD-Core Version:    0.6.0
 */