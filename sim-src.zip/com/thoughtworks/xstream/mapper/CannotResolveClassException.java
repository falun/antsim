/*    */ package com.thoughtworks.xstream.mapper;
/*    */ 
/*    */ public class CannotResolveClassException extends com.thoughtworks.xstream.alias.CannotResolveClassException
/*    */ {
/*    */   public CannotResolveClassException(String className)
/*    */   {
/* 23 */     super(className);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.mapper.CannotResolveClassException
 * JD-Core Version:    0.6.0
 */