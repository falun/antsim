/*     */ package com.thoughtworks.xstream.mapper;
/*     */ 
/*     */ import com.thoughtworks.xstream.InitializationException;
/*     */ import com.thoughtworks.xstream.alias.ClassMapper;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class ImplicitCollectionMapper extends MapperWrapper
/*     */ {
/*  38 */   private final Map classNameToMapper = new HashMap();
/*     */ 
/*     */   public ImplicitCollectionMapper(Mapper wrapped)
/*     */   {
/*  27 */     super(wrapped);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public ImplicitCollectionMapper(ClassMapper wrapped)
/*     */   {
/*  34 */     this(wrapped);
/*     */   }
/*     */ 
/*     */   private ImplicitCollectionMapperForClass getMapper(Class definedIn)
/*     */   {
/*  41 */     while (definedIn != null) {
/*  42 */       ImplicitCollectionMapperForClass mapper = (ImplicitCollectionMapperForClass)this.classNameToMapper.get(definedIn);
/*     */ 
/*  44 */       if (mapper != null) {
/*  45 */         return mapper;
/*     */       }
/*  47 */       definedIn = definedIn.getSuperclass();
/*     */     }
/*  49 */     return null;
/*     */   }
/*     */ 
/*     */   private ImplicitCollectionMapperForClass getOrCreateMapper(Class definedIn) {
/*  53 */     ImplicitCollectionMapperForClass mapper = getMapper(definedIn);
/*  54 */     if (mapper == null) {
/*  55 */       mapper = new ImplicitCollectionMapperForClass(null);
/*  56 */       this.classNameToMapper.put(definedIn, mapper);
/*     */     }
/*  58 */     return mapper;
/*     */   }
/*     */ 
/*     */   public String getFieldNameForItemTypeAndName(Class definedIn, Class itemType, String itemFieldName)
/*     */   {
/*  63 */     ImplicitCollectionMapperForClass mapper = getMapper(definedIn);
/*  64 */     if (mapper != null) {
/*  65 */       return mapper.getFieldNameForItemTypeAndName(itemType, itemFieldName);
/*     */     }
/*  67 */     return null;
/*     */   }
/*     */ 
/*     */   public Class getItemTypeForItemFieldName(Class definedIn, String itemFieldName)
/*     */   {
/*  72 */     ImplicitCollectionMapperForClass mapper = getMapper(definedIn);
/*  73 */     if (mapper != null) {
/*  74 */       return mapper.getItemTypeForItemFieldName(itemFieldName);
/*     */     }
/*  76 */     return null;
/*     */   }
/*     */ 
/*     */   public Mapper.ImplicitCollectionMapping getImplicitCollectionDefForFieldName(Class itemType, String fieldName)
/*     */   {
/*  82 */     ImplicitCollectionMapperForClass mapper = getMapper(itemType);
/*  83 */     if (mapper != null) {
/*  84 */       return mapper.getImplicitCollectionDefForFieldName(fieldName);
/*     */     }
/*  86 */     return null;
/*     */   }
/*     */ 
/*     */   public void add(Class definedIn, String fieldName, Class itemType)
/*     */   {
/*  91 */     add(definedIn, fieldName, null, itemType);
/*     */   }
/*     */ 
/*     */   public void add(Class definedIn, String fieldName, String itemFieldName, Class itemType) {
/*  95 */     Field field = null;
/*  96 */     while (definedIn != Object.class) {
/*     */       try {
/*  98 */         field = definedIn.getDeclaredField(fieldName);
/*     */       }
/*     */       catch (SecurityException e) {
/* 101 */         throw new InitializationException("Access denied for field with implicit collection", e);
/*     */       }
/*     */       catch (NoSuchFieldException e) {
/* 104 */         definedIn = definedIn.getSuperclass();
/*     */       }
/*     */     }
/* 107 */     if (field == null) {
/* 108 */       throw new InitializationException("No field \"" + fieldName + "\" for implicit collection");
/*     */     }
/*     */ 
/* 111 */     if (!Collection.class.isAssignableFrom(field.getType())) {
/* 112 */       throw new InitializationException("Field \"" + fieldName + "\" declares no collection");
/*     */     }
/*     */ 
/* 116 */     ImplicitCollectionMapperForClass mapper = getOrCreateMapper(definedIn);
/* 117 */     mapper.add(new ImplicitCollectionMappingImpl(fieldName, itemType, itemFieldName));
/*     */   }
/*     */ 
/*     */   private static class NamedItemType
/*     */   {
/*     */     Class itemType;
/*     */     String itemFieldName;
/*     */ 
/*     */     NamedItemType(Class itemType, String itemFieldName)
/*     */     {
/* 249 */       this.itemType = itemType;
/* 250 */       this.itemFieldName = itemFieldName;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object obj) {
/* 254 */       if ((obj instanceof NamedItemType)) {
/* 255 */         NamedItemType b = (NamedItemType)obj;
/* 256 */         return (this.itemType.equals(b.itemType)) && (isEquals(this.itemFieldName, b.itemFieldName));
/*     */       }
/* 258 */       return false;
/*     */     }
/*     */ 
/*     */     private static boolean isEquals(Object a, Object b)
/*     */     {
/* 263 */       if (a == null) {
/* 264 */         return b == null;
/*     */       }
/* 266 */       return a.equals(b);
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 271 */       int hash = this.itemType.hashCode() << 7;
/* 272 */       if (this.itemFieldName != null) {
/* 273 */         hash += this.itemFieldName.hashCode();
/*     */       }
/* 275 */       return hash;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ImplicitCollectionMappingImpl
/*     */     implements Mapper.ImplicitCollectionMapping
/*     */   {
/*     */     private String fieldName;
/*     */     private String itemFieldName;
/*     */     private Class itemType;
/*     */ 
/*     */     ImplicitCollectionMappingImpl(String fieldName, Class itemType, String itemFieldName)
/*     */     {
/* 196 */       this.fieldName = fieldName;
/* 197 */       this.itemFieldName = itemFieldName;
/* 198 */       this.itemType = (itemType == null ? Object.class : itemType);
/*     */     }
/*     */ 
/*     */     public boolean equals(Object obj) {
/* 202 */       if ((obj instanceof ImplicitCollectionMappingImpl)) {
/* 203 */         ImplicitCollectionMappingImpl b = (ImplicitCollectionMappingImpl)obj;
/* 204 */         return (this.fieldName.equals(b.fieldName)) && (isEquals(this.itemFieldName, b.itemFieldName));
/*     */       }
/*     */ 
/* 207 */       return false;
/*     */     }
/*     */ 
/*     */     public ImplicitCollectionMapper.NamedItemType createNamedItemType()
/*     */     {
/* 212 */       return new ImplicitCollectionMapper.NamedItemType(this.itemType, this.itemFieldName);
/*     */     }
/*     */ 
/*     */     private static boolean isEquals(Object a, Object b) {
/* 216 */       if (a == null) {
/* 217 */         return b == null;
/*     */       }
/* 219 */       return a.equals(b);
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 224 */       int hash = this.fieldName.hashCode();
/* 225 */       if (this.itemFieldName != null) {
/* 226 */         hash += (this.itemFieldName.hashCode() << 7);
/*     */       }
/* 228 */       return hash;
/*     */     }
/*     */ 
/*     */     public String getFieldName() {
/* 232 */       return this.fieldName;
/*     */     }
/*     */ 
/*     */     public String getItemFieldName() {
/* 236 */       return this.itemFieldName;
/*     */     }
/*     */ 
/*     */     public Class getItemType() {
/* 240 */       return this.itemType;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ImplicitCollectionMapperForClass
/*     */   {
/* 122 */     private Map namedItemTypeToDef = new HashMap();
/*     */ 
/* 124 */     private Map itemFieldNameToDef = new HashMap();
/*     */ 
/* 126 */     private Map fieldNameToDef = new HashMap();
/*     */ 
/*     */     private ImplicitCollectionMapperForClass() {  }
/*     */ 
/* 129 */     public String getFieldNameForItemTypeAndName(Class itemType, String itemFieldName) { ImplicitCollectionMapper.ImplicitCollectionMappingImpl unnamed = null;
/* 130 */       for (Iterator iterator = this.namedItemTypeToDef.keySet().iterator(); iterator.hasNext(); ) {
/* 131 */         ImplicitCollectionMapper.NamedItemType itemTypeForFieldName = (ImplicitCollectionMapper.NamedItemType)iterator.next();
/* 132 */         ImplicitCollectionMapper.ImplicitCollectionMappingImpl def = (ImplicitCollectionMapper.ImplicitCollectionMappingImpl)this.namedItemTypeToDef.get(itemTypeForFieldName);
/*     */ 
/* 134 */         if (itemType == Mapper.Null.class) {
/* 135 */           unnamed = def;
/* 136 */           break;
/* 137 */         }if (itemTypeForFieldName.itemType.isAssignableFrom(itemType)) {
/* 138 */           if (def.getItemFieldName() != null) {
/* 139 */             if (def.getItemFieldName().equals(itemFieldName))
/* 140 */               return def.getFieldName();
/*     */           }
/*     */           else {
/* 143 */             unnamed = def;
/* 144 */             if (itemFieldName == null) {
/*     */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 150 */       return unnamed != null ? unnamed.getFieldName() : null; }
/*     */ 
/*     */     public Class getItemTypeForItemFieldName(String itemFieldName)
/*     */     {
/* 154 */       ImplicitCollectionMapper.ImplicitCollectionMappingImpl def = getImplicitCollectionDefByItemFieldName(itemFieldName);
/* 155 */       if (def != null) {
/* 156 */         return def.getItemType();
/*     */       }
/* 158 */       return null;
/*     */     }
/*     */ 
/*     */     private ImplicitCollectionMapper.ImplicitCollectionMappingImpl getImplicitCollectionDefByItemFieldName(String itemFieldName)
/*     */     {
/* 164 */       if (itemFieldName == null) {
/* 165 */         return null;
/*     */       }
/* 167 */       return (ImplicitCollectionMapper.ImplicitCollectionMappingImpl)this.itemFieldNameToDef.get(itemFieldName);
/*     */     }
/*     */ 
/*     */     public ImplicitCollectionMapper.ImplicitCollectionMappingImpl getImplicitCollectionDefByFieldName(String fieldName)
/*     */     {
/* 173 */       return (ImplicitCollectionMapper.ImplicitCollectionMappingImpl)this.fieldNameToDef.get(fieldName);
/*     */     }
/*     */ 
/*     */     public Mapper.ImplicitCollectionMapping getImplicitCollectionDefForFieldName(String fieldName) {
/* 177 */       return (Mapper.ImplicitCollectionMapping)this.fieldNameToDef.get(fieldName);
/*     */     }
/*     */ 
/*     */     public void add(ImplicitCollectionMapper.ImplicitCollectionMappingImpl def) {
/* 181 */       this.fieldNameToDef.put(def.getFieldName(), def);
/* 182 */       this.namedItemTypeToDef.put(def.createNamedItemType(), def);
/* 183 */       if (def.getItemFieldName() != null)
/* 184 */         this.itemFieldNameToDef.put(def.getItemFieldName(), def);
/*     */     }
/*     */ 
/*     */     ImplicitCollectionMapperForClass(ImplicitCollectionMapper.1 x0)
/*     */     {
/* 120 */       this();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.mapper.ImplicitCollectionMapper
 * JD-Core Version:    0.6.0
 */