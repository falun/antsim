/*     */ package com.thoughtworks.xstream.mapper;
/*     */ 
/*     */ import com.thoughtworks.xstream.InitializationException;
/*     */ import com.thoughtworks.xstream.annotations.XStreamAlias;
/*     */ import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
/*     */ import com.thoughtworks.xstream.annotations.XStreamConverter;
/*     */ import com.thoughtworks.xstream.annotations.XStreamConverters;
/*     */ import com.thoughtworks.xstream.annotations.XStreamImplicit;
/*     */ import com.thoughtworks.xstream.annotations.XStreamImplicitCollection;
/*     */ import com.thoughtworks.xstream.annotations.XStreamInclude;
/*     */ import com.thoughtworks.xstream.annotations.XStreamOmitField;
/*     */ import com.thoughtworks.xstream.converters.Converter;
/*     */ import com.thoughtworks.xstream.converters.ConverterMatcher;
/*     */ import com.thoughtworks.xstream.converters.ConverterRegistry;
/*     */ import com.thoughtworks.xstream.converters.SingleValueConverter;
/*     */ import com.thoughtworks.xstream.converters.SingleValueConverterWrapper;
/*     */ import com.thoughtworks.xstream.converters.reflection.ReflectionProvider;
/*     */ import com.thoughtworks.xstream.core.JVM;
/*     */ import com.thoughtworks.xstream.core.util.DependencyInjectionFactory;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.GenericArrayType;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.WeakHashMap;
/*     */ 
/*     */ public class AnnotationMapper extends MapperWrapper
/*     */   implements AnnotationConfiguration
/*     */ {
/*     */   private boolean locked;
/*     */   private final Object[] arguments;
/*     */   private final ConverterRegistry converterRegistry;
/*     */   private final ClassAliasingMapper classAliasingMapper;
/*     */   private final DefaultImplementationsMapper defaultImplementationsMapper;
/*     */   private final ImplicitCollectionMapper implicitCollectionMapper;
/*     */   private final FieldAliasingMapper fieldAliasingMapper;
/*     */   private final AttributeMapper attributeMapper;
/*     */   private final LocalConversionMapper localConversionMapper;
/*  68 */   private final Map<Class<?>, Converter> converterCache = new HashMap();
/*  69 */   private final Set<Class<?>> annotatedTypes = new WeakHashSet(null);
/*     */ 
/*     */   public AnnotationMapper(Mapper wrapped, ConverterRegistry converterRegistry, ClassLoader classLoader, ReflectionProvider reflectionProvider, JVM jvm)
/*     */   {
/*  81 */     super(wrapped);
/*  82 */     this.converterRegistry = converterRegistry;
/*  83 */     this.annotatedTypes.add(Object.class);
/*  84 */     this.classAliasingMapper = ((ClassAliasingMapper)lookupMapperOfType(ClassAliasingMapper.class));
/*  85 */     this.defaultImplementationsMapper = ((DefaultImplementationsMapper)lookupMapperOfType(DefaultImplementationsMapper.class));
/*  86 */     this.implicitCollectionMapper = ((ImplicitCollectionMapper)lookupMapperOfType(ImplicitCollectionMapper.class));
/*  87 */     this.fieldAliasingMapper = ((FieldAliasingMapper)lookupMapperOfType(FieldAliasingMapper.class));
/*  88 */     this.attributeMapper = ((AttributeMapper)lookupMapperOfType(AttributeMapper.class));
/*  89 */     this.localConversionMapper = ((LocalConversionMapper)lookupMapperOfType(LocalConversionMapper.class));
/*  90 */     this.locked = true;
/*  91 */     this.arguments = new Object[] { this, classLoader, reflectionProvider, jvm };
/*     */   }
/*     */ 
/*     */   public String realMember(Class type, String serialized)
/*     */   {
/*  96 */     if (!this.locked) {
/*  97 */       processAnnotations(type);
/*     */     }
/*  99 */     return super.realMember(type, serialized);
/*     */   }
/*     */ 
/*     */   public String serializedClass(Class type)
/*     */   {
/* 104 */     if (!this.locked) {
/* 105 */       processAnnotations(type);
/*     */     }
/* 107 */     return super.serializedClass(type);
/*     */   }
/*     */ 
/*     */   public Class defaultImplementationOf(Class type)
/*     */   {
/* 112 */     if (!this.locked) {
/* 113 */       processAnnotations(type);
/*     */     }
/* 115 */     Class defaultImplementation = super.defaultImplementationOf(type);
/* 116 */     if (!this.locked) {
/* 117 */       processAnnotations(defaultImplementation);
/*     */     }
/* 119 */     return defaultImplementation;
/*     */   }
/*     */ 
/*     */   public Converter getLocalConverter(Class definedIn, String fieldName)
/*     */   {
/* 124 */     if (!this.locked) {
/* 125 */       processAnnotations(definedIn);
/*     */     }
/* 127 */     return super.getLocalConverter(definedIn, fieldName);
/*     */   }
/*     */ 
/*     */   public void autodetectAnnotations(boolean mode) {
/* 131 */     this.locked = (!mode);
/*     */   }
/*     */ 
/*     */   public void processAnnotations(Class[] initialTypes) {
/* 135 */     if ((initialTypes == null) || (initialTypes.length == 0)) {
/* 136 */       return;
/*     */     }
/* 138 */     this.locked = true;
/* 139 */     synchronized (this.annotatedTypes) {
/* 140 */       Set types = new UnprocessedTypesSet(null);
/* 141 */       for (Class initialType : initialTypes) {
/* 142 */         types.add(initialType);
/*     */       }
/* 144 */       processTypes(types);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void processAnnotations(Class initialType) {
/* 149 */     if (initialType == null) {
/* 150 */       return;
/*     */     }
/* 152 */     synchronized (this.annotatedTypes) {
/* 153 */       Set types = new UnprocessedTypesSet(null);
/* 154 */       types.add(initialType);
/* 155 */       processTypes(types);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void processTypes(Set<Class<?>> types) {
/* 160 */     while (!types.isEmpty()) {
/* 161 */       Iterator iter = types.iterator();
/* 162 */       Class type = (Class)iter.next();
/* 163 */       iter.remove();
/*     */ 
/* 165 */       if (this.annotatedTypes.add(type)) {
/* 166 */         if (type.isPrimitive())
/*     */         {
/*     */           continue;
/*     */         }
/* 170 */         addParametrizedTypes(type, types);
/*     */ 
/* 172 */         processConverterAnnotations(type);
/* 173 */         processAliasAnnotation(type, types);
/*     */ 
/* 175 */         if (type.isInterface())
/*     */         {
/*     */           continue;
/*     */         }
/* 179 */         processImplicitCollectionAnnotation(type);
/*     */ 
/* 181 */         Field[] fields = type.getDeclaredFields();
/* 182 */         for (int i = 0; i < fields.length; i++) {
/* 183 */           Field field = fields[i];
/* 184 */           if ((field.isEnumConstant()) || ((field.getModifiers() & 0x88) > 0))
/*     */           {
/*     */             continue;
/*     */           }
/*     */ 
/* 189 */           addParametrizedTypes(field.getGenericType(), types);
/*     */ 
/* 191 */           if (field.isSynthetic())
/*     */           {
/*     */             continue;
/*     */           }
/* 195 */           processFieldAliasAnnotation(field);
/* 196 */           processAsAttributeAnnotation(field);
/* 197 */           processImplicitAnnotation(field);
/* 198 */           processOmitFieldAnnotation(field);
/* 199 */           processLocalConverterAnnotation(field);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void addParametrizedTypes(Type type, Set<Class<?>> types) {
/* 206 */     Set processedTypes = new HashSet();
/* 207 */     Set localTypes = new LinkedHashSet(types, processedTypes)
/*     */     {
/*     */       public boolean add(Type o)
/*     */       {
/* 211 */         if ((o instanceof Class)) {
/* 212 */           return this.val$types.add((Class)o);
/*     */         }
/* 214 */         return (o == null) || (this.val$processedTypes.contains(o)) ? false : super.add(o);
/*     */       }
/*     */     };
/* 218 */     while (type != null) {
/* 219 */       processedTypes.add(type);
/* 220 */       if ((type instanceof Class)) {
/* 221 */         Class clazz = (Class)type;
/* 222 */         types.add(clazz);
/* 223 */         if (!clazz.isPrimitive()) {
/* 224 */           TypeVariable[] typeParameters = clazz.getTypeParameters();
/* 225 */           for (TypeVariable typeVariable : typeParameters) {
/* 226 */             localTypes.add(typeVariable);
/*     */           }
/* 228 */           localTypes.add(clazz.getGenericSuperclass());
/* 229 */           for (Type iface : clazz.getGenericInterfaces())
/* 230 */             localTypes.add(iface);
/*     */         }
/*     */       }
/* 233 */       else if ((type instanceof TypeVariable)) {
/* 234 */         TypeVariable typeVariable = (TypeVariable)type;
/* 235 */         Type[] bounds = typeVariable.getBounds();
/* 236 */         for (Type bound : bounds)
/* 237 */           localTypes.add(bound);
/*     */       }
/* 239 */       else if ((type instanceof ParameterizedType)) {
/* 240 */         ParameterizedType parametrizedType = (ParameterizedType)type;
/* 241 */         localTypes.add(parametrizedType.getRawType());
/* 242 */         Type[] actualArguments = parametrizedType.getActualTypeArguments();
/* 243 */         for (Type actualArgument : actualArguments)
/* 244 */           localTypes.add(actualArgument);
/*     */       }
/* 246 */       else if ((type instanceof GenericArrayType)) {
/* 247 */         GenericArrayType arrayType = (GenericArrayType)type;
/* 248 */         localTypes.add(arrayType.getGenericComponentType());
/*     */       }
/*     */ 
/* 251 */       if (!localTypes.isEmpty()) {
/* 252 */         Iterator iter = localTypes.iterator();
/* 253 */         type = (Type)iter.next();
/* 254 */         iter.remove();
/* 255 */         continue;
/* 256 */       }type = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void processConverterAnnotations(Class<?> type)
/*     */   {
/*     */     XStreamConverter converterAnnotation;
/* 262 */     if (this.converterRegistry != null) {
/* 263 */       XStreamConverters convertersAnnotation = (XStreamConverters)type.getAnnotation(XStreamConverters.class);
/*     */ 
/* 265 */       converterAnnotation = (XStreamConverter)type.getAnnotation(XStreamConverter.class);
/*     */ 
/* 267 */       List annotations = convertersAnnotation != null ? new ArrayList(Arrays.asList(convertersAnnotation.value())) : new ArrayList();
/*     */ 
/* 270 */       if (converterAnnotation != null) {
/* 271 */         annotations.add(converterAnnotation);
/*     */       }
/* 273 */       for (XStreamConverter annotation : annotations) {
/* 274 */         Class converterType = annotation.value();
/* 275 */         Converter converter = cacheConverter(converterType);
/* 276 */         if (converter != null)
/* 277 */           if ((converterAnnotation != null) || (converter.canConvert(type)))
/* 278 */             this.converterRegistry.registerConverter(converter, 0);
/*     */           else
/* 280 */             throw new InitializationException("Converter " + converterType.getName() + " cannot handle annotated class " + type.getName());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void processAliasAnnotation(Class<?> type, Set<Class<?>> types)
/*     */   {
/* 291 */     XStreamAlias aliasAnnotation = (XStreamAlias)type.getAnnotation(XStreamAlias.class);
/* 292 */     if (aliasAnnotation != null) {
/* 293 */       if (this.classAliasingMapper == null) {
/* 294 */         throw new InitializationException("No " + ClassAliasingMapper.class.getName() + " available");
/*     */       }
/*     */ 
/* 298 */       if (aliasAnnotation.impl() != Void.class)
/*     */       {
/* 300 */         this.classAliasingMapper.addClassAlias(aliasAnnotation.value(), type);
/* 301 */         this.defaultImplementationsMapper.addDefaultImplementation(aliasAnnotation.impl(), type);
/*     */ 
/* 303 */         if (type.isInterface())
/* 304 */           types.add(aliasAnnotation.impl());
/*     */       }
/*     */       else {
/* 307 */         this.classAliasingMapper.addClassAlias(aliasAnnotation.value(), type);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   private void processImplicitCollectionAnnotation(Class<?> type) {
/* 314 */     XStreamImplicitCollection implicitColAnnotation = (XStreamImplicitCollection)type.getAnnotation(XStreamImplicitCollection.class);
/*     */ 
/* 316 */     if (implicitColAnnotation != null) {
/* 317 */       if (this.implicitCollectionMapper == null) {
/* 318 */         throw new InitializationException("No " + ImplicitCollectionMapper.class.getName() + " available");
/* 322 */       }
/*     */ String fieldName = implicitColAnnotation.value();
/* 323 */       String itemFieldName = implicitColAnnotation.item();
/*     */       Field field;
/*     */       try { field = type.getDeclaredField(fieldName);
/*     */       } catch (NoSuchFieldException e) {
/* 328 */         throw new InitializationException(type.getName() + " does not have a field named '" + fieldName + "' as required by " + XStreamImplicitCollection.class.getName());
/*     */       }
/*     */ 
/* 334 */       Class itemType = null;
/* 335 */       Type genericType = field.getGenericType();
/* 336 */       if ((genericType instanceof ParameterizedType)) {
/* 337 */         Type typeArgument = ((ParameterizedType)genericType).getActualTypeArguments()[0];
/*     */ 
/* 339 */         itemType = getClass(typeArgument);
/*     */       }
/* 341 */       if (itemType == null) {
/* 342 */         this.implicitCollectionMapper.add(type, fieldName, null, Object.class);
/*     */       }
/* 344 */       else if (itemFieldName.equals(""))
/* 345 */         this.implicitCollectionMapper.add(type, fieldName, null, itemType);
/*     */       else
/* 347 */         this.implicitCollectionMapper.add(type, fieldName, itemFieldName, itemType);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void processFieldAliasAnnotation(Field field)
/*     */   {
/* 354 */     XStreamAlias aliasAnnotation = (XStreamAlias)field.getAnnotation(XStreamAlias.class);
/* 355 */     if (aliasAnnotation != null) {
/* 356 */       if (this.fieldAliasingMapper == null) {
/* 357 */         throw new InitializationException("No " + FieldAliasingMapper.class.getName() + " available");
/*     */       }
/*     */ 
/* 361 */       this.fieldAliasingMapper.addFieldAlias(aliasAnnotation.value(), field.getDeclaringClass(), field.getName());
/*     */     }
/*     */   }
/*     */ 
/*     */   private void processAsAttributeAnnotation(Field field)
/*     */   {
/* 367 */     XStreamAsAttribute asAttributeAnnotation = (XStreamAsAttribute)field.getAnnotation(XStreamAsAttribute.class);
/*     */ 
/* 369 */     if (asAttributeAnnotation != null) {
/* 370 */       if (this.attributeMapper == null) {
/* 371 */         throw new InitializationException("No " + AttributeMapper.class.getName() + " available");
/*     */       }
/*     */ 
/* 375 */       this.attributeMapper.addAttributeFor(field);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void processImplicitAnnotation(Field field) {
/* 380 */     XStreamImplicit implicitAnnotation = (XStreamImplicit)field.getAnnotation(XStreamImplicit.class);
/* 381 */     if (implicitAnnotation != null) {
/* 382 */       if (this.implicitCollectionMapper == null) {
/* 383 */         throw new InitializationException("No " + ImplicitCollectionMapper.class.getName() + " available");
/*     */       }
/*     */ 
/* 387 */       String fieldName = field.getName();
/* 388 */       String itemFieldName = implicitAnnotation.itemFieldName();
/* 389 */       Class itemType = null;
/* 390 */       Type genericType = field.getGenericType();
/* 391 */       if ((genericType instanceof ParameterizedType)) {
/* 392 */         Type typeArgument = ((ParameterizedType)genericType).getActualTypeArguments()[0];
/*     */ 
/* 394 */         itemType = getClass(typeArgument);
/*     */       }
/* 396 */       if ((itemFieldName != null) && (!"".equals(itemFieldName))) {
/* 397 */         this.implicitCollectionMapper.add(field.getDeclaringClass(), fieldName, itemFieldName, itemType);
/*     */       }
/*     */       else
/* 400 */         this.implicitCollectionMapper.add(field.getDeclaringClass(), fieldName, itemType);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void processOmitFieldAnnotation(Field field)
/*     */   {
/* 406 */     XStreamOmitField omitFieldAnnotation = (XStreamOmitField)field.getAnnotation(XStreamOmitField.class);
/*     */ 
/* 408 */     if (omitFieldAnnotation != null) {
/* 409 */       if (this.fieldAliasingMapper == null) {
/* 410 */         throw new InitializationException("No " + FieldAliasingMapper.class.getName() + " available");
/*     */       }
/*     */ 
/* 414 */       this.fieldAliasingMapper.omitField(field.getDeclaringClass(), field.getName());
/*     */     }
/*     */   }
/*     */ 
/*     */   private void processLocalConverterAnnotation(Field field) {
/* 419 */     XStreamConverter annotation = (XStreamConverter)field.getAnnotation(XStreamConverter.class);
/* 420 */     if (annotation != null) {
/* 421 */       Class converterType = annotation.value();
/* 422 */       Converter converter = cacheConverter(converterType);
/* 423 */       if (converter != null) {
/* 424 */         if (this.localConversionMapper == null) {
/* 425 */           throw new InitializationException("No " + LocalConversionMapper.class.getName() + " available");
/*     */         }
/*     */ 
/* 429 */         this.localConversionMapper.registerLocalConverter(field.getDeclaringClass(), field.getName(), converter);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private Converter cacheConverter(Class<? extends ConverterMatcher> converterType)
/*     */   {
/* 436 */     Converter converter = (Converter)this.converterCache.get(converterType);
/* 437 */     if (converter == null) {
/*     */       try {
/* 439 */         if (SingleValueConverter.class.isAssignableFrom(converterType)) {
/* 440 */           SingleValueConverter svc = (SingleValueConverter)DependencyInjectionFactory.newInstance(converterType, this.arguments);
/*     */ 
/* 442 */           converter = new SingleValueConverterWrapper(svc);
/*     */         } else {
/* 444 */           converter = (Converter)DependencyInjectionFactory.newInstance(converterType, this.arguments);
/*     */         }
/*     */ 
/* 447 */         this.converterCache.put(converterType, converter);
/*     */       } catch (Exception e) {
/* 449 */         throw new InitializationException("Cannot instantiate converter " + converterType.getName(), e);
/*     */       }
/*     */     }
/*     */ 
/* 453 */     return converter;
/*     */   }
/*     */ 
/*     */   private Class<?> getClass(Type typeArgument) {
/* 457 */     Class type = null;
/* 458 */     if ((typeArgument instanceof ParameterizedType))
/* 459 */       type = (Class)((ParameterizedType)typeArgument).getRawType();
/* 460 */     else if ((typeArgument instanceof Class)) {
/* 461 */       type = (Class)typeArgument;
/*     */     }
/* 463 */     return type;
/*     */   }
/*     */ 
/*     */   private static class WeakHashSet<K>
/*     */     implements Set<K>
/*     */   {
/* 497 */     private static Object NULL = new Object();
/* 498 */     private final WeakHashMap<K, Object> map = new WeakHashMap();
/*     */ 
/*     */     public boolean add(K o) {
/* 501 */       return this.map.put(o, NULL) == null;
/*     */     }
/*     */ 
/*     */     public boolean addAll(Collection<? extends K> c) {
/* 505 */       boolean ret = false;
/* 506 */       for (Iterator i$ = c.iterator(); i$.hasNext(); ) { Object k = i$.next();
/* 507 */         ret = add(k) | false;
/*     */       }
/* 509 */       return ret;
/*     */     }
/*     */ 
/*     */     public void clear() {
/* 513 */       this.map.clear();
/*     */     }
/*     */ 
/*     */     public boolean contains(Object o) {
/* 517 */       return this.map.containsKey(o);
/*     */     }
/*     */ 
/*     */     public boolean containsAll(Collection<?> c) {
/* 521 */       return this.map.keySet().containsAll(c);
/*     */     }
/*     */ 
/*     */     public boolean isEmpty() {
/* 525 */       return this.map.isEmpty();
/*     */     }
/*     */ 
/*     */     public Iterator<K> iterator() {
/* 529 */       return this.map.keySet().iterator();
/*     */     }
/*     */ 
/*     */     public boolean remove(Object o) {
/* 533 */       return this.map.remove(o) != null;
/*     */     }
/*     */ 
/*     */     public boolean removeAll(Collection<?> c) {
/* 537 */       boolean ret = false;
/* 538 */       for (Iterator i$ = c.iterator(); i$.hasNext(); ) { Object object = i$.next();
/* 539 */         ret = remove(object) | false;
/*     */       }
/* 541 */       return ret;
/*     */     }
/*     */ 
/*     */     public boolean retainAll(Collection<?> c) {
/* 545 */       boolean ret = false;
/* 546 */       for (Iterator iter = iterator(); iter.hasNext(); ) {
/* 547 */         Object element = iter.next();
/* 548 */         if (!c.contains(element)) {
/* 549 */           iter.remove();
/* 550 */           ret = true;
/*     */         }
/*     */       }
/* 553 */       return ret;
/*     */     }
/*     */ 
/*     */     public int size() {
/* 557 */       return this.map.size();
/*     */     }
/*     */ 
/*     */     public Object[] toArray() {
/* 561 */       return this.map.keySet().toArray();
/*     */     }
/*     */ 
/*     */     public <T> T[] toArray(T[] a) {
/* 565 */       return this.map.keySet().toArray(a);
/*     */     }
/*     */   }
/*     */ 
/*     */   private final class UnprocessedTypesSet extends LinkedHashSet<Class<?>>
/*     */   {
/*     */     private UnprocessedTypesSet()
/*     */     {
/*     */     }
/*     */ 
/*     */     public boolean add(Class<?> type)
/*     */     {
/* 469 */       if (type == null) {
/* 470 */         return false;
/*     */       }
/* 472 */       while (type.isArray()) {
/* 473 */         type = type.getComponentType();
/*     */       }
/* 475 */       String name = type.getName();
/* 476 */       if ((name.startsWith("java.")) || (name.startsWith("javax."))) {
/* 477 */         return false;
/*     */       }
/* 479 */       boolean ret = AnnotationMapper.this.annotatedTypes.contains(type) ? false : super.add(type);
/* 480 */       if (ret) {
/* 481 */         XStreamInclude inc = (XStreamInclude)type.getAnnotation(XStreamInclude.class);
/* 482 */         if (inc != null) {
/* 483 */           Class[] incTypes = inc.value();
/* 484 */           if (incTypes != null) {
/* 485 */             for (Class incType : incTypes) {
/* 486 */               add(incType);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 491 */       return ret;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.mapper.AnnotationMapper
 * JD-Core Version:    0.6.0
 */