/*    */ package com.thoughtworks.xstream.mapper;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ public class AttributeAliasingMapper extends AbstractAttributeAliasingMapper
/*    */ {
/*    */   public AttributeAliasingMapper(Mapper wrapped)
/*    */   {
/* 26 */     super(wrapped);
/*    */   }
/*    */ 
/*    */   public String aliasForAttribute(String attribute) {
/* 30 */     String alias = (String)this.nameToAlias.get(attribute);
/* 31 */     return alias == null ? super.aliasForAttribute(attribute) : alias;
/*    */   }
/*    */ 
/*    */   public String attributeForAlias(String alias) {
/* 35 */     String name = (String)this.aliasToName.get(alias);
/* 36 */     return name == null ? super.attributeForAlias(alias) : name;
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.mapper.AttributeAliasingMapper
 * JD-Core Version:    0.6.0
 */