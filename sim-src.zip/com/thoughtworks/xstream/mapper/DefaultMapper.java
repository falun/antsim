/*     */ package com.thoughtworks.xstream.mapper;
/*     */ 
/*     */ import com.thoughtworks.xstream.converters.Converter;
/*     */ import com.thoughtworks.xstream.converters.SingleValueConverter;
/*     */ 
/*     */ public class DefaultMapper
/*     */   implements Mapper
/*     */ {
/*     */   private final ClassLoader classLoader;
/*     */ 
/*     */   /** @deprecated */
/*     */   private transient String classAttributeIdentifier;
/*     */ 
/*     */   public DefaultMapper(ClassLoader classLoader)
/*     */   {
/*  34 */     this.classLoader = classLoader;
/*  35 */     this.classAttributeIdentifier = "class";
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public DefaultMapper(ClassLoader classLoader, String classAttributeIdentifier)
/*     */   {
/*  42 */     this(classLoader);
/*  43 */     this.classAttributeIdentifier = (classAttributeIdentifier == null ? "class" : classAttributeIdentifier);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   private Object readResolve()
/*     */   {
/*  50 */     this.classAttributeIdentifier = "class";
/*  51 */     return this;
/*     */   }
/*     */ 
/*     */   public String serializedClass(Class type) {
/*  55 */     return type.getName();
/*     */   }
/*     */ 
/*     */   public Class realClass(String elementName) {
/*     */     try {
/*  60 */       if (elementName.charAt(0) != '[')
/*  61 */         return this.classLoader.loadClass(elementName);
/*  62 */       if (elementName.endsWith(";")) {
/*  63 */         return Class.forName(elementName.toString(), false, this.classLoader);
/*     */       }
/*  65 */       return Class.forName(elementName.toString());
/*     */     } catch (ClassNotFoundException e) {
/*     */     }
/*  68 */     throw new CannotResolveClassException(elementName + " : " + e.getMessage());
/*     */   }
/*     */ 
/*     */   public Class defaultImplementationOf(Class type)
/*     */   {
/*  73 */     return type;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public String attributeForClassDefiningField()
/*     */   {
/*  80 */     return "defined-in";
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public String attributeForReadResolveField()
/*     */   {
/*  87 */     return "resolves-to";
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public String attributeForEnumType()
/*     */   {
/*  94 */     return "enum-type";
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public String attributeForImplementationClass()
/*     */   {
/* 101 */     return this.classAttributeIdentifier;
/*     */   }
/*     */ 
/*     */   public String aliasForAttribute(String attribute) {
/* 105 */     return attribute;
/*     */   }
/*     */ 
/*     */   public String attributeForAlias(String alias) {
/* 109 */     return alias;
/*     */   }
/*     */ 
/*     */   public String aliasForSystemAttribute(String attribute) {
/* 113 */     return attribute;
/*     */   }
/*     */ 
/*     */   public boolean isImmutableValueType(Class type) {
/* 117 */     return false;
/*     */   }
/*     */ 
/*     */   public String getFieldNameForItemTypeAndName(Class definedIn, Class itemType, String itemFieldName) {
/* 121 */     return null;
/*     */   }
/*     */ 
/*     */   public Class getItemTypeForItemFieldName(Class definedIn, String itemFieldName) {
/* 125 */     return null;
/*     */   }
/*     */ 
/*     */   public Mapper.ImplicitCollectionMapping getImplicitCollectionDefForFieldName(Class itemType, String fieldName) {
/* 129 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean shouldSerializeMember(Class definedIn, String fieldName) {
/* 133 */     return true;
/*     */   }
/*     */ 
/*     */   public String lookupName(Class type) {
/* 137 */     return serializedClass(type);
/*     */   }
/*     */ 
/*     */   public Class lookupType(String elementName) {
/* 141 */     return realClass(elementName);
/*     */   }
/*     */ 
/*     */   public String serializedMember(Class type, String memberName) {
/* 145 */     return memberName;
/*     */   }
/*     */ 
/*     */   public String realMember(Class type, String serialized) {
/* 149 */     return serialized;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public SingleValueConverter getConverterFromAttribute(String name)
/*     */   {
/* 156 */     return null;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public SingleValueConverter getConverterFromItemType(String fieldName, Class type)
/*     */   {
/* 163 */     return null;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public SingleValueConverter getConverterFromItemType(Class type)
/*     */   {
/* 170 */     return null;
/*     */   }
/*     */ 
/*     */   public SingleValueConverter getConverterFromItemType(String fieldName, Class type, Class definedIn)
/*     */   {
/* 175 */     return null;
/*     */   }
/*     */ 
/*     */   public Converter getLocalConverter(Class definedIn, String fieldName) {
/* 179 */     return null;
/*     */   }
/*     */ 
/*     */   public Mapper lookupMapperOfType(Class type) {
/* 183 */     return null;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public String aliasForAttribute(Class definedIn, String fieldName)
/*     */   {
/* 190 */     return fieldName;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public String attributeForAlias(Class definedIn, String alias)
/*     */   {
/* 197 */     return alias;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public SingleValueConverter getConverterFromAttribute(Class definedIn, String attribute)
/*     */   {
/* 204 */     return null;
/*     */   }
/*     */ 
/*     */   public SingleValueConverter getConverterFromAttribute(Class definedIn, String attribute, Class type) {
/* 208 */     return null;
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.mapper.DefaultMapper
 * JD-Core Version:    0.6.0
 */