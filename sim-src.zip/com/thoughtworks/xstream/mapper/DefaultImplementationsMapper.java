/*    */ package com.thoughtworks.xstream.mapper;
/*    */ 
/*    */ import com.thoughtworks.xstream.InitializationException;
/*    */ import com.thoughtworks.xstream.alias.ClassMapper;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class DefaultImplementationsMapper extends MapperWrapper
/*    */ {
/* 32 */   private final Map typeToImpl = new HashMap();
/* 33 */   private transient Map implToType = new HashMap();
/*    */ 
/*    */   public DefaultImplementationsMapper(Mapper wrapped) {
/* 36 */     super(wrapped);
/* 37 */     addDefaults();
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public DefaultImplementationsMapper(ClassMapper wrapped)
/*    */   {
/* 44 */     this(wrapped);
/*    */   }
/*    */ 
/*    */   protected void addDefaults()
/*    */   {
/* 49 */     addDefaultImplementation(null, Mapper.Null.class);
/*    */ 
/* 51 */     addDefaultImplementation(Boolean.class, Boolean.TYPE);
/* 52 */     addDefaultImplementation(Character.class, Character.TYPE);
/* 53 */     addDefaultImplementation(Integer.class, Integer.TYPE);
/* 54 */     addDefaultImplementation(Float.class, Float.TYPE);
/* 55 */     addDefaultImplementation(Double.class, Double.TYPE);
/* 56 */     addDefaultImplementation(Short.class, Short.TYPE);
/* 57 */     addDefaultImplementation(Byte.class, Byte.TYPE);
/* 58 */     addDefaultImplementation(Long.class, Long.TYPE);
/*    */   }
/*    */ 
/*    */   public void addDefaultImplementation(Class defaultImplementation, Class ofType) {
/* 62 */     if ((defaultImplementation != null) && (defaultImplementation.isInterface())) {
/* 63 */       throw new InitializationException("Default implementation is not a concrete class: " + defaultImplementation.getName());
/*    */     }
/*    */ 
/* 67 */     this.typeToImpl.put(ofType, defaultImplementation);
/* 68 */     this.implToType.put(defaultImplementation, ofType);
/*    */   }
/*    */ 
/*    */   public String serializedClass(Class type) {
/* 72 */     Class baseType = (Class)this.implToType.get(type);
/* 73 */     return baseType == null ? super.serializedClass(type) : super.serializedClass(baseType);
/*    */   }
/*    */ 
/*    */   public Class defaultImplementationOf(Class type) {
/* 77 */     if (this.typeToImpl.containsKey(type)) {
/* 78 */       return (Class)this.typeToImpl.get(type);
/*    */     }
/* 80 */     return super.defaultImplementationOf(type);
/*    */   }
/*    */ 
/*    */   private Object readResolve()
/*    */   {
/* 85 */     this.implToType = new HashMap();
/* 86 */     for (Iterator iter = this.typeToImpl.keySet().iterator(); iter.hasNext(); ) {
/* 87 */       Object type = iter.next();
/* 88 */       this.implToType.put(this.typeToImpl.get(type), type);
/*    */     }
/* 90 */     return this;
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.mapper.DefaultImplementationsMapper
 * JD-Core Version:    0.6.0
 */