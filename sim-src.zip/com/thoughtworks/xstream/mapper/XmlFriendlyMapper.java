/*    */ package com.thoughtworks.xstream.mapper;
/*    */ 
/*    */ import com.thoughtworks.xstream.alias.ClassMapper;
/*    */ 
/*    */ /** @deprecated */
/*    */ public class XmlFriendlyMapper extends AbstractXmlFriendlyMapper
/*    */ {
/*    */   /** @deprecated */
/*    */   public XmlFriendlyMapper(Mapper wrapped)
/*    */   {
/* 36 */     super(wrapped);
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public XmlFriendlyMapper(ClassMapper wrapped)
/*    */   {
/* 43 */     this(wrapped);
/*    */   }
/*    */ 
/*    */   public String serializedClass(Class type) {
/* 47 */     return escapeClassName(super.serializedClass(type));
/*    */   }
/*    */ 
/*    */   public Class realClass(String elementName) {
/* 51 */     return super.realClass(unescapeClassName(elementName));
/*    */   }
/*    */ 
/*    */   public String serializedMember(Class type, String memberName) {
/* 55 */     return escapeFieldName(super.serializedMember(type, memberName));
/*    */   }
/*    */ 
/*    */   public String realMember(Class type, String serialized) {
/* 59 */     return unescapeFieldName(super.realMember(type, serialized));
/*    */   }
/*    */ 
/*    */   public String mapNameToXML(String javaName) {
/* 63 */     return escapeFieldName(javaName);
/*    */   }
/*    */ 
/*    */   public String mapNameFromXML(String xmlName) {
/* 67 */     return unescapeFieldName(xmlName);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.mapper.XmlFriendlyMapper
 * JD-Core Version:    0.6.0
 */