package com.thoughtworks.xstream.mapper;

public abstract interface AnnotationConfiguration
{
  public abstract void autodetectAnnotations(boolean paramBoolean);

  public abstract void processAnnotations(Class[] paramArrayOfClass);
}

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.mapper.AnnotationConfiguration
 * JD-Core Version:    0.6.0
 */