/*     */ package com.thoughtworks.xstream.mapper;
/*     */ 
/*     */ import com.thoughtworks.xstream.alias.ClassMapper;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class ClassAliasingMapper extends MapperWrapper
/*     */ {
/*  28 */   private final Map typeToName = new HashMap();
/*  29 */   private final Map classToName = new HashMap();
/*  30 */   private transient Map nameToType = new HashMap();
/*     */ 
/*     */   public ClassAliasingMapper(Mapper wrapped) {
/*  33 */     super(wrapped);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public ClassAliasingMapper(ClassMapper wrapped)
/*     */   {
/*  40 */     this(wrapped);
/*     */   }
/*     */ 
/*     */   public void addClassAlias(String name, Class type) {
/*  44 */     this.nameToType.put(name, type.getName());
/*  45 */     this.classToName.put(type.getName(), name);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public void addClassAttributeAlias(String name, Class type)
/*     */   {
/*  52 */     addClassAlias(name, type);
/*     */   }
/*     */ 
/*     */   public void addTypeAlias(String name, Class type) {
/*  56 */     this.nameToType.put(name, type.getName());
/*  57 */     this.typeToName.put(type, name);
/*     */   }
/*     */ 
/*     */   public String serializedClass(Class type) {
/*  61 */     String alias = (String)this.classToName.get(type.getName());
/*  62 */     if (alias != null) {
/*  63 */       return alias;
/*     */     }
/*  65 */     for (Iterator iter = this.typeToName.keySet().iterator(); iter.hasNext(); ) {
/*  66 */       Class compatibleType = (Class)iter.next();
/*  67 */       if (compatibleType.isAssignableFrom(type)) {
/*  68 */         return (String)this.typeToName.get(compatibleType);
/*     */       }
/*     */     }
/*  71 */     return super.serializedClass(type);
/*     */   }
/*     */ 
/*     */   public Class realClass(String elementName)
/*     */   {
/*  76 */     String mappedName = (String)this.nameToType.get(elementName);
/*     */ 
/*  78 */     if (mappedName != null) {
/*  79 */       Class type = primitiveClassNamed(mappedName);
/*  80 */       if (type != null) {
/*  81 */         return type;
/*     */       }
/*  83 */       elementName = mappedName;
/*     */     }
/*     */ 
/*  86 */     return super.realClass(elementName);
/*     */   }
/*     */ 
/*     */   public boolean itemTypeAsAttribute(Class clazz) {
/*  90 */     return this.classToName.containsKey(clazz);
/*     */   }
/*     */ 
/*     */   public boolean aliasIsAttribute(String name) {
/*  94 */     return this.nameToType.containsKey(name);
/*     */   }
/*     */ 
/*     */   private Object readResolve() {
/*  98 */     this.nameToType = new HashMap();
/*  99 */     for (Iterator iter = this.classToName.keySet().iterator(); iter.hasNext(); ) {
/* 100 */       Object type = iter.next();
/* 101 */       this.nameToType.put(this.classToName.get(type), type);
/*     */     }
/* 103 */     for (Iterator iter = this.typeToName.keySet().iterator(); iter.hasNext(); ) {
/* 104 */       Class type = (Class)iter.next();
/* 105 */       this.nameToType.put(this.typeToName.get(type), type.getName());
/*     */     }
/* 107 */     return this;
/*     */   }
/*     */ 
/*     */   private Class primitiveClassNamed(String name) {
/* 111 */     return name.equals("double") ? Double.TYPE : name.equals("float") ? Float.TYPE : name.equals("long") ? Long.TYPE : name.equals("int") ? Integer.TYPE : name.equals("short") ? Short.TYPE : name.equals("char") ? Character.TYPE : name.equals("byte") ? Byte.TYPE : name.equals("boolean") ? Boolean.TYPE : name.equals("void") ? Void.TYPE : null;
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.mapper.ClassAliasingMapper
 * JD-Core Version:    0.6.0
 */