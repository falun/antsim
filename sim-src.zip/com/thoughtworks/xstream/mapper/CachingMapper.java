/*    */ package com.thoughtworks.xstream.mapper;
/*    */ 
/*    */ import com.thoughtworks.xstream.alias.ClassMapper;
/*    */ import java.lang.ref.WeakReference;
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class CachingMapper extends MapperWrapper
/*    */ {
/*    */   private transient Map realClassCache;
/*    */ 
/*    */   public CachingMapper(Mapper wrapped)
/*    */   {
/* 31 */     super(wrapped);
/* 32 */     readResolve();
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public CachingMapper(ClassMapper wrapped)
/*    */   {
/* 39 */     this(wrapped);
/* 40 */     readResolve();
/*    */   }
/*    */ 
/*    */   public Class realClass(String elementName) {
/* 44 */     WeakReference reference = (WeakReference)this.realClassCache.get(elementName);
/* 45 */     if (reference != null) {
/* 46 */       Class cached = (Class)reference.get();
/* 47 */       if (cached != null) {
/* 48 */         return cached;
/*    */       }
/*    */     }
/*    */ 
/* 52 */     Class result = super.realClass(elementName);
/* 53 */     this.realClassCache.put(elementName, new WeakReference(result));
/* 54 */     return result;
/*    */   }
/*    */ 
/*    */   private Object readResolve() {
/* 58 */     this.realClassCache = Collections.synchronizedMap(new HashMap(128));
/* 59 */     return this;
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.mapper.CachingMapper
 * JD-Core Version:    0.6.0
 */