/*    */ package com.thoughtworks.xstream.mapper;
/*    */ 
/*    */ import com.thoughtworks.xstream.alias.ClassMapper;
/*    */ import com.thoughtworks.xstream.core.util.FastField;
/*    */ import java.util.HashMap;
/*    */ import java.util.HashSet;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class FieldAliasingMapper extends MapperWrapper
/*    */ {
/* 30 */   protected final Map fieldToAliasMap = new HashMap();
/* 31 */   protected final Map aliasToFieldMap = new HashMap();
/* 32 */   protected final Set fieldsToOmit = new HashSet();
/*    */ 
/*    */   public FieldAliasingMapper(Mapper wrapped) {
/* 35 */     super(wrapped);
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public FieldAliasingMapper(ClassMapper wrapped)
/*    */   {
/* 42 */     this(wrapped);
/*    */   }
/*    */ 
/*    */   public void addFieldAlias(String alias, Class type, String fieldName) {
/* 46 */     this.fieldToAliasMap.put(key(type, fieldName), alias);
/* 47 */     this.aliasToFieldMap.put(key(type, alias), fieldName);
/*    */   }
/*    */ 
/*    */   private Object key(Class type, String name) {
/* 51 */     return new FastField(type, name);
/*    */   }
/*    */ 
/*    */   public String serializedMember(Class type, String memberName) {
/* 55 */     String alias = getMember(type, memberName, this.fieldToAliasMap);
/* 56 */     if (alias == null) {
/* 57 */       return super.serializedMember(type, memberName);
/*    */     }
/* 59 */     return alias;
/*    */   }
/*    */ 
/*    */   public String realMember(Class type, String serialized)
/*    */   {
/* 64 */     String real = getMember(type, serialized, this.aliasToFieldMap);
/* 65 */     if (real == null) {
/* 66 */       return super.realMember(type, serialized);
/*    */     }
/* 68 */     return real;
/*    */   }
/*    */ 
/*    */   private String getMember(Class type, String name, Map map)
/*    */   {
/* 73 */     String member = null;
/* 74 */     for (Class declaringType = type; (member == null) && (declaringType != Object.class); declaringType = declaringType.getSuperclass()) {
/* 75 */       member = (String)map.get(key(declaringType, name));
/*    */     }
/* 77 */     return member;
/*    */   }
/*    */ 
/*    */   public boolean shouldSerializeMember(Class definedIn, String fieldName) {
/* 81 */     return !this.fieldsToOmit.contains(key(definedIn, fieldName));
/*    */   }
/*    */ 
/*    */   public void omitField(Class definedIn, String fieldName) {
/* 85 */     this.fieldsToOmit.add(key(definedIn, fieldName));
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.mapper.FieldAliasingMapper
 * JD-Core Version:    0.6.0
 */