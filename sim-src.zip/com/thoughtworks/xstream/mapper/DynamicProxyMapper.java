/*    */ package com.thoughtworks.xstream.mapper;
/*    */ 
/*    */ import com.thoughtworks.xstream.alias.ClassMapper;
/*    */ import java.lang.reflect.Proxy;
/*    */ 
/*    */ public class DynamicProxyMapper extends MapperWrapper
/*    */ {
/*    */   private String alias;
/*    */ 
/*    */   public DynamicProxyMapper(Mapper wrapped)
/*    */   {
/* 29 */     this(wrapped, "dynamic-proxy");
/*    */   }
/*    */ 
/*    */   public DynamicProxyMapper(Mapper wrapped, String alias) {
/* 33 */     super(wrapped);
/* 34 */     this.alias = alias;
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public DynamicProxyMapper(ClassMapper wrapped)
/*    */   {
/* 41 */     this(wrapped);
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public DynamicProxyMapper(ClassMapper wrapped, String alias)
/*    */   {
/* 48 */     this(wrapped, alias);
/*    */   }
/*    */ 
/*    */   public String getAlias() {
/* 52 */     return this.alias;
/*    */   }
/*    */ 
/*    */   public void setAlias(String alias) {
/* 56 */     this.alias = alias;
/*    */   }
/*    */ 
/*    */   public String serializedClass(Class type) {
/* 60 */     if (Proxy.isProxyClass(type)) {
/* 61 */       return this.alias;
/*    */     }
/* 63 */     return super.serializedClass(type);
/*    */   }
/*    */ 
/*    */   public Class realClass(String elementName)
/*    */   {
/* 68 */     if (elementName.equals(this.alias)) {
/* 69 */       return DynamicProxy.class;
/*    */     }
/* 71 */     return super.realClass(elementName);
/*    */   }
/*    */ 
/*    */   public static class DynamicProxy
/*    */   {
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.mapper.DynamicProxyMapper
 * JD-Core Version:    0.6.0
 */