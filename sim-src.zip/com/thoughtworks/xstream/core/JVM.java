/*     */ package com.thoughtworks.xstream.core;
/*     */ 
/*     */ import com.thoughtworks.xstream.converters.reflection.PureJavaReflectionProvider;
/*     */ import com.thoughtworks.xstream.converters.reflection.ReflectionProvider;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.lang.reflect.Field;
/*     */ import java.security.AccessControlException;
/*     */ import java.text.AttributedString;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class JVM
/*     */ {
/*     */   private ReflectionProvider reflectionProvider;
/*  16 */   private transient Map loaderCache = new HashMap();
/*     */ 
/*  18 */   private final boolean supportsAWT = loadClass("java.awt.Color") != null;
/*  19 */   private final boolean supportsSwing = loadClass("javax.swing.LookAndFeel") != null;
/*  20 */   private final boolean supportsSQL = loadClass("java.sql.Date") != null;
/*     */ 
/*  22 */   private static final String vendor = System.getProperty("java.vm.vendor");
/*  23 */   private static final float majorJavaVersion = getMajorJavaVersion();
/*  24 */   private static final boolean reverseFieldOrder = (isHarmony()) || ((isIBM()) && (!is15()));
/*     */   static final float DEFAULT_JAVA_VERSION = 1.3F;
/*     */ 
/*     */   private static final float getMajorJavaVersion()
/*     */   {
/*     */     try
/*     */     {
/*  31 */       return Float.parseFloat(System.getProperty("java.specification.version"));
/*     */     } catch (NumberFormatException localNumberFormatException) {
/*     */     }
/*  34 */     return 1.3F;
/*     */   }
/*     */ 
/*     */   public static boolean is14()
/*     */   {
/*  39 */     return majorJavaVersion >= 1.4F;
/*     */   }
/*     */ 
/*     */   public static boolean is15() {
/*  43 */     return majorJavaVersion >= 1.5F;
/*     */   }
/*     */ 
/*     */   public static boolean is16() {
/*  47 */     return majorJavaVersion >= 1.6F;
/*     */   }
/*     */ 
/*     */   private static boolean isSun() {
/*  51 */     return (vendor.indexOf("Sun") != -1) || (vendor.indexOf("Oracle") != -1);
/*     */   }
/*     */ 
/*     */   private static boolean isApple() {
/*  55 */     return vendor.indexOf("Apple") != -1;
/*     */   }
/*     */ 
/*     */   private static boolean isHPUX() {
/*  59 */     return vendor.indexOf("Hewlett-Packard Company") != -1;
/*     */   }
/*     */ 
/*     */   private static boolean isIBM() {
/*  63 */     return vendor.indexOf("IBM") != -1;
/*     */   }
/*     */ 
/*     */   private static boolean isBlackdown() {
/*  67 */     return vendor.indexOf("Blackdown") != -1;
/*     */   }
/*     */ 
/*     */   private static boolean isDiablo() {
/*  71 */     return vendor.indexOf("FreeBSD Foundation") != -1;
/*     */   }
/*     */ 
/*     */   private static boolean isHarmony() {
/*  75 */     return vendor.indexOf("Apache Software Foundation") != -1;
/*     */   }
/*     */ 
/*     */   private static boolean isBEAWithUnsafeSupport()
/*     */   {
/*  80 */     if (vendor.indexOf("BEA") != -1)
/*     */     {
/*  82 */       String str1 = System.getProperty("java.vm.version");
/*  83 */       if (str1.startsWith("R"))
/*     */       {
/*  85 */         return true;
/*     */       }
/*     */ 
/*  88 */       String str2 = System.getProperty("java.vm.info");
/*  89 */       if (str2 != null)
/*     */       {
/*  91 */         return (str2.startsWith("R25.1")) || (str2.startsWith("R25.2"));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  96 */     return false;
/*     */   }
/*     */ 
/*     */   private static boolean isHitachi() {
/* 100 */     return vendor.indexOf("Hitachi") != -1;
/*     */   }
/*     */ 
/*     */   private static boolean isSAP() {
/* 104 */     return vendor.indexOf("SAP AG") != -1;
/*     */   }
/*     */ 
/*     */   public Class loadClass(String paramString) {
/*     */     try {
/* 109 */       WeakReference localWeakReference = (WeakReference)this.loaderCache.get(paramString);
/* 110 */       if (localWeakReference != null) {
/* 111 */         localClass = (Class)localWeakReference.get();
/* 112 */         if (localClass != null) {
/* 113 */           return localClass;
/*     */         }
/*     */       }
/*     */ 
/* 117 */       Class localClass = Class.forName(paramString, false, getClass().getClassLoader());
/* 118 */       this.loaderCache.put(paramString, new WeakReference(localClass));
/* 119 */       return localClass; } catch (ClassNotFoundException localClassNotFoundException) {
/*     */     }
/* 121 */     return null;
/*     */   }
/*     */ 
/*     */   public synchronized ReflectionProvider bestReflectionProvider()
/*     */   {
/* 126 */     if (this.reflectionProvider == null) {
/*     */       try
/*     */       {
/*     */         String str;
/* 128 */         if (canUseSun14ReflectionProvider()) {
/* 129 */           str = "com.thoughtworks.xstream.converters.reflection.Sun14ReflectionProvider";
/* 130 */           this.reflectionProvider = ((ReflectionProvider)loadClass(str).newInstance());
/* 131 */         } else if (canUseHarmonyReflectionProvider()) {
/* 132 */           str = "com.thoughtworks.xstream.converters.reflection.HarmonyReflectionProvider";
/* 133 */           this.reflectionProvider = ((ReflectionProvider)loadClass(str).newInstance());
/*     */         }
/* 135 */         if (this.reflectionProvider == null)
/* 136 */           this.reflectionProvider = new PureJavaReflectionProvider();
/*     */       }
/*     */       catch (InstantiationException localInstantiationException) {
/* 139 */         this.reflectionProvider = new PureJavaReflectionProvider();
/*     */       } catch (IllegalAccessException localIllegalAccessException) {
/* 141 */         this.reflectionProvider = new PureJavaReflectionProvider();
/*     */       }
/*     */       catch (AccessControlException localAccessControlException) {
/* 144 */         this.reflectionProvider = new PureJavaReflectionProvider();
/*     */       }
/*     */     }
/* 147 */     return this.reflectionProvider;
/*     */   }
/*     */ 
/*     */   private boolean canUseSun14ReflectionProvider() {
/* 151 */     return ((isSun()) || (isApple()) || (isHPUX()) || (isIBM()) || (isBlackdown()) || (isBEAWithUnsafeSupport()) || (isHitachi()) || (isSAP()) || (isDiablo())) && (is14()) && (loadClass("sun.misc.Unsafe") != null);
/*     */   }
/*     */ 
/*     */   private boolean canUseHarmonyReflectionProvider()
/*     */   {
/* 156 */     return isHarmony();
/*     */   }
/*     */ 
/*     */   public static boolean reverseFieldDefinition() {
/* 160 */     return reverseFieldOrder;
/*     */   }
/*     */ 
/*     */   public boolean supportsAWT()
/*     */   {
/* 165 */     return this.supportsAWT;
/*     */   }
/*     */ 
/*     */   public boolean supportsSwing()
/*     */   {
/* 170 */     return this.supportsSwing;
/*     */   }
/*     */ 
/*     */   public boolean supportsSQL()
/*     */   {
/* 175 */     return this.supportsSQL;
/*     */   }
/*     */ 
/*     */   private Object readResolve() {
/* 179 */     this.loaderCache = new HashMap();
/* 180 */     return this;
/*     */   }
/*     */ 
/*     */   public static void main(String[] paramArrayOfString) {
/* 184 */     boolean bool = false;
/* 185 */     Field[] arrayOfField = AttributedString.class.getDeclaredFields();
/* 186 */     for (int i = 0; i < arrayOfField.length; i++) {
/* 187 */       if (arrayOfField[i].getName().equals("text")) {
/* 188 */         bool = i > 3;
/* 189 */         break;
/*     */       }
/*     */     }
/* 192 */     if (bool) {
/* 193 */       arrayOfField = JVM.class.getDeclaredFields();
/* 194 */       for (i = 0; i < arrayOfField.length; i++) {
/* 195 */         if (arrayOfField[i].getName().equals("reflectionProvider")) {
/* 196 */           bool = i > 2;
/* 197 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 202 */     JVM localJVM = new JVM();
/* 203 */     System.out.println("XStream JVM diagnostics");
/* 204 */     System.out.println(new StringBuilder().append("java.specification.version: ").append(System.getProperty("java.specification.version")).toString());
/* 205 */     System.out.println(new StringBuilder().append("java.vm.vendor: ").append(vendor).toString());
/* 206 */     System.out.println(new StringBuilder().append("Version: ").append(majorJavaVersion).toString());
/* 207 */     System.out.println(new StringBuilder().append("XStream support for enhanced Mode: ").append((localJVM.canUseSun14ReflectionProvider()) || (localJVM.canUseHarmonyReflectionProvider())).toString());
/* 208 */     System.out.println(new StringBuilder().append("Supports AWT: ").append(localJVM.supportsAWT()).toString());
/* 209 */     System.out.println(new StringBuilder().append("Supports Swing: ").append(localJVM.supportsSwing()).toString());
/* 210 */     System.out.println(new StringBuilder().append("Supports SQL: ").append(localJVM.supportsSQL()).toString());
/* 211 */     System.out.println(new StringBuilder().append("Reverse field order detected (may have failed): ").append(bool).toString());
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.core.JVM
 * JD-Core Version:    0.6.0
 */