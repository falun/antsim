/*    */ package com.thoughtworks.xstream.core;
/*    */ 
/*    */ import com.thoughtworks.xstream.alias.ClassMapper;
/*    */ import com.thoughtworks.xstream.converters.ConverterLookup;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*    */ import com.thoughtworks.xstream.io.path.Path;
/*    */ import com.thoughtworks.xstream.mapper.Mapper;
/*    */ 
/*    */ public class ReferenceByIdMarshaller extends AbstractReferenceMarshaller
/*    */ {
/*    */   private final IDGenerator idGenerator;
/*    */ 
/*    */   public ReferenceByIdMarshaller(HierarchicalStreamWriter writer, ConverterLookup converterLookup, Mapper mapper, IDGenerator idGenerator)
/*    */   {
/* 32 */     super(writer, converterLookup, mapper);
/* 33 */     this.idGenerator = idGenerator;
/*    */   }
/*    */ 
/*    */   public ReferenceByIdMarshaller(HierarchicalStreamWriter writer, ConverterLookup converterLookup, Mapper mapper)
/*    */   {
/* 39 */     this(writer, converterLookup, mapper, new SequenceGenerator(1));
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public ReferenceByIdMarshaller(HierarchicalStreamWriter writer, ConverterLookup converterLookup, ClassMapper classMapper, IDGenerator idGenerator)
/*    */   {
/* 49 */     this(writer, converterLookup, classMapper, idGenerator);
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public ReferenceByIdMarshaller(HierarchicalStreamWriter writer, ConverterLookup converterLookup, ClassMapper classMapper)
/*    */   {
/* 58 */     this(writer, converterLookup, classMapper);
/*    */   }
/*    */ 
/*    */   protected String createReference(Path currentPath, Object existingReferenceKey) {
/* 62 */     return existingReferenceKey.toString();
/*    */   }
/*    */ 
/*    */   protected Object createReferenceKey(Path currentPath, Object item) {
/* 66 */     return this.idGenerator.next(item);
/*    */   }
/*    */ 
/*    */   protected void fireValidReference(Object referenceKey) {
/* 70 */     String attributeName = getMapper().aliasForSystemAttribute("id");
/* 71 */     if (attributeName != null)
/* 72 */       this.writer.addAttribute(attributeName, referenceKey.toString());
/*    */   }
/*    */ 
/*    */   public static abstract interface IDGenerator
/*    */   {
/*    */     public abstract String next(Object paramObject);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.core.ReferenceByIdMarshaller
 * JD-Core Version:    0.6.0
 */