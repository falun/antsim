/*    */ package com.thoughtworks.xstream.core;
/*    */ 
/*    */ public class SequenceGenerator
/*    */   implements ReferenceByIdMarshaller.IDGenerator
/*    */ {
/*    */   private int counter;
/*    */ 
/*    */   public SequenceGenerator(int startsAt)
/*    */   {
/* 19 */     this.counter = startsAt;
/*    */   }
/*    */ 
/*    */   public String next(Object item) {
/* 23 */     return String.valueOf(this.counter++);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.core.SequenceGenerator
 * JD-Core Version:    0.6.0
 */