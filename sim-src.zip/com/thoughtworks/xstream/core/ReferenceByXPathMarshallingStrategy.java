/*    */ package com.thoughtworks.xstream.core;
/*    */ 
/*    */ import com.thoughtworks.xstream.converters.ConverterLookup;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*    */ import com.thoughtworks.xstream.mapper.Mapper;
/*    */ 
/*    */ public class ReferenceByXPathMarshallingStrategy extends AbstractTreeMarshallingStrategy
/*    */ {
/* 21 */   public static int RELATIVE = 0;
/* 22 */   public static int ABSOLUTE = 1;
/*    */   private final int mode;
/*    */ 
/*    */   /** @deprecated */
/*    */   public ReferenceByXPathMarshallingStrategy()
/*    */   {
/* 29 */     this(RELATIVE);
/*    */   }
/*    */ 
/*    */   public ReferenceByXPathMarshallingStrategy(int mode) {
/* 33 */     this.mode = mode;
/*    */   }
/*    */ 
/*    */   protected TreeUnmarshaller createUnmarshallingContext(Object root, HierarchicalStreamReader reader, ConverterLookup converterLookup, Mapper mapper)
/*    */   {
/* 38 */     return new ReferenceByXPathUnmarshaller(root, reader, converterLookup, mapper);
/*    */   }
/*    */ 
/*    */   protected TreeMarshaller createMarshallingContext(HierarchicalStreamWriter writer, ConverterLookup converterLookup, Mapper mapper)
/*    */   {
/* 43 */     return new ReferenceByXPathMarshaller(writer, converterLookup, mapper, this.mode);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.core.ReferenceByXPathMarshallingStrategy
 * JD-Core Version:    0.6.0
 */