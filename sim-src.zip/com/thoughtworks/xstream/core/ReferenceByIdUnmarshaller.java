/*    */ package com.thoughtworks.xstream.core;
/*    */ 
/*    */ import com.thoughtworks.xstream.alias.ClassMapper;
/*    */ import com.thoughtworks.xstream.converters.ConverterLookup;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*    */ import com.thoughtworks.xstream.mapper.Mapper;
/*    */ 
/*    */ public class ReferenceByIdUnmarshaller extends AbstractReferenceUnmarshaller
/*    */ {
/*    */   public ReferenceByIdUnmarshaller(Object root, HierarchicalStreamReader reader, ConverterLookup converterLookup, Mapper mapper)
/*    */   {
/* 23 */     super(root, reader, converterLookup, mapper);
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public ReferenceByIdUnmarshaller(Object root, HierarchicalStreamReader reader, ConverterLookup converterLookup, ClassMapper classMapper)
/*    */   {
/* 31 */     this(root, reader, converterLookup, classMapper);
/*    */   }
/*    */ 
/*    */   protected Object getReferenceKey(String reference) {
/* 35 */     return reference;
/*    */   }
/*    */ 
/*    */   protected Object getCurrentReferenceKey() {
/* 39 */     String attributeName = getMapper().aliasForSystemAttribute("id");
/* 40 */     return attributeName == null ? null : this.reader.getAttribute(attributeName);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.core.ReferenceByIdUnmarshaller
 * JD-Core Version:    0.6.0
 */