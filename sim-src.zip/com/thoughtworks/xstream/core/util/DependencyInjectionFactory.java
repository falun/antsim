/*     */ package com.thoughtworks.xstream.core.util;
/*     */ 
/*     */ import com.thoughtworks.xstream.converters.reflection.ObjectAccessException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class DependencyInjectionFactory
/*     */ {
/*     */   public static Object newInstance(Class type, Object[] dependencies)
/*     */   {
/*  45 */     Constructor[] ctors = type.getConstructors();
/*  46 */     if (ctors.length > 1) {
/*  47 */       Arrays.sort(ctors, new Comparator() {
/*     */         public int compare(Object o1, Object o2) {
/*  49 */           return ((Constructor)o2).getParameterTypes().length - ((Constructor)o1).getParameterTypes().length;
/*     */         }
/*     */       });
/*     */     }
/*  54 */     TypedValue[] typedDependencies = new TypedValue[dependencies.length];
/*  55 */     for (int i = 0; i < dependencies.length; i++) {
/*  56 */       Object dependency = dependencies[i];
/*  57 */       Class depType = dependency.getClass();
/*  58 */       if (depType.isPrimitive()) {
/*  59 */         depType = Primitives.box(depType);
/*  60 */       } else if (depType == TypedNull.class) {
/*  61 */         depType = ((TypedNull)dependency).getType();
/*  62 */         dependency = null;
/*     */       }
/*     */ 
/*  65 */       typedDependencies[i] = new TypedValue(depType, dependency);
/*     */     }
/*     */ 
/*  68 */     Constructor bestMatchingCtor = null;
/*  69 */     Constructor possibleCtor = null;
/*  70 */     int arity = 2147483647;
/*  71 */     List matchingDependencies = new ArrayList();
/*  72 */     for (int i = 0; (bestMatchingCtor == null) && (i < ctors.length); i++) {
/*  73 */       Constructor constructor = ctors[i];
/*  74 */       Class[] parameterTypes = constructor.getParameterTypes();
/*  75 */       if (parameterTypes.length > dependencies.length)
/*     */         continue;
/*  77 */       if (parameterTypes.length == 0) {
/*  78 */         bestMatchingCtor = constructor;
/*  79 */         break;
/*     */       }
/*  81 */       if (arity > parameterTypes.length) {
/*  82 */         if (possibleCtor != null) {
/*  83 */           bestMatchingCtor = possibleCtor;
/*     */         }
/*     */         else
/*  86 */           arity = parameterTypes.length;
/*     */       }
/*     */       else {
/*  89 */         for (int j = 0; j < parameterTypes.length; j++) {
/*  90 */           if (parameterTypes[j].isPrimitive()) {
/*  91 */             parameterTypes[j] = Primitives.box(parameterTypes[j]);
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*  97 */         matchingDependencies.clear();
/*  98 */         int j = 0; int k = 0;
/*  99 */         for (; (j < parameterTypes.length) && (parameterTypes.length + k - j <= typedDependencies.length); k++) {
/* 100 */           if (parameterTypes[j].isAssignableFrom(typedDependencies[k].type)) {
/* 101 */             matchingDependencies.add(typedDependencies[k].value);
/* 102 */             j++; if (j == parameterTypes.length) {
/* 103 */               bestMatchingCtor = constructor;
/* 104 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 109 */         if ((bestMatchingCtor == null) && (possibleCtor == null)) {
/* 110 */           possibleCtor = constructor;
/*     */ 
/* 113 */           TypedValue[] deps = new TypedValue[typedDependencies.length];
/* 114 */           System.arraycopy(typedDependencies, 0, deps, 0, deps.length);
/* 115 */           matchingDependencies.clear();
/* 116 */           for (int j = 0; j < parameterTypes.length; j++) {
/* 117 */             int assignable = -1;
/* 118 */             for (int k = 0; k < deps.length; k++) {
/* 119 */               if (deps[k] == null) {
/*     */                 continue;
/*     */               }
/* 122 */               if (deps[k].type == parameterTypes[j]) {
/* 123 */                 assignable = k;
/*     */ 
/* 125 */                 break;
/* 126 */               }if (!parameterTypes[j].isAssignableFrom(deps[k].type))
/*     */                 continue;
/* 128 */               if ((assignable < 0) || (deps[assignable].type.isAssignableFrom(deps[k].type))) {
/* 129 */                 assignable = k;
/*     */               }
/*     */ 
/*     */             }
/*     */ 
/* 134 */             if (assignable >= 0) {
/* 135 */               matchingDependencies.add(deps[assignable].value);
/* 136 */               deps[assignable] = null;
/*     */             } else {
/* 138 */               possibleCtor = null;
/* 139 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 145 */     if (bestMatchingCtor == null) {
/* 146 */       if (possibleCtor == null) {
/* 147 */         throw new ObjectAccessException("Cannot construct " + type.getName() + ", none of the dependencies match any constructor's parameters");
/*     */       }
/*     */ 
/* 151 */       bestMatchingCtor = possibleCtor;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 156 */       return bestMatchingCtor.newInstance(matchingDependencies.toArray());
/*     */     } catch (InstantiationException e) {
/* 158 */       throw new ObjectAccessException("Cannot construct " + type.getName(), e);
/*     */     } catch (IllegalAccessException e) {
/* 160 */       throw new ObjectAccessException("Cannot construct " + type.getName(), e); } catch (InvocationTargetException e) {
/*     */     }
/* 162 */     throw new ObjectAccessException("Cannot construct " + type.getName(), e);
/*     */   }
/*     */ 
/*     */   private static class TypedValue {
/*     */     final Class type;
/*     */     final Object value;
/*     */ 
/*     */     public TypedValue(Class type, Object value) {
/* 172 */       this.type = type;
/* 173 */       this.value = value;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.core.util.DependencyInjectionFactory
 * JD-Core Version:    0.6.0
 */