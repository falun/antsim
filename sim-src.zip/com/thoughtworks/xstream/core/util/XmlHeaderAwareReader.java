/*     */ package com.thoughtworks.xstream.core.util;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PushbackInputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ public final class XmlHeaderAwareReader extends Reader
/*     */ {
/*     */   private final InputStreamReader reader;
/*     */   private final double version;
/*     */   private static final String KEY_ENCODING = "encoding";
/*     */   private static final String KEY_VERSION = "version";
/*     */   private static final String XML_TOKEN = "?xml";
/*     */   private static final int STATE_START = 0;
/*     */   private static final int STATE_AWAIT_XML_HEADER = 1;
/*     */   private static final int STATE_ATTR_NAME = 2;
/*     */   private static final int STATE_ATTR_VALUE = 3;
/*     */ 
/*     */   public XmlHeaderAwareReader(InputStream in)
/*     */     throws UnsupportedEncodingException, IOException
/*     */   {
/*  57 */     PushbackInputStream[] pin = { (in instanceof PushbackInputStream) ? (PushbackInputStream)in : new PushbackInputStream(in, 64) };
/*     */ 
/*  60 */     Map header = getHeader(pin);
/*  61 */     this.version = Double.parseDouble((String)header.get("version"));
/*  62 */     this.reader = new InputStreamReader(pin[0], (String)header.get("encoding"));
/*     */   }
/*     */ 
/*     */   private Map getHeader(PushbackInputStream[] in) throws IOException {
/*  66 */     Map header = new HashMap();
/*  67 */     header.put("encoding", "utf-8");
/*  68 */     header.put("version", "1.0");
/*     */ 
/*  70 */     int state = 0;
/*  71 */     ByteArrayOutputStream out = new ByteArrayOutputStream(64);
/*  72 */     int i = 0;
/*  73 */     char ch = '\000';
/*  74 */     char valueEnd = '\000';
/*  75 */     StringBuffer name = new StringBuffer();
/*  76 */     StringBuffer value = new StringBuffer();
/*  77 */     boolean escape = false;
/*  78 */     while ((i != -1) && ((i = in[0].read()) != -1)) {
/*  79 */       out.write(i);
/*  80 */       ch = (char)i;
/*  81 */       switch (state) {
/*     */       case 0:
/*  83 */         if (Character.isWhitespace(ch)) break;
/*  84 */         if (ch == '<')
/*  85 */           state = 1;
/*     */         else
/*  87 */           i = -1; break;
/*     */       case 1:
/*  92 */         if (!Character.isWhitespace(ch)) {
/*  93 */           name.append(Character.toLowerCase(ch));
/*  94 */           if ("?xml".startsWith(name.substring(0))) break;
/*  95 */           i = -1;
/*     */         }
/*  98 */         else if (name.toString().equals("?xml")) {
/*  99 */           state = 2;
/* 100 */           name.setLength(0);
/*     */         } else {
/* 102 */           i = -1;
/*     */         }
/*     */ 
/* 105 */         break;
/*     */       case 2:
/* 107 */         if (!Character.isWhitespace(ch)) {
/* 108 */           if (ch == '=') {
/* 109 */             state = 3;
/*     */           } else {
/* 111 */             ch = Character.toLowerCase(ch);
/* 112 */             if (Character.isLetter(ch))
/* 113 */               name.append(ch);
/*     */             else
/* 115 */               i = -1;
/*     */           }
/*     */         } else {
/* 118 */           if (name.length() <= 0) break;
/* 119 */           i = -1; } break;
/*     */       case 3:
/* 123 */         if (valueEnd == 0) {
/* 124 */           if ((ch == '"') || (ch == '\''))
/* 125 */             valueEnd = ch;
/*     */           else {
/* 127 */             i = -1;
/*     */           }
/*     */         }
/* 130 */         else if ((ch == '\\') && (!escape)) {
/* 131 */           escape = true;
/*     */         }
/* 134 */         else if ((ch == valueEnd) && (!escape)) {
/* 135 */           valueEnd = '\000';
/* 136 */           state = 2;
/* 137 */           header.put(name.toString(), value.toString());
/* 138 */           name.setLength(0);
/* 139 */           value.setLength(0);
/*     */         } else {
/* 141 */           escape = false;
/* 142 */           if (ch != '\n')
/* 143 */             value.append(ch);
/*     */           else {
/* 145 */             i = -1;
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 153 */     byte[] pushbackData = out.toByteArray();
/* 154 */     for (i = pushbackData.length; i-- > 0; ) {
/* 155 */       byte b = pushbackData[i];
/*     */       try {
/* 157 */         in[0].unread(b);
/*     */       } catch (IOException ex) {
/* 159 */         i++; in[0] = new PushbackInputStream(in[0], i);
/*     */       }
/*     */     }
/* 162 */     return header;
/*     */   }
/*     */ 
/*     */   public String getEncoding()
/*     */   {
/* 170 */     return this.reader.getEncoding();
/*     */   }
/*     */ 
/*     */   public double getVersion()
/*     */   {
/* 178 */     return this.version;
/*     */   }
/*     */ 
/*     */   public void mark(int readAheadLimit)
/*     */     throws IOException
/*     */   {
/* 185 */     this.reader.mark(readAheadLimit);
/*     */   }
/*     */ 
/*     */   public boolean markSupported()
/*     */   {
/* 192 */     return this.reader.markSupported();
/*     */   }
/*     */ 
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/* 199 */     return this.reader.read();
/*     */   }
/*     */ 
/*     */   public int read(char[] cbuf, int offset, int length)
/*     */     throws IOException
/*     */   {
/* 206 */     return this.reader.read(cbuf, offset, length);
/*     */   }
/*     */ 
/*     */   public int read(char[] cbuf)
/*     */     throws IOException
/*     */   {
/* 213 */     return this.reader.read(cbuf);
/*     */   }
/*     */ 
/*     */   public boolean ready()
/*     */     throws IOException
/*     */   {
/* 225 */     return this.reader.ready();
/*     */   }
/*     */ 
/*     */   public void reset()
/*     */     throws IOException
/*     */   {
/* 232 */     this.reader.reset();
/*     */   }
/*     */ 
/*     */   public long skip(long n)
/*     */     throws IOException
/*     */   {
/* 239 */     return this.reader.skip(n);
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 246 */     this.reader.close();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 253 */     return this.reader.equals(obj);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 260 */     return this.reader.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 267 */     return this.reader.toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.core.util.XmlHeaderAwareReader
 * JD-Core Version:    0.6.0
 */