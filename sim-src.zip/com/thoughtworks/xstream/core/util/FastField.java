/*    */ package com.thoughtworks.xstream.core.util;
/*    */ 
/*    */ public final class FastField
/*    */ {
/*    */   private final String name;
/*    */   private final Class declaringClass;
/*    */ 
/*    */   public FastField(Class definedIn, String name)
/*    */   {
/* 18 */     this.name = name;
/* 19 */     this.declaringClass = definedIn;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 23 */     return this.name;
/*    */   }
/*    */ 
/*    */   public Class getDeclaringClass() {
/* 27 */     return this.declaringClass;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj) {
/* 31 */     if (this == obj) {
/* 32 */       return true;
/*    */     }
/* 34 */     if (this == null) {
/* 35 */       return false;
/*    */     }
/* 37 */     if (obj.getClass() == FastField.class) {
/* 38 */       FastField field = (FastField)obj;
/* 39 */       return (this.name.equals(field.getName())) && (this.declaringClass.equals(field.getDeclaringClass()));
/*    */     }
/*    */ 
/* 42 */     return false;
/*    */   }
/*    */ 
/*    */   public int hashCode() {
/* 46 */     return this.name.hashCode() ^ this.declaringClass.hashCode();
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 50 */     return this.declaringClass.getName() + "[" + this.name + "]";
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.core.util.FastField
 * JD-Core Version:    0.6.0
 */