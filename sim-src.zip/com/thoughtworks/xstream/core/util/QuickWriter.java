/*    */ package com.thoughtworks.xstream.core.util;
/*    */ 
/*    */ import com.thoughtworks.xstream.io.StreamException;
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ 
/*    */ public class QuickWriter
/*    */ {
/*    */   private final Writer writer;
/*    */   private char[] buffer;
/*    */   private int pointer;
/*    */ 
/*    */   public QuickWriter(Writer writer)
/*    */   {
/* 26 */     this(writer, 1024);
/*    */   }
/*    */ 
/*    */   public QuickWriter(Writer writer, int bufferSize) {
/* 30 */     this.writer = writer;
/* 31 */     this.buffer = new char[bufferSize];
/*    */   }
/*    */ 
/*    */   public void write(String str) {
/* 35 */     int len = str.length();
/* 36 */     if (this.pointer + len >= this.buffer.length) {
/* 37 */       flush();
/* 38 */       if (len > this.buffer.length) {
/* 39 */         raw(str.toCharArray());
/* 40 */         return;
/*    */       }
/*    */     }
/* 43 */     str.getChars(0, len, this.buffer, this.pointer);
/* 44 */     this.pointer += len;
/*    */   }
/*    */ 
/*    */   public void write(char c) {
/* 48 */     if (this.pointer + 1 >= this.buffer.length) {
/* 49 */       flush();
/*    */     }
/* 51 */     this.buffer[(this.pointer++)] = c;
/*    */   }
/*    */ 
/*    */   public void write(char[] c) {
/* 55 */     int len = c.length;
/* 56 */     if (this.pointer + len >= this.buffer.length) {
/* 57 */       flush();
/* 58 */       if (len > this.buffer.length) {
/* 59 */         raw(c);
/* 60 */         return;
/*    */       }
/*    */     }
/* 63 */     System.arraycopy(c, 0, this.buffer, this.pointer, len);
/* 64 */     this.pointer += len;
/*    */   }
/*    */ 
/*    */   public void flush() {
/*    */     try {
/* 69 */       this.writer.write(this.buffer, 0, this.pointer);
/* 70 */       this.pointer = 0;
/* 71 */       this.writer.flush();
/*    */     } catch (IOException e) {
/* 73 */       throw new StreamException(e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void close() {
/*    */     try {
/* 79 */       this.writer.write(this.buffer, 0, this.pointer);
/* 80 */       this.pointer = 0;
/* 81 */       this.writer.close();
/*    */     } catch (IOException e) {
/* 83 */       throw new StreamException(e);
/*    */     }
/*    */   }
/*    */ 
/*    */   private void raw(char[] c) {
/*    */     try {
/* 89 */       this.writer.write(c);
/* 90 */       this.writer.flush();
/*    */     } catch (IOException e) {
/* 92 */       throw new StreamException(e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.core.util.QuickWriter
 * JD-Core Version:    0.6.0
 */