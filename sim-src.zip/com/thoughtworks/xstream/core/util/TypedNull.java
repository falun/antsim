/*    */ package com.thoughtworks.xstream.core.util;
/*    */ 
/*    */ public class TypedNull
/*    */ {
/*    */   private final Class type;
/*    */ 
/*    */   public TypedNull(Class type)
/*    */   {
/* 26 */     this.type = type;
/*    */   }
/*    */ 
/*    */   public Class getType()
/*    */   {
/* 31 */     return this.type;
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.core.util.TypedNull
 * JD-Core Version:    0.6.0
 */