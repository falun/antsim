/*    */ package com.thoughtworks.xstream.core.util;
/*    */ 
/*    */ import com.thoughtworks.xstream.converters.reflection.ObjectAccessException;
/*    */ import java.beans.PropertyEditor;
/*    */ 
/*    */ public class ThreadSafePropertyEditor
/*    */ {
/*    */   private final Class editorType;
/*    */   private final Pool pool;
/*    */ 
/*    */   public ThreadSafePropertyEditor(Class type, int initialPoolSize, int maxPoolSize)
/*    */   {
/* 39 */     if (!PropertyEditor.class.isAssignableFrom(type)) {
/* 40 */       throw new IllegalArgumentException(type.getName() + " is not a " + PropertyEditor.class.getName());
/*    */     }
/*    */ 
/* 44 */     this.editorType = type;
/* 45 */     this.pool = new Pool(initialPoolSize, maxPoolSize, new Pool.Factory() {
/*    */       public Object newInstance() {
/*    */         try {
/* 48 */           return ThreadSafePropertyEditor.this.editorType.newInstance();
/*    */         } catch (InstantiationException e) {
/* 50 */           throw new ObjectAccessException("Could not call default constructor of " + ThreadSafePropertyEditor.this.editorType.getName(), e);
/*    */         } catch (IllegalAccessException e) {
/*    */         }
/* 53 */         throw new ObjectAccessException("Could not call default constructor of " + ThreadSafePropertyEditor.this.editorType.getName(), e);
/*    */       }
/*    */     });
/*    */   }
/*    */ 
/*    */   public String getAsText(Object object)
/*    */   {
/* 62 */     PropertyEditor editor = fetchFromPool();
/*    */     try {
/* 64 */       editor.setValue(object);
/* 65 */       String str = editor.getAsText();
/*    */       return str; } finally { this.pool.putInPool(editor); } throw localObject;
/*    */   }
/*    */ 
/*    */   public Object setAsText(String str)
/*    */   {
/* 72 */     PropertyEditor editor = fetchFromPool();
/*    */     try {
/* 74 */       editor.setAsText(str);
/* 75 */       Object localObject1 = editor.getValue();
/*    */       return localObject1; } finally { this.pool.putInPool(editor); } throw localObject2;
/*    */   }
/*    */ 
/*    */   private PropertyEditor fetchFromPool()
/*    */   {
/* 82 */     PropertyEditor editor = (PropertyEditor)this.pool.fetchFromPool();
/* 83 */     return editor;
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.core.util.ThreadSafePropertyEditor
 * JD-Core Version:    0.6.0
 */