/*     */ package com.thoughtworks.xstream.core.util;
/*     */ 
/*     */ import com.thoughtworks.xstream.converters.ConversionException;
/*     */ import com.thoughtworks.xstream.converters.DataHolder;
/*     */ import java.io.IOException;
/*     */ import java.io.InvalidObjectException;
/*     */ import java.io.NotActiveException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectInputStream.GetField;
/*     */ import java.io.ObjectInputValidation;
/*     */ import java.io.ObjectStreamClass;
/*     */ import java.io.StreamCorruptedException;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class CustomObjectInputStream extends ObjectInputStream
/*     */ {
/*  28 */   private FastStack callbacks = new FastStack(1);
/*     */ 
/*  30 */   private static final String DATA_HOLDER_KEY = CustomObjectInputStream.class.getName();
/*     */ 
/*     */   public static synchronized CustomObjectInputStream getInstance(DataHolder whereFrom, StreamCallback callback)
/*     */   {
/*     */     try
/*     */     {
/*  42 */       CustomObjectInputStream result = (CustomObjectInputStream)whereFrom.get(DATA_HOLDER_KEY);
/*  43 */       if (result == null) {
/*  44 */         result = new CustomObjectInputStream(callback);
/*  45 */         whereFrom.put(DATA_HOLDER_KEY, result);
/*     */       } else {
/*  47 */         result.pushCallback(callback);
/*     */       }
/*  49 */       return result; } catch (IOException e) {
/*     */     }
/*  51 */     throw new ConversionException("Cannot create CustomObjectStream", e);
/*     */   }
/*     */ 
/*     */   public CustomObjectInputStream(StreamCallback callback)
/*     */     throws IOException, SecurityException
/*     */   {
/*  63 */     this.callbacks.push(callback);
/*     */   }
/*     */ 
/*     */   public void pushCallback(StreamCallback callback)
/*     */   {
/*  70 */     this.callbacks.push(callback);
/*     */   }
/*     */ 
/*     */   public StreamCallback popCallback() {
/*  74 */     return (StreamCallback)this.callbacks.pop();
/*     */   }
/*     */ 
/*     */   public StreamCallback peekCallback() {
/*  78 */     return (StreamCallback)this.callbacks.peek();
/*     */   }
/*     */ 
/*     */   public void defaultReadObject() throws IOException {
/*  82 */     peekCallback().defaultReadObject();
/*     */   }
/*     */ 
/*     */   protected Object readObjectOverride() throws IOException {
/*  86 */     return peekCallback().readFromStream();
/*     */   }
/*     */ 
/*     */   public Object readUnshared() throws IOException, ClassNotFoundException {
/*  90 */     return readObject();
/*     */   }
/*     */ 
/*     */   public boolean readBoolean() throws IOException {
/*  94 */     return ((Boolean)peekCallback().readFromStream()).booleanValue();
/*     */   }
/*     */ 
/*     */   public byte readByte() throws IOException {
/*  98 */     return ((Byte)peekCallback().readFromStream()).byteValue();
/*     */   }
/*     */ 
/*     */   public int readUnsignedByte() throws IOException {
/* 102 */     int b = ((Byte)peekCallback().readFromStream()).byteValue();
/* 103 */     if (b < 0) {
/* 104 */       b += 127;
/*     */     }
/* 106 */     return b;
/*     */   }
/*     */ 
/*     */   public int readInt() throws IOException {
/* 110 */     return ((Integer)peekCallback().readFromStream()).intValue();
/*     */   }
/*     */ 
/*     */   public char readChar() throws IOException {
/* 114 */     return ((Character)peekCallback().readFromStream()).charValue();
/*     */   }
/*     */ 
/*     */   public float readFloat() throws IOException {
/* 118 */     return ((Float)peekCallback().readFromStream()).floatValue();
/*     */   }
/*     */ 
/*     */   public double readDouble() throws IOException {
/* 122 */     return ((Double)peekCallback().readFromStream()).doubleValue();
/*     */   }
/*     */ 
/*     */   public long readLong() throws IOException {
/* 126 */     return ((Long)peekCallback().readFromStream()).longValue();
/*     */   }
/*     */ 
/*     */   public short readShort() throws IOException {
/* 130 */     return ((Short)peekCallback().readFromStream()).shortValue(); } 
/*     */   // ERROR //
/*     */   public int readUnsignedShort() throws IOException { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokevirtual 24	com/thoughtworks/xstream/core/util/CustomObjectInputStream:peekCallback	()Lcom/thoughtworks/xstream/core/util/CustomObjectInputStream$StreamCallback;
/*     */     //   4: invokeinterface 26 1 0
/*     */     //   9: checkcast 42	java/lang/Short
/*     */     //   12: invokevirtual 43	java/lang/Short:shortValue	()S
/*     */     //   15: istore_1
/*     */     //   16: iload_1
/*     */     //   17: ifge +9 -> 26
/*     */     //   20: wide
/*     */     //   26: iload_1
/*     */     //   27: ireturn } 
/* 142 */   public String readUTF() throws IOException { return (String)peekCallback().readFromStream(); }
/*     */ 
/*     */   public void readFully(byte[] buf) throws IOException
/*     */   {
/* 146 */     readFully(buf, 0, buf.length);
/*     */   }
/*     */ 
/*     */   public void readFully(byte[] buf, int off, int len) throws IOException {
/* 150 */     byte[] b = (byte[])(byte[])peekCallback().readFromStream();
/* 151 */     System.arraycopy(b, 0, buf, off, len);
/*     */   }
/*     */ 
/*     */   public int read() throws IOException {
/* 155 */     return readUnsignedByte();
/*     */   }
/*     */ 
/*     */   public int read(byte[] buf, int off, int len) throws IOException {
/* 159 */     byte[] b = (byte[])(byte[])peekCallback().readFromStream();
/* 160 */     if (b.length != len) {
/* 161 */       throw new StreamCorruptedException("Expected " + len + " bytes from stream, got " + b.length);
/*     */     }
/* 163 */     System.arraycopy(b, 0, buf, off, len);
/* 164 */     return len;
/*     */   }
/*     */ 
/*     */   public int read(byte[] b) throws IOException {
/* 168 */     return read(b, 0, b.length);
/*     */   }
/*     */ 
/*     */   public ObjectInputStream.GetField readFields() throws IOException {
/* 172 */     return new CustomGetField(peekCallback().readFieldsFromStream());
/*     */   }
/*     */ 
/*     */   public void registerValidation(ObjectInputValidation validation, int priority)
/*     */     throws NotActiveException, InvalidObjectException
/*     */   {
/* 234 */     peekCallback().registerValidation(validation, priority);
/*     */   }
/*     */ 
/*     */   public void close() throws IOException {
/* 238 */     peekCallback().close();
/*     */   }
/*     */ 
/*     */   public int available()
/*     */   {
/* 244 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public String readLine() {
/* 248 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public int skipBytes(int len) {
/* 252 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public long skip(long n) {
/* 256 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public void mark(int readlimit) {
/* 260 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public void reset() {
/* 264 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public boolean markSupported() {
/* 268 */     return false;
/*     */   }
/*     */ 
/*     */   private class CustomGetField extends ObjectInputStream.GetField
/*     */   {
/*     */     private Map fields;
/*     */ 
/*     */     public CustomGetField(Map fields)
/*     */     {
/* 180 */       this.fields = fields;
/*     */     }
/*     */ 
/*     */     public ObjectStreamClass getObjectStreamClass() {
/* 184 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     private Object get(String name) {
/* 188 */       return this.fields.get(name);
/*     */     }
/*     */ 
/*     */     public boolean defaulted(String name) {
/* 192 */       return !this.fields.containsKey(name);
/*     */     }
/*     */ 
/*     */     public byte get(String name, byte val) {
/* 196 */       return defaulted(name) ? val : ((Byte)get(name)).byteValue();
/*     */     }
/*     */ 
/*     */     public char get(String name, char val) {
/* 200 */       return defaulted(name) ? val : ((Character)get(name)).charValue();
/*     */     }
/*     */ 
/*     */     public double get(String name, double val) {
/* 204 */       return defaulted(name) ? val : ((Double)get(name)).doubleValue();
/*     */     }
/*     */ 
/*     */     public float get(String name, float val) {
/* 208 */       return defaulted(name) ? val : ((Float)get(name)).floatValue();
/*     */     }
/*     */ 
/*     */     public int get(String name, int val) {
/* 212 */       return defaulted(name) ? val : ((Integer)get(name)).intValue();
/*     */     }
/*     */ 
/*     */     public long get(String name, long val) {
/* 216 */       return defaulted(name) ? val : ((Long)get(name)).longValue();
/*     */     }
/*     */ 
/*     */     public short get(String name, short val) {
/* 220 */       return defaulted(name) ? val : ((Short)get(name)).shortValue();
/*     */     }
/*     */ 
/*     */     public boolean get(String name, boolean val) {
/* 224 */       return defaulted(name) ? val : ((Boolean)get(name)).booleanValue();
/*     */     }
/*     */ 
/*     */     public Object get(String name, Object val) {
/* 228 */       return defaulted(name) ? val : get(name);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract interface StreamCallback
/*     */   {
/*     */     public abstract Object readFromStream()
/*     */       throws IOException;
/*     */ 
/*     */     public abstract Map readFieldsFromStream()
/*     */       throws IOException;
/*     */ 
/*     */     public abstract void defaultReadObject()
/*     */       throws IOException;
/*     */ 
/*     */     public abstract void registerValidation(ObjectInputValidation paramObjectInputValidation, int paramInt)
/*     */       throws NotActiveException, InvalidObjectException;
/*     */ 
/*     */     public abstract void close()
/*     */       throws IOException;
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.core.util.CustomObjectInputStream
 * JD-Core Version:    0.6.0
 */