/*    */ package com.thoughtworks.xstream.core.util;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ 
/*    */ public class Fields
/*    */ {
/*    */   public static Field find(Class type, String name)
/*    */   {
/*    */     try
/*    */     {
/* 25 */       Field result = type.getDeclaredField(name);
/* 26 */       result.setAccessible(true);
/* 27 */       return result; } catch (NoSuchFieldException e) {
/*    */     }
/* 29 */     throw new IllegalArgumentException("Could not access " + type.getName() + "." + name + " field: " + e.getMessage());
/*    */   }
/*    */ 
/*    */   public static void write(Field field, Object instance, Object value)
/*    */   {
/*    */     try
/*    */     {
/* 40 */       field.set(instance, value);
/*    */     } catch (IllegalAccessException e) {
/* 42 */       throw new RuntimeException("Could not write " + field.getType().getName() + "." + field.getName() + " field");
/*    */     }
/*    */   }
/*    */ 
/*    */   public static Object read(Field field, Object instance) {
/*    */     try {
/* 48 */       return field.get(instance); } catch (IllegalAccessException e) {
/*    */     }
/* 50 */     throw new RuntimeException("Could not read " + field.getType().getName() + "." + field.getName() + " field");
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.core.util.Fields
 * JD-Core Version:    0.6.0
 */