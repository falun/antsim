/*     */ package com.thoughtworks.xstream.core.util;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class ObjectIdDictionary
/*     */ {
/*     */   private final Map map;
/*     */   private volatile int counter;
/*     */ 
/*     */   public ObjectIdDictionary()
/*     */   {
/*  30 */     this.map = new HashMap();
/*     */   }
/*     */ 
/*     */   public void associateId(Object obj, Object id)
/*     */   {
/*  97 */     this.map.put(new WeakIdWrapper(obj), id);
/*  98 */     this.counter += 1;
/*  99 */     cleanup();
/*     */   }
/*     */ 
/*     */   public Object lookupId(Object obj) {
/* 103 */     Object id = this.map.get(new IdWrapper(obj));
/* 104 */     this.counter += 1;
/* 105 */     return id;
/*     */   }
/*     */ 
/*     */   public boolean containsId(Object item) {
/* 109 */     boolean b = this.map.containsKey(new IdWrapper(item));
/* 110 */     this.counter += 1;
/* 111 */     return b;
/*     */   }
/*     */ 
/*     */   public void removeId(Object item) {
/* 115 */     this.map.remove(new IdWrapper(item));
/* 116 */     this.counter += 1;
/* 117 */     cleanup();
/*     */   }
/*     */ 
/*     */   public int size() {
/* 121 */     return this.map.size();
/*     */   }
/*     */ 
/*     */   private void cleanup()
/*     */   {
/*     */     Iterator iterator;
/* 125 */     if (this.counter > 10000) {
/* 126 */       this.counter = 0;
/*     */ 
/* 128 */       for (iterator = this.map.keySet().iterator(); iterator.hasNext(); ) {
/* 129 */         WeakIdWrapper key = (WeakIdWrapper)iterator.next();
/* 130 */         if (key.get() == null)
/* 131 */           iterator.remove();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class WeakIdWrapper
/*     */     implements ObjectIdDictionary.Wrapper
/*     */   {
/*     */     private final int hashCode;
/*     */     private final WeakReference ref;
/*     */ 
/*     */     public WeakIdWrapper(Object obj)
/*     */     {
/*  73 */       this.hashCode = System.identityHashCode(obj);
/*  74 */       this.ref = new WeakReference(obj);
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/*  78 */       return this.hashCode;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other) {
/*  82 */       return get() == ((ObjectIdDictionary.Wrapper)other).get();
/*     */     }
/*     */ 
/*     */     public String toString() {
/*  86 */       Object obj = get();
/*  87 */       return obj == null ? "(null)" : obj.toString();
/*     */     }
/*     */ 
/*     */     public Object get() {
/*  91 */       Object obj = this.ref.get();
/*  92 */       return obj;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class IdWrapper
/*     */     implements ObjectIdDictionary.Wrapper
/*     */   {
/*     */     private final Object obj;
/*     */     private final int hashCode;
/*     */ 
/*     */     public IdWrapper(Object obj)
/*     */     {
/*  46 */       this.hashCode = System.identityHashCode(obj);
/*  47 */       this.obj = obj;
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/*  51 */       return this.hashCode;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other) {
/*  55 */       return this.obj == ((ObjectIdDictionary.Wrapper)other).get();
/*     */     }
/*     */ 
/*     */     public String toString() {
/*  59 */       return this.obj.toString();
/*     */     }
/*     */ 
/*     */     public Object get() {
/*  63 */       return this.obj;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static abstract interface Wrapper
/*     */   {
/*     */     public abstract int hashCode();
/*     */ 
/*     */     public abstract boolean equals(Object paramObject);
/*     */ 
/*     */     public abstract String toString();
/*     */ 
/*     */     public abstract Object get();
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.core.util.ObjectIdDictionary
 * JD-Core Version:    0.6.0
 */