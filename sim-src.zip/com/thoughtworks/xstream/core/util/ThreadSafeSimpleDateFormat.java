/*    */ package com.thoughtworks.xstream.core.util;
/*    */ 
/*    */ import java.text.DateFormat;
/*    */ import java.text.ParseException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ import java.util.Locale;
/*    */ import java.util.TimeZone;
/*    */ 
/*    */ public class ThreadSafeSimpleDateFormat
/*    */ {
/*    */   private final String formatString;
/*    */   private final Pool pool;
/*    */ 
/*    */   public ThreadSafeSimpleDateFormat(String format, int initialPoolSize, int maxPoolSize, boolean lenient)
/*    */   {
/* 42 */     this.formatString = format;
/* 43 */     this.pool = new Pool(initialPoolSize, maxPoolSize, new Pool.Factory(lenient) { private final boolean val$lenient;
/*    */ 
/* 45 */       public Object newInstance() { SimpleDateFormat dateFormat = new SimpleDateFormat(ThreadSafeSimpleDateFormat.this.formatString, Locale.ENGLISH);
/* 46 */         dateFormat.setLenient(this.val$lenient);
/* 47 */         return dateFormat; }
/*    */     });
/*    */   }
/*    */ 
/*    */   public String format(Date date)
/*    */   {
/* 54 */     DateFormat format = fetchFromPool();
/*    */     try {
/* 56 */       String str = format.format(date);
/*    */       return str; } finally { this.pool.putInPool(format); } throw localObject;
/*    */   }
/*    */ 
/*    */   public Date parse(String date) throws ParseException
/*    */   {
/* 63 */     DateFormat format = fetchFromPool();
/*    */     try {
/* 65 */       Date localDate = format.parse(date);
/*    */       return localDate; } finally { this.pool.putInPool(format); } throw localObject;
/*    */   }
/*    */ 
/*    */   private DateFormat fetchFromPool()
/*    */   {
/* 72 */     TimeZone tz = TimeZone.getDefault();
/* 73 */     DateFormat format = (DateFormat)this.pool.fetchFromPool();
/* 74 */     if (!tz.equals(format.getTimeZone())) {
/* 75 */       format.setTimeZone(tz);
/*    */     }
/* 77 */     return format;
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.core.util.ThreadSafeSimpleDateFormat
 * JD-Core Version:    0.6.0
 */