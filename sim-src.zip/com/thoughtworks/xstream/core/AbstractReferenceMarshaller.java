/*    */ package com.thoughtworks.xstream.core;
/*    */ 
/*    */ import com.thoughtworks.xstream.converters.ConversionException;
/*    */ import com.thoughtworks.xstream.converters.Converter;
/*    */ import com.thoughtworks.xstream.converters.ConverterLookup;
/*    */ import com.thoughtworks.xstream.core.util.ObjectIdDictionary;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*    */ import com.thoughtworks.xstream.io.path.Path;
/*    */ import com.thoughtworks.xstream.io.path.PathTracker;
/*    */ import com.thoughtworks.xstream.io.path.PathTrackingWriter;
/*    */ import com.thoughtworks.xstream.mapper.Mapper;
/*    */ 
/*    */ public abstract class AbstractReferenceMarshaller extends TreeMarshaller
/*    */ {
/* 33 */   private ObjectIdDictionary references = new ObjectIdDictionary();
/* 34 */   private ObjectIdDictionary implicitElements = new ObjectIdDictionary();
/* 35 */   private PathTracker pathTracker = new PathTracker();
/*    */   private Path lastPath;
/*    */ 
/*    */   public AbstractReferenceMarshaller(HierarchicalStreamWriter writer, ConverterLookup converterLookup, Mapper mapper)
/*    */   {
/* 41 */     super(writer, converterLookup, mapper);
/* 42 */     this.writer = new PathTrackingWriter(writer, this.pathTracker);
/*    */   }
/*    */ 
/*    */   public void convert(Object item, Converter converter) {
/* 46 */     if (getMapper().isImmutableValueType(item.getClass()))
/*    */     {
/* 48 */       converter.marshal(item, this.writer, this);
/*    */     } else {
/* 50 */       Path currentPath = this.pathTracker.getPath();
/* 51 */       Object existingReferenceKey = this.references.lookupId(item);
/* 52 */       if (existingReferenceKey != null) {
/* 53 */         String attributeName = getMapper().aliasForSystemAttribute("reference");
/* 54 */         if (attributeName != null)
/* 55 */           this.writer.addAttribute(attributeName, createReference(currentPath, existingReferenceKey));
/*    */       } else {
/* 57 */         if (this.implicitElements.lookupId(item) != null) {
/* 58 */           throw new ReferencedImplicitElementException(item, currentPath);
/*    */         }
/* 60 */         Object newReferenceKey = createReferenceKey(currentPath, item);
/* 61 */         if ((this.lastPath == null) || (!currentPath.isAncestor(this.lastPath))) {
/* 62 */           fireValidReference(newReferenceKey);
/* 63 */           this.lastPath = currentPath;
/* 64 */           this.references.associateId(item, newReferenceKey);
/*    */         } else {
/* 66 */           this.implicitElements.associateId(item, newReferenceKey);
/*    */         }
/* 68 */         converter.marshal(item, this.writer, this);
/*    */       }
/*    */     }
/*    */   }
/*    */   protected abstract String createReference(Path paramPath, Object paramObject);
/*    */ 
/*    */   protected abstract Object createReferenceKey(Path paramPath, Object paramObject);
/*    */ 
/*    */   protected abstract void fireValidReference(Object paramObject);
/*    */ 
/*    */   public static class ReferencedImplicitElementException extends ConversionException {
/* 82 */     /** @deprecated */
/*    */     public ReferencedImplicitElementException(String msg) { super(); }
/*    */ 
/*    */     public ReferencedImplicitElementException(Object item, Path path) {
/* 85 */       super();
/* 86 */       add("implicit-element", item.toString());
/* 87 */       add("referencing-element", path.toString());
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.core.AbstractReferenceMarshaller
 * JD-Core Version:    0.6.0
 */