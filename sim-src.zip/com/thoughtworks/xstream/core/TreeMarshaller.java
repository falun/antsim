/*     */ package com.thoughtworks.xstream.core;
/*     */ 
/*     */ import com.thoughtworks.xstream.XStreamException;
/*     */ import com.thoughtworks.xstream.alias.ClassMapper;
/*     */ import com.thoughtworks.xstream.converters.ConversionException;
/*     */ import com.thoughtworks.xstream.converters.Converter;
/*     */ import com.thoughtworks.xstream.converters.ConverterLookup;
/*     */ import com.thoughtworks.xstream.converters.DataHolder;
/*     */ import com.thoughtworks.xstream.converters.MarshallingContext;
/*     */ import com.thoughtworks.xstream.core.util.ObjectIdDictionary;
/*     */ import com.thoughtworks.xstream.io.ExtendedHierarchicalStreamWriterHelper;
/*     */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*     */ import com.thoughtworks.xstream.mapper.Mapper;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class TreeMarshaller
/*     */   implements MarshallingContext
/*     */ {
/*     */   protected HierarchicalStreamWriter writer;
/*     */   protected ConverterLookup converterLookup;
/*     */ 
/*     */   /** @deprecated */
/*     */   protected ClassMapper classMapper;
/*     */   private Mapper mapper;
/*  38 */   private ObjectIdDictionary parentObjects = new ObjectIdDictionary();
/*     */   private DataHolder dataHolder;
/*     */ 
/*     */   public TreeMarshaller(HierarchicalStreamWriter writer, ConverterLookup converterLookup, Mapper mapper)
/*     */   {
/*  43 */     this.writer = writer;
/*  44 */     this.converterLookup = converterLookup;
/*  45 */     this.mapper = mapper;
/*     */ 
/*  47 */     if ((mapper instanceof ClassMapper))
/*  48 */       this.classMapper = ((ClassMapper)mapper);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public TreeMarshaller(HierarchicalStreamWriter writer, ConverterLookup converterLookup, ClassMapper classMapper)
/*     */   {
/*  59 */     this(writer, converterLookup, classMapper);
/*     */   }
/*     */ 
/*     */   public void convertAnother(Object item) {
/*  63 */     convertAnother(item, null);
/*     */   }
/*     */ 
/*     */   public void convertAnother(Object item, Converter converter) {
/*  67 */     if (converter == null) {
/*  68 */       converter = this.converterLookup.lookupConverterForType(item.getClass());
/*     */     }
/*  70 */     else if (!converter.canConvert(item.getClass())) {
/*  71 */       ConversionException e = new ConversionException("Explicit selected converter cannot handle item");
/*     */ 
/*  73 */       e.add("item-type", item.getClass().getName());
/*  74 */       e.add("converter-type", converter.getClass().getName());
/*  75 */       throw e;
/*     */     }
/*     */ 
/*  78 */     convert(item, converter);
/*     */   }
/*     */ 
/*     */   protected void convert(Object item, Converter converter) {
/*  82 */     if (this.parentObjects.containsId(item)) {
/*  83 */       throw new CircularReferenceException();
/*     */     }
/*  85 */     this.parentObjects.associateId(item, "");
/*  86 */     converter.marshal(item, this.writer, this);
/*  87 */     this.parentObjects.removeId(item);
/*     */   }
/*     */ 
/*     */   public void start(Object item, DataHolder dataHolder) {
/*  91 */     this.dataHolder = dataHolder;
/*  92 */     if (item == null) {
/*  93 */       this.writer.startNode(this.mapper.serializedClass(null));
/*  94 */       this.writer.endNode();
/*     */     } else {
/*  96 */       ExtendedHierarchicalStreamWriterHelper.startNode(this.writer, this.mapper.serializedClass(item.getClass()), item.getClass());
/*     */ 
/*  98 */       convertAnother(item);
/*  99 */       this.writer.endNode();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object get(Object key) {
/* 104 */     lazilyCreateDataHolder();
/* 105 */     return this.dataHolder.get(key);
/*     */   }
/*     */ 
/*     */   public void put(Object key, Object value) {
/* 109 */     lazilyCreateDataHolder();
/* 110 */     this.dataHolder.put(key, value);
/*     */   }
/*     */ 
/*     */   public Iterator keys() {
/* 114 */     lazilyCreateDataHolder();
/* 115 */     return this.dataHolder.keys();
/*     */   }
/*     */ 
/*     */   private void lazilyCreateDataHolder() {
/* 119 */     if (this.dataHolder == null)
/* 120 */       this.dataHolder = new MapBackedDataHolder();
/*     */   }
/*     */ 
/*     */   protected Mapper getMapper()
/*     */   {
/* 125 */     return this.mapper;
/*     */   }
/*     */ 
/*     */   public static class CircularReferenceException extends XStreamException
/*     */   {
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.core.TreeMarshaller
 * JD-Core Version:    0.6.0
 */