/*    */ package com.thoughtworks.xstream.core;
/*    */ 
/*    */ import com.thoughtworks.xstream.alias.ClassMapper;
/*    */ import com.thoughtworks.xstream.converters.ConverterLookup;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*    */ import com.thoughtworks.xstream.io.path.Path;
/*    */ import com.thoughtworks.xstream.mapper.Mapper;
/*    */ 
/*    */ public class ReferenceByXPathMarshaller extends AbstractReferenceMarshaller
/*    */ {
/*    */   private final int mode;
/*    */ 
/*    */   public ReferenceByXPathMarshaller(HierarchicalStreamWriter writer, ConverterLookup converterLookup, Mapper mapper, int mode)
/*    */   {
/* 25 */     super(writer, converterLookup, mapper);
/* 26 */     this.mode = mode;
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public ReferenceByXPathMarshaller(HierarchicalStreamWriter writer, ConverterLookup converterLookup, ClassMapper classMapper)
/*    */   {
/* 33 */     this(writer, converterLookup, classMapper, ReferenceByXPathMarshallingStrategy.RELATIVE);
/*    */   }
/*    */ 
/*    */   protected String createReference(Path currentPath, Object existingReferenceKey) {
/* 37 */     return (this.mode == ReferenceByXPathMarshallingStrategy.RELATIVE ? currentPath.relativeTo((Path)existingReferenceKey) : existingReferenceKey).toString();
/*    */   }
/*    */ 
/*    */   protected Object createReferenceKey(Path currentPath, Object item) {
/* 41 */     return currentPath;
/*    */   }
/*    */ 
/*    */   protected void fireValidReference(Object referenceKey)
/*    */   {
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.core.ReferenceByXPathMarshaller
 * JD-Core Version:    0.6.0
 */