/*     */ package com.thoughtworks.xstream.core;
/*     */ 
/*     */ import com.thoughtworks.xstream.alias.ClassMapper;
/*     */ import com.thoughtworks.xstream.converters.ConversionException;
/*     */ import com.thoughtworks.xstream.converters.Converter;
/*     */ import com.thoughtworks.xstream.converters.ConverterLookup;
/*     */ import com.thoughtworks.xstream.converters.DataHolder;
/*     */ import com.thoughtworks.xstream.converters.ErrorWriter;
/*     */ import com.thoughtworks.xstream.converters.UnmarshallingContext;
/*     */ import com.thoughtworks.xstream.core.util.FastStack;
/*     */ import com.thoughtworks.xstream.core.util.HierarchicalStreams;
/*     */ import com.thoughtworks.xstream.core.util.PrioritizedList;
/*     */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*     */ import com.thoughtworks.xstream.mapper.Mapper;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class TreeUnmarshaller
/*     */   implements UnmarshallingContext
/*     */ {
/*     */   private Object root;
/*     */   protected HierarchicalStreamReader reader;
/*     */   private ConverterLookup converterLookup;
/*     */   private Mapper mapper;
/*  36 */   private FastStack types = new FastStack(16);
/*     */   private DataHolder dataHolder;
/*  38 */   private final PrioritizedList validationList = new PrioritizedList();
/*     */ 
/*     */   public TreeUnmarshaller(Object root, HierarchicalStreamReader reader, ConverterLookup converterLookup, Mapper mapper)
/*     */   {
/*  43 */     this.root = root;
/*  44 */     this.reader = reader;
/*  45 */     this.converterLookup = converterLookup;
/*  46 */     this.mapper = mapper;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public TreeUnmarshaller(Object root, HierarchicalStreamReader reader, ConverterLookup converterLookup, ClassMapper classMapper)
/*     */   {
/*  56 */     this(root, reader, converterLookup, classMapper);
/*     */   }
/*     */ 
/*     */   public Object convertAnother(Object parent, Class type) {
/*  60 */     return convertAnother(parent, type, null);
/*     */   }
/*     */ 
/*     */   public Object convertAnother(Object parent, Class type, Converter converter) {
/*  64 */     type = this.mapper.defaultImplementationOf(type);
/*  65 */     if (converter == null) {
/*  66 */       converter = this.converterLookup.lookupConverterForType(type);
/*     */     }
/*  68 */     else if (!converter.canConvert(type)) {
/*  69 */       ConversionException e = new ConversionException("Explicit selected converter cannot handle type");
/*     */ 
/*  71 */       e.add("item-type", type.getName());
/*  72 */       e.add("converter-type", converter.getClass().getName());
/*  73 */       throw e;
/*     */     }
/*     */ 
/*  76 */     return convert(parent, type, converter);
/*     */   }
/*     */   protected Object convert(Object parent, Class type, Converter converter) {
/*     */     ConversionException conversionException;
/*     */     try { this.types.push(type);
/*  82 */       Object result = converter.unmarshal(this.reader, this);
/*  83 */       this.types.popSilently();
/*  84 */       return result;
/*     */     } catch (ConversionException conversionException) {
/*  86 */       addInformationTo(conversionException, type);
/*  87 */       throw conversionException;
/*     */     } catch (RuntimeException e) {
/*  89 */       conversionException = new ConversionException(e);
/*  90 */       addInformationTo(conversionException, type);
/*  91 */     }throw conversionException;
/*     */   }
/*     */ 
/*     */   private void addInformationTo(ErrorWriter errorWriter, Class type)
/*     */   {
/*  96 */     errorWriter.add("class", type.getName());
/*  97 */     errorWriter.add("required-type", getRequiredType().getName());
/*  98 */     this.reader.appendErrors(errorWriter);
/*     */   }
/*     */ 
/*     */   public void addCompletionCallback(Runnable work, int priority) {
/* 102 */     this.validationList.add(work, priority);
/*     */   }
/*     */ 
/*     */   public Object currentObject() {
/* 106 */     return this.types.size() == 1 ? this.root : null;
/*     */   }
/*     */ 
/*     */   public Class getRequiredType() {
/* 110 */     return (Class)this.types.peek();
/*     */   }
/*     */ 
/*     */   public Object get(Object key) {
/* 114 */     lazilyCreateDataHolder();
/* 115 */     return this.dataHolder.get(key);
/*     */   }
/*     */ 
/*     */   public void put(Object key, Object value) {
/* 119 */     lazilyCreateDataHolder();
/* 120 */     this.dataHolder.put(key, value);
/*     */   }
/*     */ 
/*     */   public Iterator keys() {
/* 124 */     lazilyCreateDataHolder();
/* 125 */     return this.dataHolder.keys();
/*     */   }
/*     */ 
/*     */   private void lazilyCreateDataHolder() {
/* 129 */     if (this.dataHolder == null)
/* 130 */       this.dataHolder = new MapBackedDataHolder();
/*     */   }
/*     */ 
/*     */   public Object start(DataHolder dataHolder)
/*     */   {
/* 135 */     this.dataHolder = dataHolder;
/* 136 */     Class type = HierarchicalStreams.readClassType(this.reader, this.mapper);
/* 137 */     Object result = convertAnother(null, type);
/* 138 */     Iterator validations = this.validationList.iterator();
/* 139 */     while (validations.hasNext()) {
/* 140 */       Runnable runnable = (Runnable)validations.next();
/* 141 */       runnable.run();
/*     */     }
/* 143 */     return result;
/*     */   }
/*     */ 
/*     */   protected Mapper getMapper() {
/* 147 */     return this.mapper;
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.core.TreeUnmarshaller
 * JD-Core Version:    0.6.0
 */