/*    */ package com.thoughtworks.xstream.core;
/*    */ 
/*    */ import com.thoughtworks.xstream.alias.ClassMapper;
/*    */ import com.thoughtworks.xstream.converters.ConverterLookup;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*    */ import com.thoughtworks.xstream.io.path.Path;
/*    */ import com.thoughtworks.xstream.io.path.PathTracker;
/*    */ import com.thoughtworks.xstream.io.path.PathTrackingReader;
/*    */ import com.thoughtworks.xstream.io.xml.XmlFriendlyReader;
/*    */ import com.thoughtworks.xstream.mapper.Mapper;
/*    */ 
/*    */ public class ReferenceByXPathUnmarshaller extends AbstractReferenceUnmarshaller
/*    */ {
/* 25 */   private PathTracker pathTracker = new PathTracker();
/*    */   protected boolean isXmlFriendly;
/*    */ 
/*    */   public ReferenceByXPathUnmarshaller(Object root, HierarchicalStreamReader reader, ConverterLookup converterLookup, Mapper mapper)
/*    */   {
/* 30 */     super(root, reader, converterLookup, mapper);
/* 31 */     this.reader = new PathTrackingReader(reader, this.pathTracker);
/* 32 */     this.isXmlFriendly = (reader.underlyingReader() instanceof XmlFriendlyReader);
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public ReferenceByXPathUnmarshaller(Object root, HierarchicalStreamReader reader, ConverterLookup converterLookup, ClassMapper classMapper)
/*    */   {
/* 40 */     this(root, reader, converterLookup, classMapper);
/*    */   }
/*    */ 
/*    */   protected Object getReferenceKey(String reference) {
/* 44 */     Path path = new Path(this.isXmlFriendly ? ((XmlFriendlyReader)this.reader.underlyingReader()).unescapeXmlName(reference) : reference);
/*    */ 
/* 46 */     return reference.charAt(0) != '/' ? this.pathTracker.getPath().apply(path) : path;
/*    */   }
/*    */ 
/*    */   protected Object getCurrentReferenceKey() {
/* 50 */     return this.pathTracker.getPath();
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.core.ReferenceByXPathUnmarshaller
 * JD-Core Version:    0.6.0
 */