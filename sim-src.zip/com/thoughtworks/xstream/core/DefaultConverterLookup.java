/*    */ package com.thoughtworks.xstream.core;
/*    */ 
/*    */ import com.thoughtworks.xstream.alias.ClassMapper;
/*    */ import com.thoughtworks.xstream.converters.ConversionException;
/*    */ import com.thoughtworks.xstream.converters.Converter;
/*    */ import com.thoughtworks.xstream.converters.ConverterLookup;
/*    */ import com.thoughtworks.xstream.converters.ConverterRegistry;
/*    */ import com.thoughtworks.xstream.core.util.PrioritizedList;
/*    */ import com.thoughtworks.xstream.mapper.Mapper;
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class DefaultConverterLookup
/*    */   implements ConverterLookup, ConverterRegistry
/*    */ {
/* 36 */   private final PrioritizedList converters = new PrioritizedList();
/* 37 */   private transient Map typeToConverterMap = Collections.synchronizedMap(new HashMap());
/*    */ 
/*    */   public DefaultConverterLookup()
/*    */   {
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public DefaultConverterLookup(Mapper mapper)
/*    */   {
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public DefaultConverterLookup(ClassMapper classMapper) {
/*    */   }
/*    */ 
/*    */   public Converter lookupConverterForType(Class type) {
/* 55 */     Converter cachedConverter = (Converter)this.typeToConverterMap.get(type);
/* 56 */     if (cachedConverter != null) return cachedConverter;
/* 57 */     Iterator iterator = this.converters.iterator();
/* 58 */     while (iterator.hasNext()) {
/* 59 */       Converter converter = (Converter)iterator.next();
/* 60 */       if (converter.canConvert(type)) {
/* 61 */         this.typeToConverterMap.put(type, converter);
/* 62 */         return converter;
/*    */       }
/*    */     }
/* 65 */     throw new ConversionException("No converter specified for " + type);
/*    */   }
/*    */ 
/*    */   public void registerConverter(Converter converter, int priority) {
/* 69 */     this.converters.add(converter, priority);
/* 70 */     for (Iterator iter = this.typeToConverterMap.keySet().iterator(); iter.hasNext(); ) {
/* 71 */       Class type = (Class)iter.next();
/* 72 */       if (converter.canConvert(type))
/* 73 */         iter.remove();
/*    */     }
/*    */   }
/*    */ 
/*    */   private Object readResolve()
/*    */   {
/* 79 */     this.typeToConverterMap = Collections.synchronizedMap(new HashMap());
/* 80 */     return this;
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.core.DefaultConverterLookup
 * JD-Core Version:    0.6.0
 */