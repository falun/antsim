/*    */ package com.thoughtworks.xstream.core;
/*    */ 
/*    */ import com.thoughtworks.xstream.MarshallingStrategy;
/*    */ import com.thoughtworks.xstream.alias.ClassMapper;
/*    */ import com.thoughtworks.xstream.converters.ConverterLookup;
/*    */ import com.thoughtworks.xstream.converters.DataHolder;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*    */ import com.thoughtworks.xstream.mapper.Mapper;
/*    */ 
/*    */ public abstract class AbstractTreeMarshallingStrategy
/*    */   implements MarshallingStrategy
/*    */ {
/*    */   public Object unmarshal(Object root, HierarchicalStreamReader reader, DataHolder dataHolder, ConverterLookup converterLookup, Mapper mapper)
/*    */   {
/* 32 */     TreeUnmarshaller context = createUnmarshallingContext(root, reader, converterLookup, mapper);
/* 33 */     return context.start(dataHolder);
/*    */   }
/*    */ 
/*    */   public void marshal(HierarchicalStreamWriter writer, Object obj, ConverterLookup converterLookup, Mapper mapper, DataHolder dataHolder) {
/* 37 */     TreeMarshaller context = createMarshallingContext(writer, converterLookup, mapper);
/* 38 */     context.start(obj, dataHolder);
/*    */   }
/*    */ 
/*    */   protected abstract TreeUnmarshaller createUnmarshallingContext(Object paramObject, HierarchicalStreamReader paramHierarchicalStreamReader, ConverterLookup paramConverterLookup, Mapper paramMapper);
/*    */ 
/*    */   protected abstract TreeMarshaller createMarshallingContext(HierarchicalStreamWriter paramHierarchicalStreamWriter, ConverterLookup paramConverterLookup, Mapper paramMapper);
/*    */ 
/*    */   /** @deprecated */
/*    */   public Object unmarshal(Object root, HierarchicalStreamReader reader, DataHolder dataHolder, DefaultConverterLookup converterLookup, ClassMapper classMapper)
/*    */   {
/* 51 */     return unmarshal(root, reader, dataHolder, converterLookup, classMapper);
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public void marshal(HierarchicalStreamWriter writer, Object obj, DefaultConverterLookup converterLookup, ClassMapper classMapper, DataHolder dataHolder)
/*    */   {
/* 58 */     marshal(writer, obj, converterLookup, classMapper, dataHolder);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.core.AbstractTreeMarshallingStrategy
 * JD-Core Version:    0.6.0
 */