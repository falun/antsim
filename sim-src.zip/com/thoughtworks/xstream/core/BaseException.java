/*    */ package com.thoughtworks.xstream.core;
/*    */ 
/*    */ /** @deprecated */
/*    */ public abstract class BaseException extends RuntimeException
/*    */ {
/*    */   protected BaseException(String message)
/*    */   {
/* 23 */     super(message);
/*    */   }
/*    */ 
/*    */   public abstract Throwable getCause();
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.core.BaseException
 * JD-Core Version:    0.6.0
 */