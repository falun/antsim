/*    */ package com.thoughtworks.xstream.annotations;
/*    */ 
/*    */ import com.thoughtworks.xstream.XStream;
/*    */ 
/*    */ @Deprecated
/*    */ public class Annotations
/*    */ {
/*    */   @Deprecated
/*    */   public static synchronized void configureAliases(XStream xstream, Class<?>[] topLevelClasses)
/*    */   {
/* 48 */     xstream.processAnnotations(topLevelClasses);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.annotations.Annotations
 * JD-Core Version:    0.6.0
 */