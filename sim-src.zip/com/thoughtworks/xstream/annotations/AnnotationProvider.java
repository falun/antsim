/*    */ package com.thoughtworks.xstream.annotations;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Field;
/*    */ 
/*    */ @Deprecated
/*    */ public class AnnotationProvider
/*    */ {
/*    */   @Deprecated
/*    */   public <T extends Annotation> T getAnnotation(Field field, Class<T> annotationClass)
/*    */   {
/* 36 */     return field.getAnnotation(annotationClass);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.annotations.AnnotationProvider
 * JD-Core Version:    0.6.0
 */