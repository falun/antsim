/*     */ package com.thoughtworks.xstream.annotations;
/*     */ 
/*     */ import com.thoughtworks.xstream.converters.Converter;
/*     */ import com.thoughtworks.xstream.converters.ConverterMatcher;
/*     */ import com.thoughtworks.xstream.converters.MarshallingContext;
/*     */ import com.thoughtworks.xstream.converters.SingleValueConverter;
/*     */ import com.thoughtworks.xstream.converters.SingleValueConverterWrapper;
/*     */ import com.thoughtworks.xstream.converters.UnmarshallingContext;
/*     */ import com.thoughtworks.xstream.converters.reflection.ObjectAccessException;
/*     */ import com.thoughtworks.xstream.converters.reflection.ReflectionConverter;
/*     */ import com.thoughtworks.xstream.converters.reflection.ReflectionProvider;
/*     */ import com.thoughtworks.xstream.mapper.Mapper;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ @Deprecated
/*     */ public class AnnotationReflectionConverter extends ReflectionConverter
/*     */ {
/*     */   private final AnnotationProvider annotationProvider;
/*     */   private final Map<Class<? extends ConverterMatcher>, Converter> cachedConverters;
/*     */ 
/*     */   @Deprecated
/*     */   public AnnotationReflectionConverter(Mapper mapper, ReflectionProvider reflectionProvider, AnnotationProvider annotationProvider)
/*     */   {
/*  50 */     super(mapper, reflectionProvider);
/*  51 */     this.annotationProvider = annotationProvider;
/*  52 */     this.cachedConverters = new HashMap();
/*     */   }
/*     */ 
/*     */   protected void marshallField(MarshallingContext context, Object newObj, Field field) {
/*  56 */     XStreamConverter annotation = (XStreamConverter)this.annotationProvider.getAnnotation(field, XStreamConverter.class);
/*     */ 
/*  58 */     if (annotation != null) {
/*  59 */       Class type = annotation.value();
/*  60 */       ensureCache(type);
/*  61 */       context.convertAnother(newObj, (Converter)this.cachedConverters.get(type));
/*     */     } else {
/*  63 */       context.convertAnother(newObj);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void ensureCache(Class<? extends ConverterMatcher> type) {
/*  68 */     if (!this.cachedConverters.containsKey(type))
/*  69 */       this.cachedConverters.put(type, newInstance(type));
/*     */   }
/*     */ 
/*     */   protected Object unmarshallField(UnmarshallingContext context, Object result, Class type, Field field)
/*     */   {
/*  76 */     XStreamConverter annotation = (XStreamConverter)this.annotationProvider.getAnnotation(field, XStreamConverter.class);
/*     */ 
/*  78 */     if (annotation != null) {
/*  79 */       Class converterType = annotation.value();
/*  80 */       ensureCache(converterType);
/*  81 */       return context.convertAnother(result, type, (Converter)this.cachedConverters.get(converterType));
/*     */     }
/*  83 */     return context.convertAnother(result, type);
/*     */   }
/*     */ 
/*     */   private Converter newInstance(Class<? extends ConverterMatcher> type)
/*     */   {
/*     */     Converter converter;
/*     */     try
/*     */     {
/*     */       Converter converter;
/*  97 */       if (SingleValueConverter.class.isAssignableFrom(type)) {
/*  98 */         SingleValueConverter svc = (SingleValueConverter)type.getConstructor(new Class[0]).newInstance(new Object[0]);
/*  99 */         converter = new SingleValueConverterWrapper(svc);
/*     */       } else {
/* 101 */         converter = (Converter)type.getConstructor(new Class[0]).newInstance(new Object[0]);
/*     */       }
/*     */     } catch (InvocationTargetException e) {
/* 104 */       throw new ObjectAccessException("Cannot construct " + type.getName(), e.getCause());
/*     */     }
/*     */     catch (InstantiationException e) {
/* 107 */       throw new ObjectAccessException("Cannot construct " + type.getName(), e);
/*     */     } catch (IllegalAccessException e) {
/* 109 */       throw new ObjectAccessException("Cannot construct " + type.getName(), e);
/*     */     } catch (NoSuchMethodException e) {
/* 111 */       throw new ObjectAccessException("Cannot construct " + type.getName(), e);
/*     */     }
/* 113 */     return converter;
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.annotations.AnnotationReflectionConverter
 * JD-Core Version:    0.6.0
 */