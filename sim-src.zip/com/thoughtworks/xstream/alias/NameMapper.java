package com.thoughtworks.xstream.alias;

/** @deprecated */
public abstract interface NameMapper
{
  /** @deprecated */
  public abstract String fromXML(String paramString);

  /** @deprecated */
  public abstract String toXML(String paramString);
}

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.alias.NameMapper
 * JD-Core Version:    0.6.0
 */