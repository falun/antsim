/*    */ package com.thoughtworks.xstream.alias;
/*    */ 
/*    */ import com.thoughtworks.xstream.XStreamException;
/*    */ 
/*    */ /** @deprecated */
/*    */ public class CannotResolveClassException extends XStreamException
/*    */ {
/*    */   /** @deprecated */
/*    */   public CannotResolveClassException(String className)
/*    */   {
/* 24 */     super(className);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.alias.CannotResolveClassException
 * JD-Core Version:    0.6.0
 */