package com.thoughtworks.xstream.alias;

import com.thoughtworks.xstream.mapper.Mapper;
import com.thoughtworks.xstream.mapper.Mapper.Null;

/** @deprecated */
public abstract interface ClassMapper extends Mapper
{
  /** @deprecated */
  public static class Null extends Mapper.Null
  {
  }
}

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.alias.ClassMapper
 * JD-Core Version:    0.6.0
 */