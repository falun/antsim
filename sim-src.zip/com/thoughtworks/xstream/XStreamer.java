/*     */ package com.thoughtworks.xstream;
/*     */ 
/*     */ import com.thoughtworks.xstream.converters.ConversionException;
/*     */ import com.thoughtworks.xstream.io.HierarchicalStreamDriver;
/*     */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*     */ import com.thoughtworks.xstream.io.xml.XppDriver;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.ObjectStreamException;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ 
/*     */ public class XStreamer
/*     */ {
/*     */   public String toXML(XStream xstream, Object obj)
/*     */     throws ObjectStreamException
/*     */   {
/*  46 */     Writer writer = new StringWriter();
/*     */     try {
/*  48 */       toXML(xstream, obj, writer);
/*     */     } catch (ObjectStreamException e) {
/*  50 */       throw e;
/*     */     } catch (IOException e) {
/*  52 */       throw new ConversionException("Unexpeced IO error from a StringWriter", e);
/*     */     }
/*  54 */     return writer.toString();
/*     */   }
/*     */ 
/*     */   public void toXML(XStream xstream, Object obj, Writer out)
/*     */     throws IOException
/*     */   {
/*  74 */     XStream outer = new XStream();
/*  75 */     ObjectOutputStream oos = outer.createObjectOutputStream(out);
/*     */     try {
/*  77 */       oos.writeObject(xstream);
/*  78 */       oos.flush();
/*  79 */       xstream.toXML(obj, out);
/*     */     } finally {
/*  81 */       oos.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object fromXML(String xml)
/*     */     throws ClassNotFoundException, ObjectStreamException
/*     */   {
/*     */     try
/*     */     {
/*  97 */       return fromXML(new StringReader(xml));
/*     */     } catch (ObjectStreamException e) {
/*  99 */       throw e; } catch (IOException e) {
/*     */     }
/* 101 */     throw new ConversionException("Unexpeced IO error from a StringReader", e);
/*     */   }
/*     */ 
/*     */   public Object fromXML(HierarchicalStreamDriver driver, String xml)
/*     */     throws ClassNotFoundException, ObjectStreamException
/*     */   {
/*     */     try
/*     */     {
/* 117 */       return fromXML(driver, new StringReader(xml));
/*     */     } catch (ObjectStreamException e) {
/* 119 */       throw e; } catch (IOException e) {
/*     */     }
/* 121 */     throw new ConversionException("Unexpeced IO error from a StringReader", e);
/*     */   }
/*     */ 
/*     */   public Object fromXML(Reader xml)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 137 */     return fromXML(new XppDriver(), xml);
/*     */   }
/*     */ 
/*     */   public Object fromXML(HierarchicalStreamDriver driver, Reader xml)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 150 */     XStream outer = new XStream(driver);
/* 151 */     HierarchicalStreamReader reader = driver.createReader(xml);
/* 152 */     ObjectInputStream configIn = outer.createObjectInputStream(reader);
/*     */     try {
/* 154 */       XStream configured = (XStream)configIn.readObject();
/* 155 */       ObjectInputStream in = configured.createObjectInputStream(reader);
/*     */       try {
/* 157 */         Object localObject1 = in.readObject();
/*     */ 
/* 159 */         in.close();
/*     */         return localObject1;
/*     */       }
/*     */       finally
/*     */       {
/* 159 */         in.close();
/*     */       }
/*     */     } finally {
/* 162 */       configIn.close(); } throw localObject3;
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.XStreamer
 * JD-Core Version:    0.6.0
 */