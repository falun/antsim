/*    */ package com.thoughtworks.xstream;
/*    */ 
/*    */ public class InitializationException extends XStream.InitializationException
/*    */ {
/*    */   public InitializationException(String message, Throwable cause)
/*    */   {
/* 22 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public InitializationException(String message) {
/* 26 */     super(message);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.InitializationException
 * JD-Core Version:    0.6.0
 */