/*      */ package com.thoughtworks.xstream;
/*      */ 
/*      */ import com.thoughtworks.xstream.alias.ClassMapper;
/*      */ import com.thoughtworks.xstream.converters.Converter;
/*      */ import com.thoughtworks.xstream.converters.ConverterLookup;
/*      */ import com.thoughtworks.xstream.converters.ConverterRegistry;
/*      */ import com.thoughtworks.xstream.converters.DataHolder;
/*      */ import com.thoughtworks.xstream.converters.SingleValueConverter;
/*      */ import com.thoughtworks.xstream.converters.SingleValueConverterWrapper;
/*      */ import com.thoughtworks.xstream.converters.basic.BigDecimalConverter;
/*      */ import com.thoughtworks.xstream.converters.basic.BigIntegerConverter;
/*      */ import com.thoughtworks.xstream.converters.basic.BooleanConverter;
/*      */ import com.thoughtworks.xstream.converters.basic.ByteConverter;
/*      */ import com.thoughtworks.xstream.converters.basic.CharConverter;
/*      */ import com.thoughtworks.xstream.converters.basic.DateConverter;
/*      */ import com.thoughtworks.xstream.converters.basic.DoubleConverter;
/*      */ import com.thoughtworks.xstream.converters.basic.FloatConverter;
/*      */ import com.thoughtworks.xstream.converters.basic.IntConverter;
/*      */ import com.thoughtworks.xstream.converters.basic.LongConverter;
/*      */ import com.thoughtworks.xstream.converters.basic.NullConverter;
/*      */ import com.thoughtworks.xstream.converters.basic.ShortConverter;
/*      */ import com.thoughtworks.xstream.converters.basic.StringBufferConverter;
/*      */ import com.thoughtworks.xstream.converters.basic.StringConverter;
/*      */ import com.thoughtworks.xstream.converters.basic.URLConverter;
/*      */ import com.thoughtworks.xstream.converters.collections.ArrayConverter;
/*      */ import com.thoughtworks.xstream.converters.collections.BitSetConverter;
/*      */ import com.thoughtworks.xstream.converters.collections.CharArrayConverter;
/*      */ import com.thoughtworks.xstream.converters.collections.CollectionConverter;
/*      */ import com.thoughtworks.xstream.converters.collections.MapConverter;
/*      */ import com.thoughtworks.xstream.converters.collections.PropertiesConverter;
/*      */ import com.thoughtworks.xstream.converters.collections.TreeMapConverter;
/*      */ import com.thoughtworks.xstream.converters.collections.TreeSetConverter;
/*      */ import com.thoughtworks.xstream.converters.extended.ColorConverter;
/*      */ import com.thoughtworks.xstream.converters.extended.DynamicProxyConverter;
/*      */ import com.thoughtworks.xstream.converters.extended.EncodedByteArrayConverter;
/*      */ import com.thoughtworks.xstream.converters.extended.FileConverter;
/*      */ import com.thoughtworks.xstream.converters.extended.FontConverter;
/*      */ import com.thoughtworks.xstream.converters.extended.GregorianCalendarConverter;
/*      */ import com.thoughtworks.xstream.converters.extended.JavaClassConverter;
/*      */ import com.thoughtworks.xstream.converters.extended.JavaMethodConverter;
/*      */ import com.thoughtworks.xstream.converters.extended.LocaleConverter;
/*      */ import com.thoughtworks.xstream.converters.extended.LookAndFeelConverter;
/*      */ import com.thoughtworks.xstream.converters.extended.SqlDateConverter;
/*      */ import com.thoughtworks.xstream.converters.extended.SqlTimeConverter;
/*      */ import com.thoughtworks.xstream.converters.extended.SqlTimestampConverter;
/*      */ import com.thoughtworks.xstream.converters.extended.TextAttributeConverter;
/*      */ import com.thoughtworks.xstream.converters.reflection.ExternalizableConverter;
/*      */ import com.thoughtworks.xstream.converters.reflection.ReflectionConverter;
/*      */ import com.thoughtworks.xstream.converters.reflection.ReflectionProvider;
/*      */ import com.thoughtworks.xstream.converters.reflection.SelfStreamingInstanceChecker;
/*      */ import com.thoughtworks.xstream.converters.reflection.SerializableConverter;
/*      */ import com.thoughtworks.xstream.core.DefaultConverterLookup;
/*      */ import com.thoughtworks.xstream.core.JVM;
/*      */ import com.thoughtworks.xstream.core.MapBackedDataHolder;
/*      */ import com.thoughtworks.xstream.core.ReferenceByIdMarshallingStrategy;
/*      */ import com.thoughtworks.xstream.core.ReferenceByXPathMarshallingStrategy;
/*      */ import com.thoughtworks.xstream.core.TreeMarshallingStrategy;
/*      */ import com.thoughtworks.xstream.core.util.ClassLoaderReference;
/*      */ import com.thoughtworks.xstream.core.util.CompositeClassLoader;
/*      */ import com.thoughtworks.xstream.core.util.CustomObjectInputStream;
/*      */ import com.thoughtworks.xstream.core.util.CustomObjectInputStream.StreamCallback;
/*      */ import com.thoughtworks.xstream.core.util.CustomObjectOutputStream;
/*      */ import com.thoughtworks.xstream.core.util.CustomObjectOutputStream.StreamCallback;
/*      */ import com.thoughtworks.xstream.io.HierarchicalStreamDriver;
/*      */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*      */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*      */ import com.thoughtworks.xstream.io.StatefulWriter;
/*      */ import com.thoughtworks.xstream.io.xml.XppDriver;
/*      */ import com.thoughtworks.xstream.mapper.AnnotationConfiguration;
/*      */ import com.thoughtworks.xstream.mapper.ArrayMapper;
/*      */ import com.thoughtworks.xstream.mapper.AttributeAliasingMapper;
/*      */ import com.thoughtworks.xstream.mapper.AttributeMapper;
/*      */ import com.thoughtworks.xstream.mapper.CachingMapper;
/*      */ import com.thoughtworks.xstream.mapper.ClassAliasingMapper;
/*      */ import com.thoughtworks.xstream.mapper.DefaultImplementationsMapper;
/*      */ import com.thoughtworks.xstream.mapper.DefaultMapper;
/*      */ import com.thoughtworks.xstream.mapper.DynamicProxyMapper;
/*      */ import com.thoughtworks.xstream.mapper.FieldAliasingMapper;
/*      */ import com.thoughtworks.xstream.mapper.ImmutableTypesMapper;
/*      */ import com.thoughtworks.xstream.mapper.ImplicitCollectionMapper;
/*      */ import com.thoughtworks.xstream.mapper.LocalConversionMapper;
/*      */ import com.thoughtworks.xstream.mapper.Mapper;
/*      */ import com.thoughtworks.xstream.mapper.Mapper.Null;
/*      */ import com.thoughtworks.xstream.mapper.MapperWrapper;
/*      */ import com.thoughtworks.xstream.mapper.OuterClassMapper;
/*      */ import com.thoughtworks.xstream.mapper.PackageAliasingMapper;
/*      */ import com.thoughtworks.xstream.mapper.SystemAttributeAliasingMapper;
/*      */ import com.thoughtworks.xstream.mapper.XStream11XmlFriendlyMapper;
/*      */ import java.io.EOFException;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.NotActiveException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectInputValidation;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.StringReader;
/*      */ import java.io.StringWriter;
/*      */ import java.io.Writer;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.InvocationHandler;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Proxy;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.net.URL;
/*      */ import java.util.ArrayList;
/*      */ import java.util.BitSet;
/*      */ import java.util.Calendar;
/*      */ import java.util.Date;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Hashtable;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import java.util.TreeMap;
/*      */ import java.util.TreeSet;
/*      */ import java.util.Vector;
/*      */ 
/*      */ public class XStream
/*      */ {
/*      */   private ReflectionProvider reflectionProvider;
/*      */   private HierarchicalStreamDriver hierarchicalStreamDriver;
/*      */   private ClassLoaderReference classLoaderReference;
/*      */   private MarshallingStrategy marshallingStrategy;
/*      */   private ConverterLookup converterLookup;
/*      */   private ConverterRegistry converterRegistry;
/*      */   private Mapper mapper;
/*      */   private PackageAliasingMapper packageAliasingMapper;
/*      */   private ClassAliasingMapper classAliasingMapper;
/*      */   private FieldAliasingMapper fieldAliasingMapper;
/*      */   private AttributeAliasingMapper attributeAliasingMapper;
/*      */   private SystemAttributeAliasingMapper systemAttributeAliasingMapper;
/*      */   private AttributeMapper attributeMapper;
/*      */   private DefaultImplementationsMapper defaultImplementationsMapper;
/*      */   private ImmutableTypesMapper immutableTypesMapper;
/*      */   private ImplicitCollectionMapper implicitCollectionMapper;
/*      */   private LocalConversionMapper localConversionMapper;
/*      */   private AnnotationConfiguration annotationConfiguration;
/*  297 */   private transient JVM jvm = new JVM();
/*      */   public static final int NO_REFERENCES = 1001;
/*      */   public static final int ID_REFERENCES = 1002;
/*      */   public static final int XPATH_RELATIVE_REFERENCES = 1003;
/*      */   public static final int XPATH_ABSOLUTE_REFERENCES = 1004;
/*      */ 
/*      */   /** @deprecated */
/*      */   public static final int XPATH_REFERENCES = 1003;
/*      */   public static final int PRIORITY_VERY_HIGH = 10000;
/*      */   public static final int PRIORITY_NORMAL = 0;
/*      */   public static final int PRIORITY_LOW = -10;
/*      */   public static final int PRIORITY_VERY_LOW = -20;
/*      */   private static final String ANNOTATION_MAPPER_TYPE = "com.thoughtworks.xstream.mapper.AnnotationMapper";
/*      */ 
/*      */   public XStream()
/*      */   {
/*  323 */     this(null, (Mapper)null, new XppDriver());
/*      */   }
/*      */ 
/*      */   public XStream(ReflectionProvider reflectionProvider)
/*      */   {
/*  332 */     this(reflectionProvider, (Mapper)null, new XppDriver());
/*      */   }
/*      */ 
/*      */   public XStream(HierarchicalStreamDriver hierarchicalStreamDriver)
/*      */   {
/*  342 */     this(null, (Mapper)null, hierarchicalStreamDriver);
/*      */   }
/*      */ 
/*      */   public XStream(ReflectionProvider reflectionProvider, HierarchicalStreamDriver hierarchicalStreamDriver)
/*      */   {
/*  352 */     this(reflectionProvider, (Mapper)null, hierarchicalStreamDriver);
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public XStream(ReflectionProvider reflectionProvider, ClassMapper classMapper, HierarchicalStreamDriver driver)
/*      */   {
/*  362 */     this(reflectionProvider, classMapper, driver);
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public XStream(ReflectionProvider reflectionProvider, ClassMapper classMapper, HierarchicalStreamDriver driver, String classAttributeIdentifier)
/*      */   {
/*  373 */     this(reflectionProvider, classMapper, driver);
/*  374 */     aliasAttribute(classAttributeIdentifier, "class");
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public XStream(ReflectionProvider reflectionProvider, Mapper mapper, HierarchicalStreamDriver driver)
/*      */   {
/*  385 */     this(reflectionProvider, driver, new ClassLoaderReference(new CompositeClassLoader()), mapper, new DefaultConverterLookup(), null);
/*      */   }
/*      */ 
/*      */   public XStream(ReflectionProvider reflectionProvider, HierarchicalStreamDriver driver, ClassLoader classLoader)
/*      */   {
/*  397 */     this(reflectionProvider, driver, classLoader, null);
/*      */   }
/*      */ 
/*      */   public XStream(ReflectionProvider reflectionProvider, HierarchicalStreamDriver driver, ClassLoader classLoader, Mapper mapper)
/*      */   {
/*  412 */     this(reflectionProvider, driver, classLoader, mapper, new DefaultConverterLookup(), null);
/*      */   }
/*      */ 
/*      */   public XStream(ReflectionProvider reflectionProvider, HierarchicalStreamDriver driver, ClassLoader classLoader, Mapper mapper, ConverterLookup converterLookup, ConverterRegistry converterRegistry)
/*      */   {
/*  429 */     this.jvm = new JVM();
/*  430 */     if (reflectionProvider == null) {
/*  431 */       reflectionProvider = this.jvm.bestReflectionProvider();
/*      */     }
/*  433 */     this.reflectionProvider = reflectionProvider;
/*  434 */     this.hierarchicalStreamDriver = driver;
/*  435 */     this.classLoaderReference = ((classLoader instanceof ClassLoaderReference) ? (ClassLoaderReference)classLoader : new ClassLoaderReference(classLoader));
/*  436 */     this.converterLookup = converterLookup;
/*  437 */     this.converterRegistry = ((converterLookup instanceof ConverterRegistry) ? (ConverterRegistry)converterLookup : converterRegistry != null ? converterRegistry : null);
/*      */ 
/*  440 */     this.mapper = (mapper == null ? buildMapper() : mapper);
/*      */ 
/*  442 */     setupMappers();
/*  443 */     setupAliases();
/*  444 */     setupDefaultImplementations();
/*  445 */     setupConverters();
/*  446 */     setupImmutableTypes();
/*  447 */     setMode(1003);
/*      */   }
/*      */ 
/*      */   private Mapper buildMapper() {
/*  451 */     Mapper mapper = new DefaultMapper(this.classLoaderReference);
/*  452 */     if (useXStream11XmlFriendlyMapper()) {
/*  453 */       mapper = new XStream11XmlFriendlyMapper(mapper);
/*      */     }
/*  455 */     mapper = new DynamicProxyMapper(mapper);
/*  456 */     mapper = new PackageAliasingMapper(mapper);
/*  457 */     mapper = new ClassAliasingMapper(mapper);
/*  458 */     mapper = new FieldAliasingMapper(mapper);
/*  459 */     mapper = new AttributeAliasingMapper(mapper);
/*  460 */     mapper = new SystemAttributeAliasingMapper(mapper);
/*  461 */     mapper = new ImplicitCollectionMapper(mapper);
/*  462 */     mapper = new OuterClassMapper(mapper);
/*  463 */     mapper = new ArrayMapper(mapper);
/*  464 */     mapper = new DefaultImplementationsMapper(mapper);
/*  465 */     mapper = new AttributeMapper(mapper, this.converterLookup);
/*  466 */     if (JVM.is15()) {
/*  467 */       mapper = buildMapperDynamically("com.thoughtworks.xstream.mapper.EnumMapper", new Class[] { Mapper.class }, new Object[] { mapper });
/*      */     }
/*      */ 
/*  471 */     mapper = new LocalConversionMapper(mapper);
/*  472 */     mapper = new ImmutableTypesMapper(mapper);
/*  473 */     if (JVM.is15()) {
/*  474 */       mapper = buildMapperDynamically("com.thoughtworks.xstream.mapper.AnnotationMapper", new Class[] { Mapper.class, ConverterRegistry.class, ClassLoader.class, ReflectionProvider.class, JVM.class }, new Object[] { mapper, this.converterLookup, this.classLoaderReference, this.reflectionProvider, this.jvm });
/*      */     }
/*      */ 
/*  479 */     mapper = wrapMapper((MapperWrapper)mapper);
/*  480 */     mapper = new CachingMapper(mapper);
/*  481 */     return mapper;
/*      */   }
/*      */ 
/*      */   private Mapper buildMapperDynamically(String className, Class[] constructorParamTypes, Object[] constructorParamValues)
/*      */   {
/*      */     try
/*      */     {
/*  488 */       Class type = Class.forName(className, false, this.classLoaderReference.getReference());
/*  489 */       Constructor constructor = type.getConstructor(constructorParamTypes);
/*  490 */       return (Mapper)constructor.newInstance(constructorParamValues); } catch (Exception e) {
/*      */     }
/*  492 */     throw new InitializationException("Could not instantiate mapper : " + className, e);
/*      */   }
/*      */ 
/*      */   protected MapperWrapper wrapMapper(MapperWrapper next)
/*      */   {
/*  497 */     return next;
/*      */   }
/*      */ 
/*      */   protected boolean useXStream11XmlFriendlyMapper() {
/*  501 */     return false;
/*      */   }
/*      */ 
/*      */   private void setupMappers() {
/*  505 */     this.packageAliasingMapper = ((PackageAliasingMapper)this.mapper.lookupMapperOfType(PackageAliasingMapper.class));
/*      */ 
/*  507 */     this.classAliasingMapper = ((ClassAliasingMapper)this.mapper.lookupMapperOfType(ClassAliasingMapper.class));
/*      */ 
/*  509 */     this.fieldAliasingMapper = ((FieldAliasingMapper)this.mapper.lookupMapperOfType(FieldAliasingMapper.class));
/*      */ 
/*  511 */     this.attributeMapper = ((AttributeMapper)this.mapper.lookupMapperOfType(AttributeMapper.class));
/*  512 */     this.attributeAliasingMapper = ((AttributeAliasingMapper)this.mapper.lookupMapperOfType(AttributeAliasingMapper.class));
/*      */ 
/*  514 */     this.systemAttributeAliasingMapper = ((SystemAttributeAliasingMapper)this.mapper.lookupMapperOfType(SystemAttributeAliasingMapper.class));
/*      */ 
/*  516 */     this.implicitCollectionMapper = ((ImplicitCollectionMapper)this.mapper.lookupMapperOfType(ImplicitCollectionMapper.class));
/*      */ 
/*  518 */     this.defaultImplementationsMapper = ((DefaultImplementationsMapper)this.mapper.lookupMapperOfType(DefaultImplementationsMapper.class));
/*      */ 
/*  520 */     this.immutableTypesMapper = ((ImmutableTypesMapper)this.mapper.lookupMapperOfType(ImmutableTypesMapper.class));
/*      */ 
/*  522 */     this.localConversionMapper = ((LocalConversionMapper)this.mapper.lookupMapperOfType(LocalConversionMapper.class));
/*      */ 
/*  524 */     this.annotationConfiguration = ((AnnotationConfiguration)this.mapper.lookupMapperOfType(AnnotationConfiguration.class));
/*      */   }
/*      */ 
/*      */   protected void setupAliases()
/*      */   {
/*  529 */     if (this.classAliasingMapper == null) {
/*  530 */       return;
/*      */     }
/*      */ 
/*  533 */     alias("null", Mapper.Null.class);
/*  534 */     alias("int", Integer.class);
/*  535 */     alias("float", Float.class);
/*  536 */     alias("double", Double.class);
/*  537 */     alias("long", Long.class);
/*  538 */     alias("short", Short.class);
/*  539 */     alias("char", Character.class);
/*  540 */     alias("byte", Byte.class);
/*  541 */     alias("boolean", Boolean.class);
/*  542 */     alias("number", Number.class);
/*  543 */     alias("object", Object.class);
/*  544 */     alias("big-int", BigInteger.class);
/*  545 */     alias("big-decimal", BigDecimal.class);
/*      */ 
/*  547 */     alias("string-buffer", StringBuffer.class);
/*  548 */     alias("string", String.class);
/*  549 */     alias("java-class", Class.class);
/*  550 */     alias("method", Method.class);
/*  551 */     alias("constructor", Constructor.class);
/*  552 */     alias("date", Date.class);
/*  553 */     alias("url", URL.class);
/*  554 */     alias("bit-set", BitSet.class);
/*      */ 
/*  556 */     alias("map", Map.class);
/*  557 */     alias("entry", Map.Entry.class);
/*  558 */     alias("properties", Properties.class);
/*  559 */     alias("list", List.class);
/*  560 */     alias("set", Set.class);
/*      */ 
/*  562 */     alias("linked-list", LinkedList.class);
/*  563 */     alias("vector", Vector.class);
/*  564 */     alias("tree-map", TreeMap.class);
/*  565 */     alias("tree-set", TreeSet.class);
/*  566 */     alias("hashtable", Hashtable.class);
/*      */ 
/*  568 */     if (this.jvm.supportsAWT())
/*      */     {
/*  572 */       alias("awt-color", this.jvm.loadClass("java.awt.Color"));
/*  573 */       alias("awt-font", this.jvm.loadClass("java.awt.Font"));
/*  574 */       alias("awt-text-attribute", this.jvm.loadClass("java.awt.font.TextAttribute"));
/*      */     }
/*      */ 
/*  577 */     if (this.jvm.supportsSQL()) {
/*  578 */       alias("sql-timestamp", this.jvm.loadClass("java.sql.Timestamp"));
/*  579 */       alias("sql-time", this.jvm.loadClass("java.sql.Time"));
/*  580 */       alias("sql-date", this.jvm.loadClass("java.sql.Date"));
/*      */     }
/*      */ 
/*  583 */     alias("file", File.class);
/*  584 */     alias("locale", Locale.class);
/*  585 */     alias("gregorian-calendar", Calendar.class);
/*      */ 
/*  587 */     if (JVM.is14()) {
/*  588 */       alias("auth-subject", this.jvm.loadClass("javax.security.auth.Subject"));
/*  589 */       alias("linked-hash-map", this.jvm.loadClass("java.util.LinkedHashMap"));
/*  590 */       alias("linked-hash-set", this.jvm.loadClass("java.util.LinkedHashSet"));
/*  591 */       alias("trace", this.jvm.loadClass("java.lang.StackTraceElement"));
/*  592 */       alias("currency", this.jvm.loadClass("java.util.Currency"));
/*  593 */       aliasType("charset", this.jvm.loadClass("java.nio.charset.Charset"));
/*      */     }
/*      */ 
/*  596 */     if (JVM.is15()) {
/*  597 */       alias("duration", this.jvm.loadClass("javax.xml.datatype.Duration"));
/*  598 */       alias("enum-set", this.jvm.loadClass("java.util.EnumSet"));
/*  599 */       alias("enum-map", this.jvm.loadClass("java.util.EnumMap"));
/*  600 */       alias("string-builder", this.jvm.loadClass("java.lang.StringBuilder"));
/*  601 */       alias("uuid", this.jvm.loadClass("java.util.UUID"));
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void setupDefaultImplementations() {
/*  606 */     if (this.defaultImplementationsMapper == null) {
/*  607 */       return;
/*      */     }
/*  609 */     addDefaultImplementation(HashMap.class, Map.class);
/*  610 */     addDefaultImplementation(ArrayList.class, List.class);
/*  611 */     addDefaultImplementation(HashSet.class, Set.class);
/*  612 */     addDefaultImplementation(GregorianCalendar.class, Calendar.class);
/*      */   }
/*      */ 
/*      */   protected void setupConverters() {
/*  616 */     ReflectionConverter reflectionConverter = new ReflectionConverter(this.mapper, this.reflectionProvider);
/*      */ 
/*  618 */     registerConverter(reflectionConverter, -20);
/*      */ 
/*  620 */     registerConverter(new SerializableConverter(this.mapper, this.reflectionProvider), -10);
/*  621 */     registerConverter(new ExternalizableConverter(this.mapper), -10);
/*      */ 
/*  623 */     registerConverter(new NullConverter(), 10000);
/*  624 */     registerConverter(new IntConverter(), 0);
/*  625 */     registerConverter(new FloatConverter(), 0);
/*  626 */     registerConverter(new DoubleConverter(), 0);
/*  627 */     registerConverter(new LongConverter(), 0);
/*  628 */     registerConverter(new ShortConverter(), 0);
/*  629 */     registerConverter(new CharConverter(), 0);
/*  630 */     registerConverter(new BooleanConverter(), 0);
/*  631 */     registerConverter(new ByteConverter(), 0);
/*      */ 
/*  633 */     registerConverter(new StringConverter(), 0);
/*  634 */     registerConverter(new StringBufferConverter(), 0);
/*  635 */     registerConverter(new DateConverter(), 0);
/*  636 */     registerConverter(new BitSetConverter(), 0);
/*  637 */     registerConverter(new URLConverter(), 0);
/*  638 */     registerConverter(new BigIntegerConverter(), 0);
/*  639 */     registerConverter(new BigDecimalConverter(), 0);
/*      */ 
/*  641 */     registerConverter(new ArrayConverter(this.mapper), 0);
/*  642 */     registerConverter(new CharArrayConverter(), 0);
/*  643 */     registerConverter(new CollectionConverter(this.mapper), 0);
/*  644 */     registerConverter(new MapConverter(this.mapper), 0);
/*  645 */     registerConverter(new TreeMapConverter(this.mapper), 0);
/*  646 */     registerConverter(new TreeSetConverter(this.mapper), 0);
/*  647 */     registerConverter(new PropertiesConverter(), 0);
/*  648 */     registerConverter(new EncodedByteArrayConverter(), 0);
/*      */ 
/*  650 */     registerConverter(new FileConverter(), 0);
/*  651 */     if (this.jvm.supportsSQL()) {
/*  652 */       registerConverter(new SqlTimestampConverter(), 0);
/*  653 */       registerConverter(new SqlTimeConverter(), 0);
/*  654 */       registerConverter(new SqlDateConverter(), 0);
/*      */     }
/*  656 */     registerConverter(new DynamicProxyConverter(this.mapper, this.classLoaderReference), 0);
/*  657 */     registerConverter(new JavaClassConverter(this.classLoaderReference), 0);
/*  658 */     registerConverter(new JavaMethodConverter(this.classLoaderReference), 0);
/*  659 */     if (this.jvm.supportsAWT()) {
/*  660 */       registerConverter(new FontConverter(), 0);
/*  661 */       registerConverter(new ColorConverter(), 0);
/*  662 */       registerConverter(new TextAttributeConverter(), 0);
/*      */     }
/*  664 */     if (this.jvm.supportsSwing()) {
/*  665 */       registerConverter(new LookAndFeelConverter(this.mapper, this.reflectionProvider), 0);
/*      */     }
/*  667 */     registerConverter(new LocaleConverter(), 0);
/*  668 */     registerConverter(new GregorianCalendarConverter(), 0);
/*      */ 
/*  670 */     if (JVM.is14())
/*      */     {
/*  672 */       dynamicallyRegisterConverter("com.thoughtworks.xstream.converters.extended.SubjectConverter", 0, new Class[] { Mapper.class }, new Object[] { this.mapper });
/*      */ 
/*  675 */       dynamicallyRegisterConverter("com.thoughtworks.xstream.converters.extended.ThrowableConverter", 0, new Class[] { Converter.class }, new Object[] { reflectionConverter });
/*      */ 
/*  679 */       dynamicallyRegisterConverter("com.thoughtworks.xstream.converters.extended.StackTraceElementConverter", 0, null, null);
/*      */ 
/*  682 */       dynamicallyRegisterConverter("com.thoughtworks.xstream.converters.extended.CurrencyConverter", 0, null, null);
/*      */ 
/*  685 */       dynamicallyRegisterConverter("com.thoughtworks.xstream.converters.extended.RegexPatternConverter", 0, new Class[] { Converter.class }, new Object[] { reflectionConverter });
/*      */ 
/*  689 */       dynamicallyRegisterConverter("com.thoughtworks.xstream.converters.extended.CharsetConverter", 0, null, null);
/*      */     }
/*      */ 
/*  694 */     if (JVM.is15())
/*      */     {
/*  696 */       dynamicallyRegisterConverter("com.thoughtworks.xstream.converters.extended.DurationConverter", 0, null, null);
/*      */ 
/*  699 */       dynamicallyRegisterConverter("com.thoughtworks.xstream.converters.enums.EnumConverter", 0, null, null);
/*      */ 
/*  702 */       dynamicallyRegisterConverter("com.thoughtworks.xstream.converters.enums.EnumSetConverter", 0, new Class[] { Mapper.class }, new Object[] { this.mapper });
/*      */ 
/*  705 */       dynamicallyRegisterConverter("com.thoughtworks.xstream.converters.enums.EnumMapConverter", 0, new Class[] { Mapper.class }, new Object[] { this.mapper });
/*      */ 
/*  708 */       dynamicallyRegisterConverter("com.thoughtworks.xstream.converters.basic.StringBuilderConverter", 0, null, null);
/*      */ 
/*  711 */       dynamicallyRegisterConverter("com.thoughtworks.xstream.converters.basic.UUIDConverter", 0, null, null);
/*      */     }
/*      */ 
/*  716 */     registerConverter(new SelfStreamingInstanceChecker(reflectionConverter, this), 0);
/*      */   }
/*      */ 
/*      */   private void dynamicallyRegisterConverter(String className, int priority, Class[] constructorParamTypes, Object[] constructorParamValues)
/*      */   {
/*      */     try
/*      */     {
/*  723 */       Class type = Class.forName(className, false, this.classLoaderReference.getReference());
/*  724 */       Constructor constructor = type.getConstructor(constructorParamTypes);
/*  725 */       Object instance = constructor.newInstance(constructorParamValues);
/*  726 */       if ((instance instanceof Converter))
/*  727 */         registerConverter((Converter)instance, priority);
/*  728 */       else if ((instance instanceof SingleValueConverter))
/*  729 */         registerConverter((SingleValueConverter)instance, priority);
/*      */     }
/*      */     catch (Exception e) {
/*  732 */       throw new InitializationException("Could not instantiate converter : " + className, e);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void setupImmutableTypes() {
/*  737 */     if (this.immutableTypesMapper == null) {
/*  738 */       return;
/*      */     }
/*      */ 
/*  742 */     addImmutableType(Boolean.TYPE);
/*  743 */     addImmutableType(Boolean.class);
/*  744 */     addImmutableType(Byte.TYPE);
/*  745 */     addImmutableType(Byte.class);
/*  746 */     addImmutableType(Character.TYPE);
/*  747 */     addImmutableType(Character.class);
/*  748 */     addImmutableType(Double.TYPE);
/*  749 */     addImmutableType(Double.class);
/*  750 */     addImmutableType(Float.TYPE);
/*  751 */     addImmutableType(Float.class);
/*  752 */     addImmutableType(Integer.TYPE);
/*  753 */     addImmutableType(Integer.class);
/*  754 */     addImmutableType(Long.TYPE);
/*  755 */     addImmutableType(Long.class);
/*  756 */     addImmutableType(Short.TYPE);
/*  757 */     addImmutableType(Short.class);
/*      */ 
/*  760 */     addImmutableType(Mapper.Null.class);
/*  761 */     addImmutableType(BigDecimal.class);
/*  762 */     addImmutableType(BigInteger.class);
/*  763 */     addImmutableType(String.class);
/*  764 */     addImmutableType(URL.class);
/*  765 */     addImmutableType(File.class);
/*  766 */     addImmutableType(Class.class);
/*      */ 
/*  768 */     if (this.jvm.supportsAWT()) {
/*  769 */       addImmutableType(this.jvm.loadClass("java.awt.font.TextAttribute"));
/*      */     }
/*      */ 
/*  772 */     if (JVM.is14())
/*      */     {
/*  774 */       Class type = this.jvm.loadClass("com.thoughtworks.xstream.converters.extended.CharsetConverter");
/*  775 */       addImmutableType(type);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setMarshallingStrategy(MarshallingStrategy marshallingStrategy) {
/*  780 */     this.marshallingStrategy = marshallingStrategy;
/*      */   }
/*      */ 
/*      */   public String toXML(Object obj)
/*      */   {
/*  788 */     Writer writer = new StringWriter();
/*  789 */     toXML(obj, writer);
/*  790 */     return writer.toString();
/*      */   }
/*      */ 
/*      */   public void toXML(Object obj, Writer out)
/*      */   {
/*  799 */     HierarchicalStreamWriter writer = this.hierarchicalStreamDriver.createWriter(out);
/*      */     try {
/*  801 */       marshal(obj, writer);
/*      */     } finally {
/*  803 */       writer.flush();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void toXML(Object obj, OutputStream out)
/*      */   {
/*  813 */     HierarchicalStreamWriter writer = this.hierarchicalStreamDriver.createWriter(out);
/*      */     try {
/*  815 */       marshal(obj, writer);
/*      */     } finally {
/*  817 */       writer.flush();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void marshal(Object obj, HierarchicalStreamWriter writer)
/*      */   {
/*  826 */     marshal(obj, writer, null);
/*      */   }
/*      */ 
/*      */   public void marshal(Object obj, HierarchicalStreamWriter writer, DataHolder dataHolder)
/*      */   {
/*  837 */     this.marshallingStrategy.marshal(writer, obj, this.converterLookup, this.mapper, dataHolder);
/*      */   }
/*      */ 
/*      */   public Object fromXML(String xml)
/*      */   {
/*  845 */     return fromXML(new StringReader(xml));
/*      */   }
/*      */ 
/*      */   public Object fromXML(Reader xml)
/*      */   {
/*  853 */     return unmarshal(this.hierarchicalStreamDriver.createReader(xml), null);
/*      */   }
/*      */ 
/*      */   public Object fromXML(InputStream input)
/*      */   {
/*  861 */     return unmarshal(this.hierarchicalStreamDriver.createReader(input), null);
/*      */   }
/*      */ 
/*      */   public Object fromXML(String xml, Object root)
/*      */   {
/*  871 */     return fromXML(new StringReader(xml), root);
/*      */   }
/*      */ 
/*      */   public Object fromXML(Reader xml, Object root)
/*      */   {
/*  881 */     return unmarshal(this.hierarchicalStreamDriver.createReader(xml), root);
/*      */   }
/*      */ 
/*      */   public Object fromXML(InputStream xml, Object root)
/*      */   {
/*  891 */     return unmarshal(this.hierarchicalStreamDriver.createReader(xml), root);
/*      */   }
/*      */ 
/*      */   public Object unmarshal(HierarchicalStreamReader reader)
/*      */   {
/*  899 */     return unmarshal(reader, null, null);
/*      */   }
/*      */ 
/*      */   public Object unmarshal(HierarchicalStreamReader reader, Object root)
/*      */   {
/*  909 */     return unmarshal(reader, root, null);
/*      */   }
/*      */ 
/*      */   public Object unmarshal(HierarchicalStreamReader reader, Object root, DataHolder dataHolder)
/*      */   {
/*  923 */     return this.marshallingStrategy.unmarshal(root, reader, dataHolder, this.converterLookup, this.mapper);
/*      */   }
/*      */ 
/*      */   public void alias(String name, Class type)
/*      */   {
/*  934 */     if (this.classAliasingMapper == null) {
/*  935 */       throw new InitializationException("No " + ClassAliasingMapper.class.getName() + " available");
/*      */     }
/*      */ 
/*  939 */     this.classAliasingMapper.addClassAlias(name, type);
/*      */   }
/*      */ 
/*      */   public void aliasType(String name, Class type)
/*      */   {
/*  952 */     if (this.classAliasingMapper == null) {
/*  953 */       throw new InitializationException("No " + ClassAliasingMapper.class.getName() + " available");
/*      */     }
/*      */ 
/*  957 */     this.classAliasingMapper.addTypeAlias(name, type);
/*      */   }
/*      */ 
/*      */   public void alias(String name, Class type, Class defaultImplementation)
/*      */   {
/*  969 */     alias(name, type);
/*  970 */     addDefaultImplementation(defaultImplementation, type);
/*      */   }
/*      */ 
/*      */   public void aliasPackage(String name, String pkgName)
/*      */   {
/*  982 */     if (this.packageAliasingMapper == null) {
/*  983 */       throw new InitializationException("No " + PackageAliasingMapper.class.getName() + " available");
/*      */     }
/*      */ 
/*  987 */     this.packageAliasingMapper.addPackageAlias(name, pkgName);
/*      */   }
/*      */ 
/*      */   public void aliasField(String alias, Class definedIn, String fieldName)
/*      */   {
/*  999 */     if (this.fieldAliasingMapper == null) {
/* 1000 */       throw new InitializationException("No " + FieldAliasingMapper.class.getName() + " available");
/*      */     }
/*      */ 
/* 1004 */     this.fieldAliasingMapper.addFieldAlias(alias, definedIn, fieldName);
/*      */   }
/*      */ 
/*      */   public void aliasAttribute(String alias, String attributeName)
/*      */   {
/* 1015 */     if (this.attributeAliasingMapper == null) {
/* 1016 */       throw new InitializationException("No " + AttributeAliasingMapper.class.getName() + " available");
/*      */     }
/*      */ 
/* 1020 */     this.attributeAliasingMapper.addAliasFor(attributeName, alias);
/*      */   }
/*      */ 
/*      */   public void aliasSystemAttribute(String alias, String systemAttributeName)
/*      */   {
/* 1036 */     if (this.systemAttributeAliasingMapper == null) {
/* 1037 */       throw new InitializationException("No " + SystemAttributeAliasingMapper.class.getName() + " available");
/*      */     }
/*      */ 
/* 1041 */     this.systemAttributeAliasingMapper.addAliasFor(systemAttributeName, alias);
/*      */   }
/*      */ 
/*      */   public void aliasAttribute(Class definedIn, String attributeName, String alias)
/*      */   {
/* 1054 */     aliasField(alias, definedIn, attributeName);
/* 1055 */     useAttributeFor(definedIn, attributeName);
/*      */   }
/*      */ 
/*      */   public void useAttributeFor(String fieldName, Class type)
/*      */   {
/* 1067 */     if (this.attributeMapper == null) {
/* 1068 */       throw new InitializationException("No " + AttributeMapper.class.getName() + " available");
/*      */     }
/* 1070 */     this.attributeMapper.addAttributeFor(fieldName, type);
/*      */   }
/*      */ 
/*      */   public void useAttributeFor(Class definedIn, String fieldName)
/*      */   {
/* 1082 */     if (this.attributeMapper == null) {
/* 1083 */       throw new InitializationException("No " + AttributeMapper.class.getName() + " available");
/*      */     }
/* 1085 */     this.attributeMapper.addAttributeFor(definedIn, fieldName);
/*      */   }
/*      */ 
/*      */   public void useAttributeFor(Class type)
/*      */   {
/* 1096 */     if (this.attributeMapper == null) {
/* 1097 */       throw new InitializationException("No " + AttributeMapper.class.getName() + " available");
/*      */     }
/* 1099 */     this.attributeMapper.addAttributeFor(type);
/*      */   }
/*      */ 
/*      */   public void addDefaultImplementation(Class defaultImplementation, Class ofType)
/*      */   {
/* 1112 */     if (this.defaultImplementationsMapper == null) {
/* 1113 */       throw new InitializationException("No " + DefaultImplementationsMapper.class.getName() + " available");
/*      */     }
/*      */ 
/* 1117 */     this.defaultImplementationsMapper.addDefaultImplementation(defaultImplementation, ofType);
/*      */   }
/*      */ 
/*      */   public void addImmutableType(Class type)
/*      */   {
/* 1126 */     if (this.immutableTypesMapper == null) {
/* 1127 */       throw new InitializationException("No " + ImmutableTypesMapper.class.getName() + " available");
/*      */     }
/*      */ 
/* 1131 */     this.immutableTypesMapper.addImmutableType(type);
/*      */   }
/*      */ 
/*      */   public void registerConverter(Converter converter) {
/* 1135 */     registerConverter(converter, 0);
/*      */   }
/*      */ 
/*      */   public void registerConverter(Converter converter, int priority) {
/* 1139 */     if (this.converterRegistry != null)
/* 1140 */       this.converterRegistry.registerConverter(converter, priority);
/*      */   }
/*      */ 
/*      */   public void registerConverter(SingleValueConverter converter)
/*      */   {
/* 1145 */     registerConverter(converter, 0);
/*      */   }
/*      */ 
/*      */   public void registerConverter(SingleValueConverter converter, int priority) {
/* 1149 */     if (this.converterRegistry != null)
/* 1150 */       this.converterRegistry.registerConverter(new SingleValueConverterWrapper(converter), priority);
/*      */   }
/*      */ 
/*      */   public void registerLocalConverter(Class definedIn, String fieldName, Converter converter)
/*      */   {
/* 1163 */     if (this.localConversionMapper == null) {
/* 1164 */       throw new InitializationException("No " + LocalConversionMapper.class.getName() + " available");
/*      */     }
/*      */ 
/* 1168 */     this.localConversionMapper.registerLocalConverter(definedIn, fieldName, converter);
/*      */   }
/*      */ 
/*      */   public void registerLocalConverter(Class definedIn, String fieldName, SingleValueConverter converter)
/*      */   {
/* 1180 */     registerLocalConverter(definedIn, fieldName, new SingleValueConverterWrapper(converter));
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public ClassMapper getClassMapper()
/*      */   {
/* 1188 */     if ((this.mapper instanceof ClassMapper)) {
/* 1189 */       return (ClassMapper)this.mapper;
/*      */     }
/* 1191 */     return (ClassMapper)Proxy.newProxyInstance(getClassLoader(), new Class[] { ClassMapper.class }, new InvocationHandler()
/*      */     {
/*      */       public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/* 1194 */         return method.invoke(XStream.this.mapper, args);
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public Mapper getMapper()
/*      */   {
/* 1207 */     return this.mapper;
/*      */   }
/*      */ 
/*      */   public ReflectionProvider getReflectionProvider()
/*      */   {
/* 1217 */     return this.reflectionProvider;
/*      */   }
/*      */ 
/*      */   public ConverterLookup getConverterLookup() {
/* 1221 */     return this.converterLookup;
/*      */   }
/*      */ 
/*      */   public void setMode(int mode)
/*      */   {
/* 1236 */     switch (mode) {
/*      */     case 1001:
/* 1238 */       setMarshallingStrategy(new TreeMarshallingStrategy());
/* 1239 */       break;
/*      */     case 1002:
/* 1241 */       setMarshallingStrategy(new ReferenceByIdMarshallingStrategy());
/* 1242 */       break;
/*      */     case 1003:
/* 1244 */       setMarshallingStrategy(new ReferenceByXPathMarshallingStrategy(ReferenceByXPathMarshallingStrategy.RELATIVE));
/*      */ 
/* 1246 */       break;
/*      */     case 1004:
/* 1248 */       setMarshallingStrategy(new ReferenceByXPathMarshallingStrategy(ReferenceByXPathMarshallingStrategy.ABSOLUTE));
/*      */ 
/* 1250 */       break;
/*      */     default:
/* 1252 */       throw new IllegalArgumentException("Unknown mode : " + mode);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void addImplicitCollection(Class ownerType, String fieldName)
/*      */   {
/* 1265 */     if (this.implicitCollectionMapper == null) {
/* 1266 */       throw new InitializationException("No " + ImplicitCollectionMapper.class.getName() + " available");
/*      */     }
/*      */ 
/* 1270 */     this.implicitCollectionMapper.add(ownerType, fieldName, null, null);
/*      */   }
/*      */ 
/*      */   public void addImplicitCollection(Class ownerType, String fieldName, Class itemType)
/*      */   {
/* 1284 */     if (this.implicitCollectionMapper == null) {
/* 1285 */       throw new InitializationException("No " + ImplicitCollectionMapper.class.getName() + " available");
/*      */     }
/*      */ 
/* 1289 */     this.implicitCollectionMapper.add(ownerType, fieldName, null, itemType);
/*      */   }
/*      */ 
/*      */   public void addImplicitCollection(Class ownerType, String fieldName, String itemFieldName, Class itemType)
/*      */   {
/* 1306 */     if (this.implicitCollectionMapper == null) {
/* 1307 */       throw new InitializationException("No " + ImplicitCollectionMapper.class.getName() + " available");
/*      */     }
/*      */ 
/* 1311 */     this.implicitCollectionMapper.add(ownerType, fieldName, itemFieldName, itemType);
/*      */   }
/*      */ 
/*      */   public DataHolder newDataHolder()
/*      */   {
/* 1322 */     return new MapBackedDataHolder();
/*      */   }
/*      */ 
/*      */   public ObjectOutputStream createObjectOutputStream(Writer writer)
/*      */     throws IOException
/*      */   {
/* 1338 */     return createObjectOutputStream(this.hierarchicalStreamDriver.createWriter(writer), "object-stream");
/*      */   }
/*      */ 
/*      */   public ObjectOutputStream createObjectOutputStream(HierarchicalStreamWriter writer)
/*      */     throws IOException
/*      */   {
/* 1355 */     return createObjectOutputStream(writer, "object-stream");
/*      */   }
/*      */ 
/*      */   public ObjectOutputStream createObjectOutputStream(Writer writer, String rootNodeName)
/*      */     throws IOException
/*      */   {
/* 1368 */     return createObjectOutputStream(this.hierarchicalStreamDriver.createWriter(writer), rootNodeName);
/*      */   }
/*      */ 
/*      */   public ObjectOutputStream createObjectOutputStream(OutputStream out)
/*      */     throws IOException
/*      */   {
/* 1384 */     return createObjectOutputStream(this.hierarchicalStreamDriver.createWriter(out), "object-stream");
/*      */   }
/*      */ 
/*      */   public ObjectOutputStream createObjectOutputStream(OutputStream out, String rootNodeName)
/*      */     throws IOException
/*      */   {
/* 1397 */     return createObjectOutputStream(this.hierarchicalStreamDriver.createWriter(out), rootNodeName);
/*      */   }
/*      */ 
/*      */   public ObjectOutputStream createObjectOutputStream(HierarchicalStreamWriter writer, String rootNodeName)
/*      */     throws IOException
/*      */   {
/* 1428 */     StatefulWriter statefulWriter = new StatefulWriter(writer);
/* 1429 */     statefulWriter.startNode(rootNodeName, null);
/* 1430 */     return new CustomObjectOutputStream(new CustomObjectOutputStream.StreamCallback(statefulWriter) { private final StatefulWriter val$statefulWriter;
/*      */ 
/* 1432 */       public void writeToStream(Object object) { XStream.this.marshal(object, this.val$statefulWriter); }
/*      */ 
/*      */       public void writeFieldsToStream(Map fields) throws NotActiveException
/*      */       {
/* 1436 */         throw new NotActiveException("not in call to writeObject");
/*      */       }
/*      */ 
/*      */       public void defaultWriteObject() throws NotActiveException {
/* 1440 */         throw new NotActiveException("not in call to writeObject");
/*      */       }
/*      */ 
/*      */       public void flush() {
/* 1444 */         this.val$statefulWriter.flush();
/*      */       }
/*      */ 
/*      */       public void close() {
/* 1448 */         if (this.val$statefulWriter.state() != StatefulWriter.STATE_CLOSED) {
/* 1449 */           this.val$statefulWriter.endNode();
/* 1450 */           this.val$statefulWriter.close();
/*      */         }
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public ObjectInputStream createObjectInputStream(Reader xmlReader)
/*      */     throws IOException
/*      */   {
/* 1465 */     return createObjectInputStream(this.hierarchicalStreamDriver.createReader(xmlReader));
/*      */   }
/*      */ 
/*      */   public ObjectInputStream createObjectInputStream(InputStream in)
/*      */     throws IOException
/*      */   {
/* 1477 */     return createObjectInputStream(this.hierarchicalStreamDriver.createReader(in));
/*      */   }
/*      */ 
/*      */   public ObjectInputStream createObjectInputStream(HierarchicalStreamReader reader)
/*      */     throws IOException
/*      */   {
/* 1497 */     return new CustomObjectInputStream(new CustomObjectInputStream.StreamCallback(reader) { private final HierarchicalStreamReader val$reader;
/*      */ 
/* 1499 */       public Object readFromStream() throws EOFException { if (!this.val$reader.hasMoreChildren()) {
/* 1500 */           throw new EOFException();
/*      */         }
/* 1502 */         this.val$reader.moveDown();
/* 1503 */         Object result = XStream.this.unmarshal(this.val$reader);
/* 1504 */         this.val$reader.moveUp();
/* 1505 */         return result; }
/*      */ 
/*      */       public Map readFieldsFromStream() throws IOException
/*      */       {
/* 1509 */         throw new NotActiveException("not in call to readObject");
/*      */       }
/*      */ 
/*      */       public void defaultReadObject() throws NotActiveException {
/* 1513 */         throw new NotActiveException("not in call to readObject");
/*      */       }
/*      */ 
/*      */       public void registerValidation(ObjectInputValidation validation, int priority) throws NotActiveException
/*      */       {
/* 1518 */         throw new NotActiveException("stream inactive");
/*      */       }
/*      */ 
/*      */       public void close() {
/* 1522 */         this.val$reader.close();
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public void setClassLoader(ClassLoader classLoader)
/*      */   {
/* 1538 */     this.classLoaderReference.setReference(classLoader);
/*      */   }
/*      */ 
/*      */   public ClassLoader getClassLoader()
/*      */   {
/* 1547 */     return this.classLoaderReference.getReference();
/*      */   }
/*      */ 
/*      */   public void omitField(Class definedIn, String fieldName)
/*      */   {
/* 1558 */     if (this.fieldAliasingMapper == null) {
/* 1559 */       throw new InitializationException("No " + FieldAliasingMapper.class.getName() + " available");
/*      */     }
/*      */ 
/* 1563 */     this.fieldAliasingMapper.omitField(definedIn, fieldName);
/*      */   }
/*      */ 
/*      */   public void processAnnotations(Class[] types)
/*      */   {
/* 1573 */     if (this.annotationConfiguration == null) {
/* 1574 */       throw new InitializationException("No com.thoughtworks.xstream.mapper.AnnotationMapper available");
/*      */     }
/* 1576 */     this.annotationConfiguration.processAnnotations(types);
/*      */   }
/*      */ 
/*      */   public void processAnnotations(Class type)
/*      */   {
/* 1587 */     processAnnotations(new Class[] { type });
/*      */   }
/*      */ 
/*      */   public void autodetectAnnotations(boolean mode)
/*      */   {
/* 1600 */     if (this.annotationConfiguration != null)
/* 1601 */       this.annotationConfiguration.autodetectAnnotations(mode);
/*      */   }
/*      */ 
/*      */   private Object readResolve()
/*      */   {
/* 1619 */     this.jvm = new JVM();
/* 1620 */     return this;
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public static class InitializationException extends XStreamException
/*      */   {
/*      */     public InitializationException(String message, Throwable cause)
/*      */     {
/* 1610 */       super(cause);
/*      */     }
/*      */ 
/*      */     public InitializationException(String message) {
/* 1614 */       super();
/*      */     }
/*      */   }
/*      */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.XStream
 * JD-Core Version:    0.6.0
 */