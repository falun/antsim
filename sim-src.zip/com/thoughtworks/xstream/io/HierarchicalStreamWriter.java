package com.thoughtworks.xstream.io;

public abstract interface HierarchicalStreamWriter
{
  public abstract void startNode(String paramString);

  public abstract void addAttribute(String paramString1, String paramString2);

  public abstract void setValue(String paramString);

  public abstract void endNode();

  public abstract void flush();

  public abstract void close();

  public abstract HierarchicalStreamWriter underlyingWriter();
}

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.HierarchicalStreamWriter
 * JD-Core Version:    0.6.0
 */