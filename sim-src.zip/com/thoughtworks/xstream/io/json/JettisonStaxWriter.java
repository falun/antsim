/*    */ package com.thoughtworks.xstream.io.json;
/*    */ 
/*    */ import com.thoughtworks.xstream.io.xml.QNameMap;
/*    */ import com.thoughtworks.xstream.io.xml.StaxWriter;
/*    */ import com.thoughtworks.xstream.io.xml.XmlFriendlyReplacer;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Map;
/*    */ import javax.xml.namespace.QName;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import javax.xml.stream.XMLStreamWriter;
/*    */ import org.codehaus.jettison.AbstractXMLStreamWriter;
/*    */ import org.codehaus.jettison.mapped.MappedNamespaceConvention;
/*    */ 
/*    */ public class JettisonStaxWriter extends StaxWriter
/*    */ {
/*    */   private final MappedNamespaceConvention convention;
/*    */ 
/*    */   public JettisonStaxWriter(QNameMap qnameMap, XMLStreamWriter out, boolean writeEnclosingDocument, boolean namespaceRepairingMode, XmlFriendlyReplacer replacer, MappedNamespaceConvention convention)
/*    */     throws XMLStreamException
/*    */   {
/* 42 */     super(qnameMap, out, writeEnclosingDocument, namespaceRepairingMode, replacer);
/* 43 */     this.convention = convention;
/*    */   }
/*    */ 
/*    */   public JettisonStaxWriter(QNameMap qnameMap, XMLStreamWriter out, boolean writeEnclosingDocument, boolean namespaceRepairingMode, MappedNamespaceConvention convention)
/*    */     throws XMLStreamException
/*    */   {
/* 50 */     super(qnameMap, out, writeEnclosingDocument, namespaceRepairingMode);
/* 51 */     this.convention = convention;
/*    */   }
/*    */ 
/*    */   public JettisonStaxWriter(QNameMap qnameMap, XMLStreamWriter out, MappedNamespaceConvention convention)
/*    */     throws XMLStreamException
/*    */   {
/* 57 */     super(qnameMap, out);
/* 58 */     this.convention = convention;
/*    */   }
/*    */ 
/*    */   public void startNode(String name, Class clazz) {
/* 62 */     XMLStreamWriter out = getXMLStreamWriter();
/* 63 */     if ((clazz != null) && ((out instanceof AbstractXMLStreamWriter)) && (
/* 64 */       (Collection.class.isAssignableFrom(clazz)) || (Map.class.isAssignableFrom(clazz)) || (clazz.isArray())))
/*    */     {
/* 67 */       QName qname = getQNameMap().getQName(escapeXmlName(name));
/* 68 */       String prefix = qname.getPrefix();
/* 69 */       String uri = qname.getNamespaceURI();
/* 70 */       String key = this.convention.createKey(prefix, uri, qname.getLocalPart());
/* 71 */       if (!((AbstractXMLStreamWriter)out).getSerializedAsArrays().contains(key))
/*    */       {
/* 73 */         ((AbstractXMLStreamWriter)out).seriliazeAsArray(key);
/*    */       }
/*    */     }
/*    */ 
/* 77 */     startNode(name);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.json.JettisonStaxWriter
 * JD-Core Version:    0.6.0
 */