/*    */ package com.thoughtworks.xstream.io.json;
/*    */ 
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamDriver;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*    */ import com.thoughtworks.xstream.io.StreamException;
/*    */ import com.thoughtworks.xstream.io.xml.QNameMap;
/*    */ import com.thoughtworks.xstream.io.xml.StaxReader;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.io.Reader;
/*    */ import java.io.Writer;
/*    */ import java.util.HashMap;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import org.codehaus.jettison.mapped.Configuration;
/*    */ import org.codehaus.jettison.mapped.MappedNamespaceConvention;
/*    */ import org.codehaus.jettison.mapped.MappedXMLInputFactory;
/*    */ import org.codehaus.jettison.mapped.MappedXMLOutputFactory;
/*    */ 
/*    */ public class JettisonMappedXmlDriver
/*    */   implements HierarchicalStreamDriver
/*    */ {
/*    */   private final MappedXMLOutputFactory mof;
/*    */   private final MappedXMLInputFactory mif;
/*    */   private final MappedNamespaceConvention convention;
/*    */ 
/*    */   public JettisonMappedXmlDriver()
/*    */   {
/* 47 */     HashMap nstjsons = new HashMap();
/* 48 */     Configuration config = new Configuration(nstjsons);
/* 49 */     this.mof = new MappedXMLOutputFactory(config);
/* 50 */     this.mif = new MappedXMLInputFactory(config);
/* 51 */     this.convention = new MappedNamespaceConvention(config);
/*    */   }
/*    */ 
/*    */   public HierarchicalStreamReader createReader(Reader reader) {
/*    */     try {
/* 56 */       return new StaxReader(new QNameMap(), this.mif.createXMLStreamReader(reader)); } catch (XMLStreamException e) {
/*    */     }
/* 58 */     throw new StreamException(e);
/*    */   }
/*    */ 
/*    */   public HierarchicalStreamReader createReader(InputStream input)
/*    */   {
/*    */     try {
/* 64 */       return new StaxReader(new QNameMap(), this.mif.createXMLStreamReader(input)); } catch (XMLStreamException e) {
/*    */     }
/* 66 */     throw new StreamException(e);
/*    */   }
/*    */ 
/*    */   public HierarchicalStreamWriter createWriter(Writer writer)
/*    */   {
/*    */     try {
/* 72 */       return new JettisonStaxWriter(new QNameMap(), this.mof.createXMLStreamWriter(writer), this.convention); } catch (XMLStreamException e) {
/*    */     }
/* 74 */     throw new StreamException(e);
/*    */   }
/*    */ 
/*    */   public HierarchicalStreamWriter createWriter(OutputStream output)
/*    */   {
/*    */     try {
/* 80 */       return new JettisonStaxWriter(new QNameMap(), this.mof.createXMLStreamWriter(output), this.convention); } catch (XMLStreamException e) {
/*    */     }
/* 82 */     throw new StreamException(e);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.json.JettisonMappedXmlDriver
 * JD-Core Version:    0.6.0
 */