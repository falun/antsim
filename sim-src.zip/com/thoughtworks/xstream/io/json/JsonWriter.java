/*     */ package com.thoughtworks.xstream.io.json;
/*     */ 
/*     */ import com.thoughtworks.xstream.converters.ConversionException;
/*     */ import com.thoughtworks.xstream.core.util.FastStack;
/*     */ import com.thoughtworks.xstream.core.util.Primitives;
/*     */ import com.thoughtworks.xstream.core.util.QuickWriter;
/*     */ import com.thoughtworks.xstream.io.ExtendedHierarchicalStreamWriter;
/*     */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ public class JsonWriter
/*     */   implements ExtendedHierarchicalStreamWriter
/*     */ {
/*     */   public static final int DROP_ROOT_MODE = 1;
/*     */   public static final int STRICT_MODE = 2;
/*     */   private final QuickWriter writer;
/*  87 */   private final FastStack elementStack = new FastStack(16);
/*     */   private final char[] lineIndenter;
/*     */   private int depth;
/*     */   private boolean readyForNewLine;
/*     */   private boolean tagIsEmpty;
/*     */   private final String newLine;
/*     */   private int mode;
/*     */ 
/*     */   public JsonWriter(Writer writer, char[] lineIndenter, String newLine)
/*     */   {
/*  97 */     this(writer, lineIndenter, newLine, 0);
/*     */   }
/*     */ 
/*     */   public JsonWriter(Writer writer, char[] lineIndenter) {
/* 101 */     this(writer, lineIndenter, "\n");
/*     */   }
/*     */ 
/*     */   public JsonWriter(Writer writer, String lineIndenter, String newLine) {
/* 105 */     this(writer, lineIndenter.toCharArray(), newLine);
/*     */   }
/*     */ 
/*     */   public JsonWriter(Writer writer, String lineIndenter) {
/* 109 */     this(writer, lineIndenter.toCharArray());
/*     */   }
/*     */ 
/*     */   public JsonWriter(Writer writer) {
/* 113 */     this(writer, new char[] { ' ', ' ' });
/*     */   }
/*     */ 
/*     */   public JsonWriter(Writer writer, char[] lineIndenter, String newLine, int mode)
/*     */   {
/* 120 */     this.writer = new QuickWriter(writer);
/* 121 */     this.lineIndenter = lineIndenter;
/* 122 */     this.newLine = newLine;
/* 123 */     this.mode = mode;
/*     */   }
/*     */ 
/*     */   public JsonWriter(Writer writer, int mode)
/*     */   {
/* 142 */     this(writer, new char[] { ' ', ' ' }, "\n", mode);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public void startNode(String name)
/*     */   {
/* 149 */     startNode(name, null);
/*     */   }
/*     */ 
/*     */   public void startNode(String name, Class clazz) {
/* 153 */     Node currNode = (Node)this.elementStack.peek();
/* 154 */     if ((currNode == null) && (((this.mode & 0x1) == 0) || ((this.depth > 0) && (!isCollection(clazz)))))
/*     */     {
/* 156 */       this.writer.write("{");
/*     */     }
/* 158 */     if ((currNode != null) && (currNode.fieldAlready)) {
/* 159 */       this.writer.write(",");
/* 160 */       this.readyForNewLine = true;
/*     */     }
/* 162 */     this.tagIsEmpty = false;
/* 163 */     finishTag();
/* 164 */     if ((currNode == null) || (currNode.clazz == null) || ((currNode.clazz != null) && (!currNode.isCollection)))
/*     */     {
/* 167 */       if ((currNode != null) && (!currNode.fieldAlready)) {
/* 168 */         this.writer.write("{");
/* 169 */         this.readyForNewLine = true;
/* 170 */         finishTag();
/*     */       }
/* 172 */       if (((this.mode & 0x1) == 0) || (this.depth > 0)) {
/* 173 */         this.writer.write("\"");
/* 174 */         this.writer.write(name);
/* 175 */         this.writer.write("\": ");
/*     */       }
/*     */     }
/* 178 */     if (isCollection(clazz)) {
/* 179 */       this.writer.write("[");
/* 180 */       this.readyForNewLine = true;
/*     */     }
/* 182 */     if (currNode != null) {
/* 183 */       currNode.fieldAlready = true;
/*     */     }
/* 185 */     this.elementStack.push(new Node(name, clazz));
/* 186 */     this.depth += 1;
/* 187 */     this.tagIsEmpty = true;
/*     */   }
/*     */ 
/*     */   public void setValue(String text)
/*     */   {
/* 204 */     Node currNode = (Node)this.elementStack.peek();
/* 205 */     if ((currNode != null) && (currNode.fieldAlready)) {
/* 206 */       startNode("$", String.class);
/* 207 */       this.tagIsEmpty = false;
/* 208 */       writeText(text, String.class);
/* 209 */       endNode();
/*     */     } else {
/* 211 */       if (((this.mode & 0x3) == 3) && (this.depth == 1))
/*     */       {
/* 213 */         throw new ConversionException("Single value cannot be JSON root element");
/*     */       }
/* 215 */       this.readyForNewLine = false;
/* 216 */       this.tagIsEmpty = false;
/* 217 */       finishTag();
/* 218 */       writeText(this.writer, text);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addAttribute(String key, String value) {
/* 223 */     Node currNode = (Node)this.elementStack.peek();
/* 224 */     if ((currNode == null) || (!currNode.isCollection)) {
/* 225 */       startNode('@' + key, String.class);
/* 226 */       this.tagIsEmpty = false;
/* 227 */       writeText(value, String.class);
/* 228 */       endNode();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void writeAttributeValue(QuickWriter writer, String text) {
/* 233 */     writeText(text, null);
/*     */   }
/*     */ 
/*     */   protected void writeText(QuickWriter writer, String text) {
/* 237 */     Node foo = (Node)this.elementStack.peek();
/*     */ 
/* 239 */     writeText(text, foo.clazz);
/*     */   }
/*     */ 
/*     */   private void writeText(String text, Class clazz) {
/* 243 */     if (needsQuotes(clazz)) {
/* 244 */       this.writer.write("\"");
/*     */     }
/* 246 */     if (((clazz == Character.class) || (clazz == Character.TYPE)) && ("".equals(text))) {
/* 247 */       text = "";
/*     */     }
/*     */ 
/* 250 */     int length = text.length();
/* 251 */     for (int i = 0; i < length; i++) {
/* 252 */       char c = text.charAt(i);
/* 253 */       switch (c) {
/*     */       case '"':
/* 255 */         this.writer.write("\\\"");
/* 256 */         break;
/*     */       case '\\':
/* 258 */         this.writer.write("\\\\");
/* 259 */         break;
/*     */       default:
/* 261 */         if (c > '\037') {
/* 262 */           this.writer.write(c);
/*     */         } else {
/* 264 */           this.writer.write("\\u");
/* 265 */           String hex = "000" + Integer.toHexString(c);
/* 266 */           this.writer.write(hex.substring(hex.length() - 4));
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 271 */     if (needsQuotes(clazz))
/* 272 */       this.writer.write("\"");
/*     */   }
/*     */ 
/*     */   private boolean isCollection(Class clazz)
/*     */   {
/* 277 */     return (clazz != null) && ((Collection.class.isAssignableFrom(clazz)) || (clazz.isArray()) || (Map.class.isAssignableFrom(clazz)) || (Map.Entry.class.isAssignableFrom(clazz)));
/*     */   }
/*     */ 
/*     */   private boolean needsQuotes(Class clazz)
/*     */   {
/* 284 */     clazz = (clazz != null) && (clazz.isPrimitive()) ? clazz : Primitives.unbox(clazz);
/* 285 */     return (clazz == null) || (clazz == Character.TYPE);
/*     */   }
/*     */ 
/*     */   public void endNode() {
/* 289 */     this.depth -= 1;
/* 290 */     Node node = (Node)this.elementStack.pop();
/* 291 */     if ((node.clazz != null) && (node.isCollection)) {
/* 292 */       if (node.fieldAlready) {
/* 293 */         this.readyForNewLine = true;
/*     */       }
/* 295 */       finishTag();
/* 296 */       this.writer.write("]");
/* 297 */     } else if (this.tagIsEmpty) {
/* 298 */       this.readyForNewLine = false;
/* 299 */       this.writer.write("{}");
/* 300 */       finishTag();
/*     */     } else {
/* 302 */       finishTag();
/* 303 */       if (node.fieldAlready) {
/* 304 */         this.writer.write("}");
/*     */       }
/*     */     }
/* 307 */     this.readyForNewLine = true;
/* 308 */     if ((this.depth == 0) && (((this.mode & 0x1) == 0) || ((this.depth > 0) && (!node.isCollection)))) {
/* 309 */       this.writer.write("}");
/* 310 */       this.writer.flush();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void finishTag() {
/* 315 */     if (this.readyForNewLine) {
/* 316 */       endOfLine();
/*     */     }
/* 318 */     this.readyForNewLine = false;
/* 319 */     this.tagIsEmpty = false;
/*     */   }
/*     */ 
/*     */   protected void endOfLine() {
/* 323 */     this.writer.write(this.newLine);
/* 324 */     for (int i = 0; i < this.depth; i++)
/* 325 */       this.writer.write(this.lineIndenter);
/*     */   }
/*     */ 
/*     */   public void flush()
/*     */   {
/* 330 */     this.writer.flush();
/*     */   }
/*     */ 
/*     */   public void close() {
/* 334 */     this.writer.close();
/*     */   }
/*     */ 
/*     */   public HierarchicalStreamWriter underlyingWriter() {
/* 338 */     return this;
/*     */   }
/*     */ 
/*     */   public class Node
/*     */   {
/*     */     public final String name;
/*     */     public final Class clazz;
/*     */     public boolean fieldAlready;
/*     */     public boolean isCollection;
/*     */ 
/*     */     public Node(String name, Class clazz)
/*     */     {
/* 197 */       this.name = name;
/* 198 */       this.clazz = clazz;
/* 199 */       this.isCollection = JsonWriter.this.isCollection(clazz);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.json.JsonWriter
 * JD-Core Version:    0.6.0
 */