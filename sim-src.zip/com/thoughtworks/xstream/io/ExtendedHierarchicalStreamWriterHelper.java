/*    */ package com.thoughtworks.xstream.io;
/*    */ 
/*    */ public class ExtendedHierarchicalStreamWriterHelper
/*    */ {
/*    */   public static void startNode(HierarchicalStreamWriter writer, String name, Class clazz)
/*    */   {
/* 16 */     if ((writer instanceof ExtendedHierarchicalStreamWriter))
/* 17 */       ((ExtendedHierarchicalStreamWriter)writer).startNode(name, clazz);
/*    */     else
/* 19 */       writer.startNode(name);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.ExtendedHierarchicalStreamWriterHelper
 * JD-Core Version:    0.6.0
 */