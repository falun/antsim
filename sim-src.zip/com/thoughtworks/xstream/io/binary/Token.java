/*     */ package com.thoughtworks.xstream.io.binary;
/*     */ 
/*     */ import com.thoughtworks.xstream.io.StreamException;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ public abstract class Token
/*     */ {
/*     */   private static final byte TYPE_MASK = 7;
/*     */   public static final byte TYPE_VERSION = 1;
/*     */   public static final byte TYPE_MAP_ID_TO_VALUE = 2;
/*     */   public static final byte TYPE_START_NODE = 3;
/*     */   public static final byte TYPE_END_NODE = 4;
/*     */   public static final byte TYPE_ATTRIBUTE = 5;
/*     */   public static final byte TYPE_VALUE = 6;
/*     */   private static final byte ID_MASK = 56;
/*     */   private static final byte ID_ONE_BYTE = 8;
/*     */   private static final byte ID_TWO_BYTES = 16;
/*     */   private static final byte ID_FOUR_BYTES = 24;
/*     */   private static final byte ID_EIGHT_BYTES = 32;
/*     */   private final byte type;
/*  54 */   protected long id = -1L;
/*     */   protected String value;
/*     */ 
/*     */   public Token(byte type)
/*     */   {
/*  58 */     this.type = type;
/*     */   }
/*     */ 
/*     */   public byte getType() {
/*  62 */     return this.type;
/*     */   }
/*     */ 
/*     */   public long getId() {
/*  66 */     return this.id;
/*     */   }
/*     */ 
/*     */   public String getValue() {
/*  70 */     return this.value;
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  74 */     return getClass().getName() + " [id=" + this.id + ", value='" + this.value + "']";
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o) {
/*  78 */     if (this == o) return true;
/*  79 */     if ((o == null) || (getClass() != o.getClass())) return false;
/*     */ 
/*  81 */     Token token = (Token)o;
/*     */ 
/*  83 */     if (this.id != token.id) return false;
/*  84 */     if (this.type != token.type) return false;
/*  85 */     return this.value != null ? this.value.equals(token.value) : token.value == null;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  91 */     int result = this.type;
/*  92 */     result = 29 * result + (int)(this.id ^ this.id >>> 32);
/*  93 */     result = 29 * result + (this.value != null ? this.value.hashCode() : 0);
/*  94 */     return result;
/*     */   }
/*     */   public abstract void writeTo(DataOutput paramDataOutput, byte paramByte) throws IOException;
/*     */ 
/*     */   public abstract void readFrom(DataInput paramDataInput, byte paramByte) throws IOException;
/*     */ 
/* 102 */   protected void writeId(DataOutput out, long id, byte idType) throws IOException { if (id < 0L) {
/* 103 */       throw new IOException("id must not be negative " + id);
/*     */     }
/* 105 */     switch (idType) {
/*     */     case 8:
/* 107 */       out.writeByte((byte)(int)id + -128);
/* 108 */       break;
/*     */     case 16:
/* 110 */       out.writeShort((short)(int)id + -32768);
/* 111 */       break;
/*     */     case 24:
/* 113 */       out.writeInt((int)id + -2147483648);
/* 114 */       break;
/*     */     case 32:
/* 116 */       out.writeLong(id + -9223372036854775808L);
/* 117 */       break;
/*     */     default:
/* 119 */       throw new Error("Unknown idType " + idType);
/*     */     } }
/*     */ 
/*     */   protected void writeString(DataOutput out, String string) throws IOException
/*     */   {
/* 124 */     out.writeUTF(string);
/*     */   }
/*     */ 
/*     */   protected long readId(DataInput in, byte idType) throws IOException {
/* 128 */     switch (idType) {
/*     */     case 8:
/* 130 */       return in.readByte() - -128;
/*     */     case 16:
/* 132 */       return in.readShort() - -32768;
/*     */     case 24:
/* 134 */       return in.readInt() - -2147483648;
/*     */     case 32:
/* 136 */       return in.readLong() - -9223372036854775808L;
/*     */     }
/* 138 */     throw new Error("Unknown idType " + idType);
/*     */   }
/*     */ 
/*     */   protected String readString(DataInput in) throws IOException
/*     */   {
/* 143 */     return in.readUTF();
/*     */   }
/*     */ 
/*     */   public static class Value extends Token
/*     */   {
/*     */     public Value(String value)
/*     */     {
/* 277 */       super();
/* 278 */       this.value = value;
/*     */     }
/*     */ 
/*     */     public Value() {
/* 282 */       super();
/*     */     }
/*     */ 
/*     */     public void writeTo(DataOutput out, byte idType) throws IOException {
/* 286 */       writeString(out, this.value);
/*     */     }
/*     */ 
/*     */     public void readFrom(DataInput in, byte idType) throws IOException {
/* 290 */       this.value = readString(in);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class Attribute extends Token
/*     */   {
/*     */     public Attribute(long id, String value)
/*     */     {
/* 253 */       super();
/* 254 */       this.id = id;
/* 255 */       this.value = value;
/*     */     }
/*     */ 
/*     */     public Attribute() {
/* 259 */       super();
/*     */     }
/*     */ 
/*     */     public void writeTo(DataOutput out, byte idType) throws IOException {
/* 263 */       writeId(out, this.id, idType);
/* 264 */       writeString(out, this.value);
/*     */     }
/*     */ 
/*     */     public void readFrom(DataInput in, byte idType) throws IOException {
/* 268 */       this.id = readId(in, idType);
/* 269 */       this.value = readString(in);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class EndNode extends Token
/*     */   {
/*     */     public EndNode()
/*     */     {
/* 239 */       super();
/*     */     }
/*     */ 
/*     */     public void writeTo(DataOutput out, byte idType)
/*     */     {
/*     */     }
/*     */ 
/*     */     public void readFrom(DataInput in, byte idType)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class StartNode extends Token
/*     */   {
/*     */     public StartNode(long id)
/*     */     {
/* 218 */       super();
/* 219 */       this.id = id;
/*     */     }
/*     */ 
/*     */     public StartNode() {
/* 223 */       super();
/*     */     }
/*     */ 
/*     */     public void writeTo(DataOutput out, byte idType) throws IOException {
/* 227 */       writeId(out, this.id, idType);
/*     */     }
/*     */ 
/*     */     public void readFrom(DataInput in, byte idType) throws IOException {
/* 231 */       this.id = readId(in, idType);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class MapIdToValue extends Token
/*     */   {
/*     */     public MapIdToValue(long id, String value)
/*     */     {
/* 194 */       super();
/* 195 */       this.id = id;
/* 196 */       this.value = value;
/*     */     }
/*     */ 
/*     */     public MapIdToValue() {
/* 200 */       super();
/*     */     }
/*     */ 
/*     */     public void writeTo(DataOutput out, byte idType) throws IOException {
/* 204 */       writeId(out, this.id, idType);
/* 205 */       writeString(out, this.value);
/*     */     }
/*     */ 
/*     */     public void readFrom(DataInput in, byte idType) throws IOException {
/* 209 */       this.id = readId(in, idType);
/* 210 */       this.value = readString(in);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class Formatter
/*     */   {
/*     */     public void write(DataOutput out, Token token)
/*     */       throws IOException
/*     */     {
/* 149 */       long id = token.getId();
/*     */       byte idType;
/*     */       byte idType;
/* 151 */       if (id <= 255L) {
/* 152 */         idType = 8;
/*     */       }
/*     */       else
/*     */       {
/*     */         byte idType;
/* 153 */         if (id <= 65535L) {
/* 154 */           idType = 16;
/*     */         }
/*     */         else
/*     */         {
/*     */           byte idType;
/* 155 */           if (id <= 4294967295L)
/* 156 */             idType = 24;
/*     */           else
/* 158 */             idType = 32; 
/*     */         }
/*     */       }
/* 160 */       out.write(token.getType() + idType);
/* 161 */       token.writeTo(out, idType);
/*     */     }
/*     */ 
/*     */     public Token read(DataInput in) throws IOException {
/* 165 */       byte nextByte = in.readByte();
/* 166 */       byte type = (byte)(nextByte & 0x7);
/* 167 */       byte idType = (byte)(nextByte & 0x38);
/* 168 */       Token token = contructToken(type);
/* 169 */       token.readFrom(in, idType);
/* 170 */       return token;
/*     */     }
/*     */ 
/*     */     private Token contructToken(byte type) {
/* 174 */       switch (type) {
/*     */       case 3:
/* 176 */         return new Token.StartNode();
/*     */       case 2:
/* 178 */         return new Token.MapIdToValue();
/*     */       case 5:
/* 180 */         return new Token.Attribute();
/*     */       case 4:
/* 182 */         return new Token.EndNode();
/*     */       case 6:
/* 184 */         return new Token.Value();
/*     */       }
/* 186 */       throw new StreamException("Unknown token type");
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.binary.Token
 * JD-Core Version:    0.6.0
 */