package com.thoughtworks.xstream.io;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;

public abstract interface HierarchicalStreamDriver
{
  public abstract HierarchicalStreamReader createReader(Reader paramReader);

  public abstract HierarchicalStreamReader createReader(InputStream paramInputStream);

  public abstract HierarchicalStreamWriter createWriter(Writer paramWriter);

  public abstract HierarchicalStreamWriter createWriter(OutputStream paramOutputStream);
}

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.HierarchicalStreamDriver
 * JD-Core Version:    0.6.0
 */