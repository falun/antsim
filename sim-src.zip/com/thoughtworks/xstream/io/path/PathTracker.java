/*     */ package com.thoughtworks.xstream.io.path;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class PathTracker
/*     */ {
/*     */   private int pointer;
/*     */   private int capacity;
/*     */   private String[] pathStack;
/*     */   private Map[] indexMapStack;
/*     */   private Path currentPath;
/*     */ 
/*     */   public PathTracker()
/*     */   {
/*  57 */     this(16);
/*     */   }
/*     */ 
/*     */   public PathTracker(int initialCapacity)
/*     */   {
/*  66 */     this.capacity = Math.max(1, initialCapacity);
/*  67 */     this.pathStack = new String[this.capacity];
/*  68 */     this.indexMapStack = new Map[this.capacity];
/*     */   }
/*     */ 
/*     */   public void pushElement(String name)
/*     */   {
/*  77 */     if (this.pointer + 1 >= this.capacity) {
/*  78 */       resizeStacks(this.capacity * 2);
/*     */     }
/*  80 */     this.pathStack[this.pointer] = name;
/*  81 */     Map indexMap = this.indexMapStack[this.pointer];
/*  82 */     if (indexMap == null) {
/*  83 */       indexMap = new HashMap();
/*  84 */       this.indexMapStack[this.pointer] = indexMap;
/*     */     }
/*  86 */     if (indexMap.containsKey(name))
/*  87 */       indexMap.put(name, new Integer(((Integer)indexMap.get(name)).intValue() + 1));
/*     */     else {
/*  89 */       indexMap.put(name, new Integer(1));
/*     */     }
/*  91 */     this.pointer += 1;
/*  92 */     this.currentPath = null;
/*     */   }
/*     */ 
/*     */   public void popElement()
/*     */   {
/*  99 */     this.indexMapStack[this.pointer] = null;
/* 100 */     this.currentPath = null;
/* 101 */     this.pointer -= 1;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public String getCurrentPath()
/*     */   {
/* 108 */     return getPath().toString();
/*     */   }
/*     */ 
/*     */   private void resizeStacks(int newCapacity) {
/* 112 */     String[] newPathStack = new String[newCapacity];
/* 113 */     Map[] newIndexMapStack = new Map[newCapacity];
/* 114 */     int min = Math.min(this.capacity, newCapacity);
/* 115 */     System.arraycopy(this.pathStack, 0, newPathStack, 0, min);
/* 116 */     System.arraycopy(this.indexMapStack, 0, newIndexMapStack, 0, min);
/* 117 */     this.pathStack = newPathStack;
/* 118 */     this.indexMapStack = newIndexMapStack;
/* 119 */     this.capacity = newCapacity;
/*     */   }
/*     */ 
/*     */   public Path getPath()
/*     */   {
/* 126 */     if (this.currentPath == null) {
/* 127 */       String[] chunks = new String[this.pointer + 1];
/* 128 */       chunks[0] = "";
/* 129 */       for (int i = 0; i < this.pointer; i++) {
/* 130 */         Integer integer = (Integer)this.indexMapStack[i].get(this.pathStack[i]);
/* 131 */         int index = integer.intValue();
/* 132 */         if (index > 1) {
/* 133 */           StringBuffer chunk = new StringBuffer(this.pathStack[i].length() + 6);
/* 134 */           chunk.append(this.pathStack[i]).append('[').append(index).append(']');
/* 135 */           chunks[(i + 1)] = chunk.toString();
/*     */         } else {
/* 137 */           chunks[(i + 1)] = this.pathStack[i];
/*     */         }
/*     */       }
/* 140 */       this.currentPath = new Path(chunks);
/*     */     }
/* 142 */     return this.currentPath;
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.path.PathTracker
 * JD-Core Version:    0.6.0
 */