/*     */ package com.thoughtworks.xstream.io.path;
/*     */ 
/*     */ import com.thoughtworks.xstream.core.util.FastStack;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class Path
/*     */ {
/*     */   private final String[] chunks;
/*     */   private transient String pathAsString;
/*  53 */   private static final Path DOT = new Path(new String[] { "." });
/*     */ 
/*     */   public Path(String pathAsString)
/*     */   {
/*  57 */     List result = new ArrayList();
/*  58 */     int currentIndex = 0;
/*     */     int nextSeperator;
/*  60 */     while ((nextSeperator = pathAsString.indexOf('/', currentIndex)) != -1) {
/*  61 */       result.add(pathAsString.substring(currentIndex, nextSeperator));
/*  62 */       currentIndex = nextSeperator + 1;
/*     */     }
/*  64 */     result.add(pathAsString.substring(currentIndex));
/*  65 */     String[] arr = new String[result.size()];
/*  66 */     result.toArray(arr);
/*  67 */     this.chunks = arr;
/*  68 */     this.pathAsString = pathAsString;
/*     */   }
/*     */ 
/*     */   public Path(String[] chunks) {
/*  72 */     this.chunks = chunks;
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  76 */     if (this.pathAsString == null) {
/*  77 */       StringBuffer buffer = new StringBuffer();
/*  78 */       for (int i = 0; i < this.chunks.length; i++) {
/*  79 */         if (i > 0) buffer.append('/');
/*  80 */         buffer.append(this.chunks[i]);
/*     */       }
/*  82 */       this.pathAsString = buffer.toString();
/*     */     }
/*  84 */     return this.pathAsString;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o) {
/*  88 */     if (this == o) return true;
/*  89 */     if (!(o instanceof Path)) return false;
/*     */ 
/*  91 */     Path other = (Path)o;
/*  92 */     if (this.chunks.length != other.chunks.length) return false;
/*  93 */     for (int i = 0; i < this.chunks.length; i++) {
/*  94 */       if (!this.chunks[i].equals(other.chunks[i])) return false;
/*     */     }
/*     */ 
/*  97 */     return true;
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 101 */     int result = 543645643;
/* 102 */     for (int i = 0; i < this.chunks.length; i++) {
/* 103 */       result = 29 * result + this.chunks[i].hashCode();
/*     */     }
/* 105 */     return result;
/*     */   }
/*     */ 
/*     */   public Path relativeTo(Path that) {
/* 109 */     int depthOfPathDivergence = depthOfPathDivergence(this.chunks, that.chunks);
/* 110 */     String[] result = new String[this.chunks.length + that.chunks.length - 2 * depthOfPathDivergence];
/* 111 */     int count = 0;
/*     */ 
/* 113 */     for (int i = depthOfPathDivergence; i < this.chunks.length; i++) {
/* 114 */       result[(count++)] = "..";
/*     */     }
/* 116 */     for (int j = depthOfPathDivergence; j < that.chunks.length; j++) {
/* 117 */       result[(count++)] = that.chunks[j];
/*     */     }
/*     */ 
/* 120 */     if (count == 0) {
/* 121 */       return DOT;
/*     */     }
/* 123 */     return new Path(result);
/*     */   }
/*     */ 
/*     */   private int depthOfPathDivergence(String[] path1, String[] path2)
/*     */   {
/* 128 */     int minLength = Math.min(path1.length, path2.length);
/* 129 */     for (int i = 0; i < minLength; i++) {
/* 130 */       if (!path1[i].equals(path2[i])) {
/* 131 */         return i;
/*     */       }
/*     */     }
/* 134 */     return minLength;
/*     */   }
/*     */ 
/*     */   public Path apply(Path relativePath) {
/* 138 */     FastStack absoluteStack = new FastStack(16);
/*     */ 
/* 140 */     for (int i = 0; i < this.chunks.length; i++) {
/* 141 */       absoluteStack.push(this.chunks[i]);
/*     */     }
/*     */ 
/* 144 */     for (int i = 0; i < relativePath.chunks.length; i++) {
/* 145 */       String relativeChunk = relativePath.chunks[i];
/* 146 */       if (relativeChunk.equals(".."))
/* 147 */         absoluteStack.pop();
/* 148 */       else if (!relativeChunk.equals(".")) {
/* 149 */         absoluteStack.push(relativeChunk);
/*     */       }
/*     */     }
/*     */ 
/* 153 */     String[] result = new String[absoluteStack.size()];
/* 154 */     for (int i = 0; i < result.length; i++) {
/* 155 */       result[i] = ((String)absoluteStack.get(i));
/*     */     }
/*     */ 
/* 158 */     return new Path(result);
/*     */   }
/*     */ 
/*     */   public boolean isAncestor(Path child) {
/* 162 */     if ((child == null) || (child.chunks.length < this.chunks.length)) {
/* 163 */       return false;
/*     */     }
/* 165 */     for (int i = 0; i < this.chunks.length; i++) {
/* 166 */       if (!this.chunks[i].equals(child.chunks[i])) {
/* 167 */         return false;
/*     */       }
/*     */     }
/* 170 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.path.Path
 * JD-Core Version:    0.6.0
 */