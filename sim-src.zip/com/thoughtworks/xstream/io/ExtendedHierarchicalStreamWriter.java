package com.thoughtworks.xstream.io;

public abstract interface ExtendedHierarchicalStreamWriter extends HierarchicalStreamWriter
{
  public abstract void startNode(String paramString, Class paramClass);
}

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.ExtendedHierarchicalStreamWriter
 * JD-Core Version:    0.6.0
 */