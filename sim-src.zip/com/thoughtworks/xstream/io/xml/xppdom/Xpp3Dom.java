/*     */ package com.thoughtworks.xstream.io.xml.xppdom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class Xpp3Dom
/*     */ {
/*     */   protected String name;
/*     */   protected String value;
/*     */   protected Map attributes;
/*     */   protected List childList;
/*     */   protected Map childMap;
/*     */   protected Xpp3Dom parent;
/*     */ 
/*     */   public Xpp3Dom(String name)
/*     */   {
/*  33 */     this.name = name;
/*  34 */     this.childList = new ArrayList();
/*  35 */     this.childMap = new HashMap();
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  43 */     return this.name;
/*     */   }
/*     */ 
/*     */   public String getValue()
/*     */   {
/*  51 */     return this.value;
/*     */   }
/*     */ 
/*     */   public void setValue(String value) {
/*  55 */     this.value = value;
/*     */   }
/*     */ 
/*     */   public String[] getAttributeNames()
/*     */   {
/*  63 */     if (null == this.attributes) {
/*  64 */       return new String[0];
/*     */     }
/*     */ 
/*  67 */     return (String[])(String[])this.attributes.keySet().toArray(new String[0]);
/*     */   }
/*     */ 
/*     */   public String getAttribute(String name)
/*     */   {
/*  72 */     return null != this.attributes ? (String)this.attributes.get(name) : null;
/*     */   }
/*     */ 
/*     */   public void setAttribute(String name, String value) {
/*  76 */     if (null == this.attributes) {
/*  77 */       this.attributes = new HashMap();
/*     */     }
/*     */ 
/*  80 */     this.attributes.put(name, value);
/*     */   }
/*     */ 
/*     */   public Xpp3Dom getChild(int i)
/*     */   {
/*  88 */     return (Xpp3Dom)this.childList.get(i);
/*     */   }
/*     */ 
/*     */   public Xpp3Dom getChild(String name) {
/*  92 */     return (Xpp3Dom)this.childMap.get(name);
/*     */   }
/*     */ 
/*     */   public void addChild(Xpp3Dom xpp3Dom) {
/*  96 */     xpp3Dom.setParent(this);
/*  97 */     this.childList.add(xpp3Dom);
/*  98 */     this.childMap.put(xpp3Dom.getName(), xpp3Dom);
/*     */   }
/*     */ 
/*     */   public Xpp3Dom[] getChildren() {
/* 102 */     if (null == this.childList) {
/* 103 */       return new Xpp3Dom[0];
/*     */     }
/*     */ 
/* 106 */     return (Xpp3Dom[])(Xpp3Dom[])this.childList.toArray(new Xpp3Dom[0]);
/*     */   }
/*     */ 
/*     */   public Xpp3Dom[] getChildren(String name)
/*     */   {
/* 111 */     if (null == this.childList) {
/* 112 */       return new Xpp3Dom[0];
/*     */     }
/*     */ 
/* 115 */     ArrayList children = new ArrayList();
/* 116 */     int size = this.childList.size();
/*     */ 
/* 118 */     for (int i = 0; i < size; i++) {
/* 119 */       Xpp3Dom configuration = (Xpp3Dom)this.childList.get(i);
/* 120 */       if (name.equals(configuration.getName())) {
/* 121 */         children.add(configuration);
/*     */       }
/*     */     }
/*     */ 
/* 125 */     return (Xpp3Dom[])(Xpp3Dom[])children.toArray(new Xpp3Dom[0]);
/*     */   }
/*     */ 
/*     */   public int getChildCount()
/*     */   {
/* 130 */     if (null == this.childList) {
/* 131 */       return 0;
/*     */     }
/*     */ 
/* 134 */     return this.childList.size();
/*     */   }
/*     */ 
/*     */   public Xpp3Dom getParent()
/*     */   {
/* 142 */     return this.parent;
/*     */   }
/*     */ 
/*     */   public void setParent(Xpp3Dom parent) {
/* 146 */     this.parent = parent;
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.xppdom.Xpp3Dom
 * JD-Core Version:    0.6.0
 */