/*    */ package com.thoughtworks.xstream.io.xml.xppdom;
/*    */ 
/*    */ import java.io.Reader;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.xmlpull.mxp1.MXParser;
/*    */ import org.xmlpull.v1.XmlPullParser;
/*    */ 
/*    */ public class Xpp3DomBuilder
/*    */ {
/*    */   public static Xpp3Dom build(Reader reader)
/*    */     throws Exception
/*    */   {
/* 24 */     List elements = new ArrayList();
/*    */ 
/* 26 */     List values = new ArrayList();
/*    */ 
/* 28 */     Xpp3Dom node = null;
/*    */ 
/* 30 */     XmlPullParser parser = new MXParser();
/*    */ 
/* 32 */     parser.setInput(reader);
/*    */ 
/* 34 */     int eventType = parser.getEventType();
/*    */ 
/* 36 */     while (eventType != 1) {
/* 37 */       if (eventType == 2) {
/* 38 */         String rawName = parser.getName();
/*    */ 
/* 40 */         Xpp3Dom child = new Xpp3Dom(rawName);
/*    */ 
/* 42 */         int depth = elements.size();
/*    */ 
/* 44 */         if (depth > 0) {
/* 45 */           Xpp3Dom parent = (Xpp3Dom)elements.get(depth - 1);
/*    */ 
/* 47 */           parent.addChild(child);
/*    */         }
/*    */ 
/* 50 */         elements.add(child);
/*    */ 
/* 52 */         values.add(new StringBuffer());
/*    */ 
/* 54 */         int attributesSize = parser.getAttributeCount();
/*    */ 
/* 56 */         for (int i = 0; i < attributesSize; i++) {
/* 57 */           String name = parser.getAttributeName(i);
/*    */ 
/* 59 */           String value = parser.getAttributeValue(i);
/*    */ 
/* 61 */           child.setAttribute(name, value);
/*    */         }
/* 63 */       } else if (eventType == 4) {
/* 64 */         int depth = values.size() - 1;
/*    */ 
/* 66 */         StringBuffer valueBuffer = (StringBuffer)values.get(depth);
/*    */ 
/* 68 */         valueBuffer.append(parser.getText());
/* 69 */       } else if (eventType == 3) {
/* 70 */         int depth = elements.size() - 1;
/*    */ 
/* 72 */         Xpp3Dom finalNode = (Xpp3Dom)elements.remove(depth);
/*    */ 
/* 74 */         String accumulatedValue = values.remove(depth).toString();
/*    */         String finishedValue;
/*    */         String finishedValue;
/* 78 */         if (0 == accumulatedValue.length())
/* 79 */           finishedValue = null;
/*    */         else {
/* 81 */           finishedValue = accumulatedValue;
/*    */         }
/*    */ 
/* 84 */         finalNode.setValue(finishedValue);
/*    */ 
/* 86 */         if (0 == depth) {
/* 87 */           node = finalNode;
/*    */         }
/*    */       }
/*    */ 
/* 91 */       eventType = parser.next();
/*    */     }
/*    */ 
/* 94 */     reader.close();
/*    */ 
/* 96 */     return node;
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.xppdom.Xpp3DomBuilder
 * JD-Core Version:    0.6.0
 */