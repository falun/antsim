/*    */ package com.thoughtworks.xstream.io.xml;
/*    */ 
/*    */ import com.thoughtworks.xstream.io.xml.xppdom.Xpp3Dom;
/*    */ 
/*    */ public class XppDomReader extends AbstractDocumentReader
/*    */ {
/*    */   private Xpp3Dom currentElement;
/*    */ 
/*    */   public XppDomReader(Xpp3Dom xpp3Dom)
/*    */   {
/* 25 */     super(xpp3Dom);
/*    */   }
/*    */ 
/*    */   public XppDomReader(Xpp3Dom xpp3Dom, XmlFriendlyReplacer replacer)
/*    */   {
/* 32 */     super(xpp3Dom, replacer);
/*    */   }
/*    */ 
/*    */   public String getNodeName() {
/* 36 */     return unescapeXmlName(this.currentElement.getName());
/*    */   }
/*    */ 
/*    */   public String getValue() {
/* 40 */     String text = null;
/*    */     try
/*    */     {
/* 43 */       text = this.currentElement.getValue();
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/*    */     }
/* 48 */     return text == null ? "" : text;
/*    */   }
/*    */ 
/*    */   public String getAttribute(String attributeName) {
/* 52 */     return this.currentElement.getAttribute(attributeName);
/*    */   }
/*    */ 
/*    */   public String getAttribute(int index) {
/* 56 */     return this.currentElement.getAttribute(this.currentElement.getAttributeNames()[index]);
/*    */   }
/*    */ 
/*    */   public int getAttributeCount() {
/* 60 */     return this.currentElement.getAttributeNames().length;
/*    */   }
/*    */ 
/*    */   public String getAttributeName(int index) {
/* 64 */     return unescapeXmlName(this.currentElement.getAttributeNames()[index]);
/*    */   }
/*    */ 
/*    */   protected Object getParent() {
/* 68 */     return this.currentElement.getParent();
/*    */   }
/*    */ 
/*    */   protected Object getChild(int index) {
/* 72 */     return this.currentElement.getChild(index);
/*    */   }
/*    */ 
/*    */   protected int getChildCount() {
/* 76 */     return this.currentElement.getChildCount();
/*    */   }
/*    */ 
/*    */   protected void reassignCurrentElement(Object current) {
/* 80 */     this.currentElement = ((Xpp3Dom)current);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.XppDomReader
 * JD-Core Version:    0.6.0
 */