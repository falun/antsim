/*     */ package com.thoughtworks.xstream.io.xml;
/*     */ 
/*     */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*     */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*     */ import com.thoughtworks.xstream.io.StreamException;
/*     */ import java.io.FilterWriter;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import org.dom4j.Document;
/*     */ import org.dom4j.DocumentException;
/*     */ import org.dom4j.DocumentFactory;
/*     */ import org.dom4j.io.OutputFormat;
/*     */ import org.dom4j.io.SAXReader;
/*     */ import org.dom4j.io.XMLWriter;
/*     */ 
/*     */ public class Dom4JDriver extends AbstractXmlDriver
/*     */ {
/*     */   private DocumentFactory documentFactory;
/*     */   private OutputFormat outputFormat;
/*     */ 
/*     */   public Dom4JDriver()
/*     */   {
/*  38 */     this(new DocumentFactory(), OutputFormat.createPrettyPrint());
/*  39 */     this.outputFormat.setTrimText(false);
/*     */   }
/*     */ 
/*     */   public Dom4JDriver(DocumentFactory documentFactory, OutputFormat outputFormat) {
/*  43 */     this(documentFactory, outputFormat, new XmlFriendlyReplacer());
/*     */   }
/*     */ 
/*     */   public Dom4JDriver(DocumentFactory documentFactory, OutputFormat outputFormat, XmlFriendlyReplacer replacer)
/*     */   {
/*  50 */     super(replacer);
/*  51 */     this.documentFactory = documentFactory;
/*  52 */     this.outputFormat = outputFormat;
/*     */   }
/*     */ 
/*     */   public DocumentFactory getDocumentFactory()
/*     */   {
/*  57 */     return this.documentFactory;
/*     */   }
/*     */ 
/*     */   public void setDocumentFactory(DocumentFactory documentFactory) {
/*  61 */     this.documentFactory = documentFactory;
/*     */   }
/*     */ 
/*     */   public OutputFormat getOutputFormat() {
/*  65 */     return this.outputFormat;
/*     */   }
/*     */ 
/*     */   public void setOutputFormat(OutputFormat outputFormat) {
/*  69 */     this.outputFormat = outputFormat;
/*     */   }
/*     */ 
/*     */   public HierarchicalStreamReader createReader(Reader text) {
/*     */     try {
/*  74 */       SAXReader reader = new SAXReader();
/*  75 */       Document document = reader.read(text);
/*  76 */       return new Dom4JReader(document, xmlFriendlyReplacer()); } catch (DocumentException e) {
/*     */     }
/*  78 */     throw new StreamException(e);
/*     */   }
/*     */ 
/*     */   public HierarchicalStreamReader createReader(InputStream in)
/*     */   {
/*     */     try {
/*  84 */       SAXReader reader = new SAXReader();
/*  85 */       Document document = reader.read(in);
/*  86 */       return new Dom4JReader(document, xmlFriendlyReplacer()); } catch (DocumentException e) {
/*     */     }
/*  88 */     throw new StreamException(e);
/*     */   }
/*     */ 
/*     */   public HierarchicalStreamWriter createWriter(Writer out)
/*     */   {
/*  93 */     HierarchicalStreamWriter[] writer = new HierarchicalStreamWriter[1];
/*  94 */     FilterWriter filter = new FilterWriter(out, writer) { private final HierarchicalStreamWriter[] val$writer;
/*     */ 
/*  96 */       public void close() { this.val$writer[0].close();
/*     */       }
/*     */     };
/*  99 */     writer[0] = new Dom4JXmlWriter(new XMLWriter(filter, this.outputFormat), xmlFriendlyReplacer());
/* 100 */     return writer[0];
/*     */   }
/*     */ 
/*     */   public HierarchicalStreamWriter createWriter(OutputStream out) {
/* 104 */     Writer writer = new OutputStreamWriter(out);
/* 105 */     return createWriter(writer);
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.Dom4JDriver
 * JD-Core Version:    0.6.0
 */