/*     */ package com.thoughtworks.xstream.io.xml;
/*     */ 
/*     */ import com.thoughtworks.xstream.core.util.FastStack;
/*     */ import com.thoughtworks.xstream.core.util.QuickWriter;
/*     */ import com.thoughtworks.xstream.io.StreamException;
/*     */ import java.io.Writer;
/*     */ 
/*     */ public class PrettyPrintWriter extends AbstractXmlWriter
/*     */ {
/*  48 */   public static int XML_QUIRKS = -1;
/*  49 */   public static int XML_1_0 = 0;
/*  50 */   public static int XML_1_1 = 1;
/*     */   private final QuickWriter writer;
/*  53 */   private final FastStack elementStack = new FastStack(16);
/*     */   private final char[] lineIndenter;
/*     */   private final int mode;
/*     */   private boolean tagInProgress;
/*     */   protected int depth;
/*     */   private boolean readyForNewLine;
/*     */   private boolean tagIsEmpty;
/*     */   private String newLine;
/*  63 */   private static final char[] NULL = "&#x0;".toCharArray();
/*  64 */   private static final char[] AMP = "&amp;".toCharArray();
/*  65 */   private static final char[] LT = "&lt;".toCharArray();
/*  66 */   private static final char[] GT = "&gt;".toCharArray();
/*  67 */   private static final char[] CR = "&#xd;".toCharArray();
/*  68 */   private static final char[] QUOT = "&quot;".toCharArray();
/*  69 */   private static final char[] APOS = "&apos;".toCharArray();
/*  70 */   private static final char[] CLOSE = "</".toCharArray();
/*     */ 
/*     */   private PrettyPrintWriter(Writer writer, int mode, char[] lineIndenter, XmlFriendlyReplacer replacer, String newLine)
/*     */   {
/*  75 */     super(replacer);
/*  76 */     this.writer = new QuickWriter(writer);
/*  77 */     this.lineIndenter = lineIndenter;
/*  78 */     this.newLine = newLine;
/*  79 */     this.mode = mode;
/*  80 */     if ((mode < XML_QUIRKS) || (mode > XML_1_1))
/*  81 */       throw new IllegalArgumentException("Not a valid XML mode");
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public PrettyPrintWriter(Writer writer, char[] lineIndenter, String newLine, XmlFriendlyReplacer replacer)
/*     */   {
/*  91 */     this(writer, XML_QUIRKS, lineIndenter, replacer, newLine);
/*     */   }
/*     */ 
/*     */   public PrettyPrintWriter(Writer writer, int mode, char[] lineIndenter, XmlFriendlyReplacer replacer)
/*     */   {
/*  99 */     this(writer, mode, lineIndenter, replacer, "\n");
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public PrettyPrintWriter(Writer writer, char[] lineIndenter, String newLine)
/*     */   {
/* 106 */     this(writer, lineIndenter, newLine, new XmlFriendlyReplacer());
/*     */   }
/*     */ 
/*     */   public PrettyPrintWriter(Writer writer, int mode, char[] lineIndenter)
/*     */   {
/* 113 */     this(writer, mode, lineIndenter, new XmlFriendlyReplacer());
/*     */   }
/*     */ 
/*     */   public PrettyPrintWriter(Writer writer, char[] lineIndenter) {
/* 117 */     this(writer, lineIndenter, "\n");
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public PrettyPrintWriter(Writer writer, String lineIndenter, String newLine)
/*     */   {
/* 124 */     this(writer, lineIndenter.toCharArray(), newLine);
/*     */   }
/*     */ 
/*     */   public PrettyPrintWriter(Writer writer, int mode, String lineIndenter)
/*     */   {
/* 131 */     this(writer, mode, lineIndenter.toCharArray());
/*     */   }
/*     */ 
/*     */   public PrettyPrintWriter(Writer writer, String lineIndenter) {
/* 135 */     this(writer, lineIndenter.toCharArray());
/*     */   }
/*     */ 
/*     */   public PrettyPrintWriter(Writer writer, int mode, XmlFriendlyReplacer replacer)
/*     */   {
/* 142 */     this(writer, mode, new char[] { ' ', ' ' }, replacer);
/*     */   }
/*     */ 
/*     */   public PrettyPrintWriter(Writer writer, XmlFriendlyReplacer replacer) {
/* 146 */     this(writer, new char[] { ' ', ' ' }, "\n", replacer);
/*     */   }
/*     */ 
/*     */   public PrettyPrintWriter(Writer writer, int mode)
/*     */   {
/* 153 */     this(writer, mode, new char[] { ' ', ' ' });
/*     */   }
/*     */ 
/*     */   public PrettyPrintWriter(Writer writer) {
/* 157 */     this(writer, new char[] { ' ', ' ' });
/*     */   }
/*     */ 
/*     */   public void startNode(String name) {
/* 161 */     String escapedName = escapeXmlName(name);
/* 162 */     this.tagIsEmpty = false;
/* 163 */     finishTag();
/* 164 */     this.writer.write('<');
/* 165 */     this.writer.write(escapedName);
/* 166 */     this.elementStack.push(escapedName);
/* 167 */     this.tagInProgress = true;
/* 168 */     this.depth += 1;
/* 169 */     this.readyForNewLine = true;
/* 170 */     this.tagIsEmpty = true;
/*     */   }
/*     */ 
/*     */   public void startNode(String name, Class clazz) {
/* 174 */     startNode(name);
/*     */   }
/*     */ 
/*     */   public void setValue(String text) {
/* 178 */     this.readyForNewLine = false;
/* 179 */     this.tagIsEmpty = false;
/* 180 */     finishTag();
/*     */ 
/* 182 */     writeText(this.writer, text);
/*     */   }
/*     */ 
/*     */   public void addAttribute(String key, String value) {
/* 186 */     this.writer.write(' ');
/* 187 */     this.writer.write(escapeXmlName(key));
/* 188 */     this.writer.write('=');
/* 189 */     this.writer.write('"');
/* 190 */     writeAttributeValue(this.writer, value);
/* 191 */     this.writer.write('"');
/*     */   }
/*     */ 
/*     */   protected void writeAttributeValue(QuickWriter writer, String text) {
/* 195 */     writeText(text);
/*     */   }
/*     */ 
/*     */   protected void writeText(QuickWriter writer, String text) {
/* 199 */     writeText(text);
/*     */   }
/*     */ 
/*     */   private void writeText(String text) {
/* 203 */     int length = text.length();
/* 204 */     for (int i = 0; i < length; i++) {
/* 205 */       char c = text.charAt(i);
/* 206 */       switch (c) {
/*     */       case '\000':
/* 208 */         if (this.mode == XML_QUIRKS)
/* 209 */           this.writer.write(NULL);
/*     */         else {
/* 211 */           throw new StreamException("Invalid character 0x0 in XML stream");
/*     */         }
/*     */ 
/*     */       case '&':
/* 215 */         this.writer.write(AMP);
/* 216 */         break;
/*     */       case '<':
/* 218 */         this.writer.write(LT);
/* 219 */         break;
/*     */       case '>':
/* 221 */         this.writer.write(GT);
/* 222 */         break;
/*     */       case '"':
/* 224 */         this.writer.write(QUOT);
/* 225 */         break;
/*     */       case '\'':
/* 227 */         this.writer.write(APOS);
/* 228 */         break;
/*     */       case '\r':
/* 230 */         this.writer.write(CR);
/* 231 */         break;
/*     */       case '\t':
/*     */       case '\n':
/* 234 */         this.writer.write(c);
/* 235 */         break;
/*     */       default:
/* 237 */         if ((Character.isDefined(c)) && (!Character.isISOControl(c))) {
/* 238 */           if ((this.mode != XML_QUIRKS) && 
/* 239 */             (c > 55295) && (c < 57344)) {
/* 240 */             throw new StreamException("Invalid character 0x" + Integer.toHexString(c) + " in XML stream");
/*     */           }
/*     */ 
/* 245 */           this.writer.write(c);
/*     */         } else {
/* 247 */           if ((this.mode == XML_1_0) && (
/* 248 */             (c < '\t') || (c == '\013') || (c == '\f') || (c == '\016') || (c == '\017')))
/*     */           {
/* 253 */             throw new StreamException("Invalid character 0x" + Integer.toHexString(c) + " in XML 1.0 stream");
/*     */           }
/*     */ 
/* 258 */           if ((this.mode != XML_QUIRKS) && (
/* 259 */             (c == 65534) || (c == 65535))) {
/* 260 */             throw new StreamException("Invalid character 0x" + Integer.toHexString(c) + " in XML stream");
/*     */           }
/*     */ 
/* 265 */           this.writer.write("&#x");
/* 266 */           this.writer.write(Integer.toHexString(c));
/* 267 */           this.writer.write(';');
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void endNode() {
/* 274 */     this.depth -= 1;
/* 275 */     if (this.tagIsEmpty) {
/* 276 */       this.writer.write('/');
/* 277 */       this.readyForNewLine = false;
/* 278 */       finishTag();
/* 279 */       this.elementStack.popSilently();
/*     */     } else {
/* 281 */       finishTag();
/* 282 */       this.writer.write(CLOSE);
/* 283 */       this.writer.write((String)this.elementStack.pop());
/* 284 */       this.writer.write('>');
/*     */     }
/* 286 */     this.readyForNewLine = true;
/* 287 */     if (this.depth == 0)
/* 288 */       this.writer.flush();
/*     */   }
/*     */ 
/*     */   private void finishTag()
/*     */   {
/* 293 */     if (this.tagInProgress) {
/* 294 */       this.writer.write('>');
/*     */     }
/* 296 */     this.tagInProgress = false;
/* 297 */     if (this.readyForNewLine) {
/* 298 */       endOfLine();
/*     */     }
/* 300 */     this.readyForNewLine = false;
/* 301 */     this.tagIsEmpty = false;
/*     */   }
/*     */ 
/*     */   protected void endOfLine() {
/* 305 */     this.writer.write(getNewLine());
/* 306 */     for (int i = 0; i < this.depth; i++)
/* 307 */       this.writer.write(this.lineIndenter);
/*     */   }
/*     */ 
/*     */   public void flush()
/*     */   {
/* 312 */     this.writer.flush();
/*     */   }
/*     */ 
/*     */   public void close() {
/* 316 */     this.writer.close();
/*     */   }
/*     */ 
/*     */   protected String getNewLine() {
/* 320 */     return this.newLine;
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.PrettyPrintWriter
 * JD-Core Version:    0.6.0
 */