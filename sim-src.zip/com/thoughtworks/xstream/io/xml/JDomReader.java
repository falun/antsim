/*    */ package com.thoughtworks.xstream.io.xml;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.jdom.Attribute;
/*    */ import org.jdom.Document;
/*    */ import org.jdom.Element;
/*    */ 
/*    */ public class JDomReader extends AbstractDocumentReader
/*    */ {
/*    */   private Element currentElement;
/*    */ 
/*    */   public JDomReader(Element root)
/*    */   {
/* 26 */     super(root);
/*    */   }
/*    */ 
/*    */   public JDomReader(Document document) {
/* 30 */     super(document.getRootElement());
/*    */   }
/*    */ 
/*    */   public JDomReader(Element root, XmlFriendlyReplacer replacer)
/*    */   {
/* 37 */     super(root, replacer);
/*    */   }
/*    */ 
/*    */   public JDomReader(Document document, XmlFriendlyReplacer replacer)
/*    */   {
/* 44 */     super(document.getRootElement(), replacer);
/*    */   }
/*    */ 
/*    */   protected void reassignCurrentElement(Object current) {
/* 48 */     this.currentElement = ((Element)current);
/*    */   }
/*    */ 
/*    */   protected Object getParent()
/*    */   {
/* 53 */     return this.currentElement.getParentElement();
/*    */   }
/*    */ 
/*    */   protected Object getChild(int index)
/*    */   {
/* 64 */     return this.currentElement.getChildren().get(index);
/*    */   }
/*    */ 
/*    */   protected int getChildCount() {
/* 68 */     return this.currentElement.getChildren().size();
/*    */   }
/*    */ 
/*    */   public String getNodeName() {
/* 72 */     return unescapeXmlName(this.currentElement.getName());
/*    */   }
/*    */ 
/*    */   public String getValue() {
/* 76 */     return this.currentElement.getText();
/*    */   }
/*    */ 
/*    */   public String getAttribute(String name) {
/* 80 */     return this.currentElement.getAttributeValue(name);
/*    */   }
/*    */ 
/*    */   public String getAttribute(int index) {
/* 84 */     return ((Attribute)this.currentElement.getAttributes().get(index)).getValue();
/*    */   }
/*    */ 
/*    */   public int getAttributeCount() {
/* 88 */     return this.currentElement.getAttributes().size();
/*    */   }
/*    */ 
/*    */   public String getAttributeName(int index) {
/* 92 */     return unescapeXmlName(((Attribute)this.currentElement.getAttributes().get(index)).getQualifiedName());
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.JDomReader
 * JD-Core Version:    0.6.0
 */