package com.thoughtworks.xstream.io.xml;

public abstract interface XmlFriendlyWriter
{
  public abstract String escapeXmlName(String paramString);
}

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.XmlFriendlyWriter
 * JD-Core Version:    0.6.0
 */