/*     */ package com.thoughtworks.xstream.io.xml;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.Text;
/*     */ 
/*     */ public class DomReader extends AbstractDocumentReader
/*     */ {
/*     */   private Element currentElement;
/*     */   private StringBuffer textBuffer;
/*     */   private List childElements;
/*     */ 
/*     */   public DomReader(Element rootElement)
/*     */   {
/*  31 */     this(rootElement, new XmlFriendlyReplacer());
/*     */   }
/*     */ 
/*     */   public DomReader(Document document) {
/*  35 */     this(document.getDocumentElement());
/*     */   }
/*     */ 
/*     */   public DomReader(Element rootElement, XmlFriendlyReplacer replacer)
/*     */   {
/*  42 */     super(rootElement, replacer);
/*  43 */     this.textBuffer = new StringBuffer();
/*     */   }
/*     */ 
/*     */   public DomReader(Document document, XmlFriendlyReplacer replacer)
/*     */   {
/*  50 */     this(document.getDocumentElement(), replacer);
/*     */   }
/*     */ 
/*     */   public String getNodeName() {
/*  54 */     return unescapeXmlName(this.currentElement.getTagName());
/*     */   }
/*     */ 
/*     */   public String getValue() {
/*  58 */     NodeList childNodes = this.currentElement.getChildNodes();
/*  59 */     this.textBuffer.setLength(0);
/*  60 */     int length = childNodes.getLength();
/*  61 */     for (int i = 0; i < length; i++) {
/*  62 */       Node childNode = childNodes.item(i);
/*  63 */       if ((childNode instanceof Text)) {
/*  64 */         Text text = (Text)childNode;
/*  65 */         this.textBuffer.append(text.getData());
/*     */       }
/*     */     }
/*  68 */     return this.textBuffer.toString();
/*     */   }
/*     */ 
/*     */   public String getAttribute(String name) {
/*  72 */     Attr attribute = this.currentElement.getAttributeNode(name);
/*  73 */     return attribute == null ? null : attribute.getValue();
/*     */   }
/*     */ 
/*     */   public String getAttribute(int index) {
/*  77 */     return ((Attr)this.currentElement.getAttributes().item(index)).getValue();
/*     */   }
/*     */ 
/*     */   public int getAttributeCount() {
/*  81 */     return this.currentElement.getAttributes().getLength();
/*     */   }
/*     */ 
/*     */   public String getAttributeName(int index) {
/*  85 */     return unescapeXmlName(((Attr)this.currentElement.getAttributes().item(index)).getName());
/*     */   }
/*     */ 
/*     */   protected Object getParent() {
/*  89 */     return this.currentElement.getParentNode();
/*     */   }
/*     */ 
/*     */   protected Object getChild(int index) {
/*  93 */     return this.childElements.get(index);
/*     */   }
/*     */ 
/*     */   protected int getChildCount() {
/*  97 */     return this.childElements.size();
/*     */   }
/*     */ 
/*     */   protected void reassignCurrentElement(Object current) {
/* 101 */     this.currentElement = ((Element)current);
/* 102 */     NodeList childNodes = this.currentElement.getChildNodes();
/* 103 */     this.childElements = new ArrayList();
/* 104 */     for (int i = 0; i < childNodes.getLength(); i++) {
/* 105 */       Node node = childNodes.item(i);
/* 106 */       if ((node instanceof Element))
/* 107 */         this.childElements.add(node);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.DomReader
 * JD-Core Version:    0.6.0
 */