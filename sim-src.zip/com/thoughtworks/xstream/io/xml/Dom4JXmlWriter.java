/*     */ package com.thoughtworks.xstream.io.xml;
/*     */ 
/*     */ import com.thoughtworks.xstream.core.util.FastStack;
/*     */ import com.thoughtworks.xstream.io.StreamException;
/*     */ import java.io.IOException;
/*     */ import org.dom4j.Element;
/*     */ import org.dom4j.io.XMLWriter;
/*     */ import org.dom4j.tree.DefaultElement;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.AttributesImpl;
/*     */ 
/*     */ public class Dom4JXmlWriter extends AbstractXmlWriter
/*     */ {
/*     */   private final XMLWriter writer;
/*     */   private final FastStack elementStack;
/*     */   private AttributesImpl attributes;
/*     */   private boolean started;
/*     */   private boolean children;
/*     */ 
/*     */   public Dom4JXmlWriter(XMLWriter writer)
/*     */   {
/*  35 */     this(writer, new XmlFriendlyReplacer());
/*     */   }
/*     */ 
/*     */   public Dom4JXmlWriter(XMLWriter writer, XmlFriendlyReplacer replacer)
/*     */   {
/*  42 */     super(replacer);
/*  43 */     this.writer = writer;
/*  44 */     this.elementStack = new FastStack(16);
/*  45 */     this.attributes = new AttributesImpl();
/*     */     try {
/*  47 */       writer.startDocument();
/*     */     } catch (SAXException e) {
/*  49 */       throw new StreamException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void startNode(String name) {
/*  54 */     if (this.elementStack.size() > 0) {
/*     */       try {
/*  56 */         startElement();
/*     */       } catch (SAXException e) {
/*  58 */         throw new StreamException(e);
/*     */       }
/*  60 */       this.started = false;
/*     */     }
/*  62 */     this.elementStack.push(escapeXmlName(name));
/*  63 */     this.children = false;
/*     */   }
/*     */ 
/*     */   public void setValue(String text) {
/*  67 */     char[] value = text.toCharArray();
/*  68 */     if (value.length > 0) {
/*     */       try {
/*  70 */         startElement();
/*  71 */         this.writer.characters(value, 0, value.length);
/*     */       } catch (SAXException e) {
/*  73 */         throw new StreamException(e);
/*     */       }
/*  75 */       this.children = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addAttribute(String key, String value) {
/*  80 */     this.attributes.addAttribute("", "", escapeXmlName(key), "string", value);
/*     */   }
/*     */ 
/*     */   public void endNode() {
/*     */     try {
/*  85 */       if (!this.children) {
/*  86 */         Element element = new DefaultElement((String)this.elementStack.pop());
/*  87 */         for (int i = 0; i < this.attributes.getLength(); i++) {
/*  88 */           element.addAttribute(this.attributes.getQName(i), this.attributes.getValue(i));
/*     */         }
/*  90 */         this.writer.write(element);
/*  91 */         this.attributes.clear();
/*  92 */         this.children = true;
/*  93 */         this.started = true;
/*     */       } else {
/*  95 */         startElement();
/*  96 */         this.writer.endElement("", "", (String)this.elementStack.pop());
/*     */       }
/*     */     } catch (SAXException e) {
/*  99 */       throw new StreamException(e);
/*     */     } catch (IOException e) {
/* 101 */       throw new StreamException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void flush()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void close() {
/*     */     try {
/* 111 */       this.writer.endDocument();
/*     */     } catch (SAXException e) {
/* 113 */       throw new StreamException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void startElement() throws SAXException {
/* 118 */     if (!this.started) {
/* 119 */       this.writer.startElement("", "", (String)this.elementStack.peek(), this.attributes);
/* 120 */       this.attributes.clear();
/* 121 */       this.started = true;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.Dom4JXmlWriter
 * JD-Core Version:    0.6.0
 */