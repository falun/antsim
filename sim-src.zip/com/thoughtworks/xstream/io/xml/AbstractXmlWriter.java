/*    */ package com.thoughtworks.xstream.io.xml;
/*    */ 
/*    */ import com.thoughtworks.xstream.io.ExtendedHierarchicalStreamWriter;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*    */ 
/*    */ public abstract class AbstractXmlWriter
/*    */   implements ExtendedHierarchicalStreamWriter, XmlFriendlyWriter
/*    */ {
/*    */   private XmlFriendlyReplacer replacer;
/*    */ 
/*    */   protected AbstractXmlWriter()
/*    */   {
/* 29 */     this(new XmlFriendlyReplacer());
/*    */   }
/*    */ 
/*    */   protected AbstractXmlWriter(XmlFriendlyReplacer replacer) {
/* 33 */     this.replacer = replacer;
/*    */   }
/*    */ 
/*    */   public void startNode(String name, Class clazz) {
/* 37 */     startNode(name);
/*    */   }
/*    */ 
/*    */   public String escapeXmlName(String name)
/*    */   {
/* 47 */     return this.replacer.escapeName(name);
/*    */   }
/*    */ 
/*    */   public HierarchicalStreamWriter underlyingWriter() {
/* 51 */     return this;
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.AbstractXmlWriter
 * JD-Core Version:    0.6.0
 */