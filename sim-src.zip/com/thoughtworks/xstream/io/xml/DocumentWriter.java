package com.thoughtworks.xstream.io.xml;

import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
import java.util.List;

public abstract interface DocumentWriter extends HierarchicalStreamWriter
{
  public abstract List getTopLevelNodes();
}

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.DocumentWriter
 * JD-Core Version:    0.6.0
 */