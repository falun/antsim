/*    */ package com.thoughtworks.xstream.io.xml;
/*    */ 
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*    */ import com.thoughtworks.xstream.io.StreamException;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.io.OutputStreamWriter;
/*    */ import java.io.Reader;
/*    */ import java.io.Writer;
/*    */ import org.jdom.Document;
/*    */ import org.jdom.JDOMException;
/*    */ import org.jdom.input.SAXBuilder;
/*    */ 
/*    */ public class JDomDriver extends AbstractXmlDriver
/*    */ {
/*    */   public JDomDriver()
/*    */   {
/* 35 */     super(new XmlFriendlyReplacer());
/*    */   }
/*    */ 
/*    */   public JDomDriver(XmlFriendlyReplacer replacer)
/*    */   {
/* 42 */     super(replacer);
/*    */   }
/*    */ 
/*    */   public HierarchicalStreamReader createReader(Reader reader) {
/*    */     try {
/* 47 */       SAXBuilder builder = new SAXBuilder();
/* 48 */       Document document = builder.build(reader);
/* 49 */       return new JDomReader(document, xmlFriendlyReplacer());
/*    */     } catch (IOException e) {
/* 51 */       throw new StreamException(e); } catch (JDOMException e) {
/*    */     }
/* 53 */     throw new StreamException(e);
/*    */   }
/*    */ 
/*    */   public HierarchicalStreamReader createReader(InputStream in)
/*    */   {
/*    */     try {
/* 59 */       SAXBuilder builder = new SAXBuilder();
/* 60 */       Document document = builder.build(in);
/* 61 */       return new JDomReader(document, xmlFriendlyReplacer());
/*    */     } catch (IOException e) {
/* 63 */       throw new StreamException(e); } catch (JDOMException e) {
/*    */     }
/* 65 */     throw new StreamException(e);
/*    */   }
/*    */ 
/*    */   public HierarchicalStreamWriter createWriter(Writer out)
/*    */   {
/* 70 */     return new PrettyPrintWriter(out, xmlFriendlyReplacer());
/*    */   }
/*    */ 
/*    */   public HierarchicalStreamWriter createWriter(OutputStream out) {
/* 74 */     return new PrettyPrintWriter(new OutputStreamWriter(out));
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.JDomDriver
 * JD-Core Version:    0.6.0
 */