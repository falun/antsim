/*    */ package com.thoughtworks.xstream.io.xml;
/*    */ 
/*    */ import nu.xom.Attribute;
/*    */ import nu.xom.Document;
/*    */ import nu.xom.Element;
/*    */ import nu.xom.Elements;
/*    */ import nu.xom.Node;
/*    */ import nu.xom.Text;
/*    */ 
/*    */ public class XomReader extends AbstractDocumentReader
/*    */ {
/*    */   private Element currentElement;
/*    */ 
/*    */   public XomReader(Element rootElement)
/*    */   {
/* 24 */     super(rootElement);
/*    */   }
/*    */ 
/*    */   public XomReader(Document document) {
/* 28 */     super(document.getRootElement());
/*    */   }
/*    */ 
/*    */   public XomReader(Element rootElement, XmlFriendlyReplacer replacer)
/*    */   {
/* 35 */     super(rootElement, replacer);
/*    */   }
/*    */ 
/*    */   public XomReader(Document document, XmlFriendlyReplacer replacer)
/*    */   {
/* 42 */     super(document.getRootElement(), replacer);
/*    */   }
/*    */ 
/*    */   public String getNodeName() {
/* 46 */     return unescapeXmlName(this.currentElement.getLocalName());
/*    */   }
/*    */ 
/*    */   public String getValue()
/*    */   {
/* 51 */     StringBuffer result = new StringBuffer();
/* 52 */     int childCount = this.currentElement.getChildCount();
/* 53 */     for (int i = 0; i < childCount; i++) {
/* 54 */       Node child = this.currentElement.getChild(i);
/* 55 */       if ((child instanceof Text)) {
/* 56 */         Text text = (Text)child;
/* 57 */         result.append(text.getValue());
/*    */       }
/*    */     }
/* 60 */     return result.toString();
/*    */   }
/*    */ 
/*    */   public String getAttribute(String name) {
/* 64 */     return this.currentElement.getAttributeValue(name);
/*    */   }
/*    */ 
/*    */   public String getAttribute(int index) {
/* 68 */     return this.currentElement.getAttribute(index).getValue();
/*    */   }
/*    */ 
/*    */   public int getAttributeCount() {
/* 72 */     return this.currentElement.getAttributeCount();
/*    */   }
/*    */ 
/*    */   public String getAttributeName(int index) {
/* 76 */     return unescapeXmlName(this.currentElement.getAttribute(index).getQualifiedName());
/*    */   }
/*    */ 
/*    */   protected int getChildCount() {
/* 80 */     return this.currentElement.getChildElements().size();
/*    */   }
/*    */ 
/*    */   protected Object getParent() {
/* 84 */     return this.currentElement.getParent();
/*    */   }
/*    */ 
/*    */   protected Object getChild(int index) {
/* 88 */     return this.currentElement.getChildElements().get(index);
/*    */   }
/*    */ 
/*    */   protected void reassignCurrentElement(Object current) {
/* 92 */     this.currentElement = ((Element)current);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.XomReader
 * JD-Core Version:    0.6.0
 */