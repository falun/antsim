/*    */ package com.thoughtworks.xstream.io.xml;
/*    */ 
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*    */ import com.thoughtworks.xstream.io.StreamException;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.io.OutputStreamWriter;
/*    */ import java.io.Reader;
/*    */ import java.io.Writer;
/*    */ import nu.xom.Builder;
/*    */ import nu.xom.Document;
/*    */ import nu.xom.ParsingException;
/*    */ import nu.xom.ValidityException;
/*    */ 
/*    */ public class XomDriver extends AbstractXmlDriver
/*    */ {
/*    */   private final Builder builder;
/*    */ 
/*    */   public XomDriver()
/*    */   {
/* 35 */     this(new Builder());
/*    */   }
/*    */ 
/*    */   public XomDriver(Builder builder) {
/* 39 */     this(builder, new XmlFriendlyReplacer());
/*    */   }
/*    */ 
/*    */   public XomDriver(XmlFriendlyReplacer replacer)
/*    */   {
/* 46 */     this(new Builder(), replacer);
/*    */   }
/*    */ 
/*    */   public XomDriver(Builder builder, XmlFriendlyReplacer replacer)
/*    */   {
/* 53 */     super(replacer);
/* 54 */     this.builder = builder;
/*    */   }
/*    */ 
/*    */   protected Builder getBuilder() {
/* 58 */     return this.builder;
/*    */   }
/*    */ 
/*    */   public HierarchicalStreamReader createReader(Reader text) {
/*    */     try {
/* 63 */       Document document = this.builder.build(text);
/* 64 */       return new XomReader(document, xmlFriendlyReplacer());
/*    */     } catch (ValidityException e) {
/* 66 */       throw new StreamException(e);
/*    */     } catch (ParsingException e) {
/* 68 */       throw new StreamException(e); } catch (IOException e) {
/*    */     }
/* 70 */     throw new StreamException(e);
/*    */   }
/*    */ 
/*    */   public HierarchicalStreamReader createReader(InputStream in)
/*    */   {
/*    */     try {
/* 76 */       Document document = this.builder.build(in);
/* 77 */       return new XomReader(document, xmlFriendlyReplacer());
/*    */     } catch (ValidityException e) {
/* 79 */       throw new StreamException(e);
/*    */     } catch (ParsingException e) {
/* 81 */       throw new StreamException(e); } catch (IOException e) {
/*    */     }
/* 83 */     throw new StreamException(e);
/*    */   }
/*    */ 
/*    */   public HierarchicalStreamWriter createWriter(Writer out)
/*    */   {
/* 88 */     return new PrettyPrintWriter(out, xmlFriendlyReplacer());
/*    */   }
/*    */ 
/*    */   public HierarchicalStreamWriter createWriter(OutputStream out) {
/* 92 */     return new PrettyPrintWriter(new OutputStreamWriter(out), xmlFriendlyReplacer());
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.XomDriver
 * JD-Core Version:    0.6.0
 */