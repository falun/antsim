/*     */ package com.thoughtworks.xstream.io.xml;
/*     */ 
/*     */ import com.thoughtworks.xstream.converters.ErrorWriter;
/*     */ import com.thoughtworks.xstream.io.StreamException;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.xmlpull.mxp1.MXParser;
/*     */ import org.xmlpull.v1.XmlPullParser;
/*     */ import org.xmlpull.v1.XmlPullParserException;
/*     */ 
/*     */ public class XppReader extends AbstractPullReader
/*     */ {
/*     */   private final XmlPullParser parser;
/*     */   private final BufferedReader reader;
/*     */ 
/*     */   public XppReader(Reader reader)
/*     */   {
/*  36 */     this(reader, new XmlFriendlyReplacer());
/*     */   }
/*     */ 
/*     */   public XppReader(Reader reader, XmlFriendlyReplacer replacer)
/*     */   {
/*  43 */     super(replacer);
/*     */     try {
/*  45 */       this.parser = createParser();
/*  46 */       this.reader = new BufferedReader(reader);
/*  47 */       this.parser.setInput(this.reader);
/*  48 */       moveDown();
/*     */     } catch (XmlPullParserException e) {
/*  50 */       throw new StreamException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected XmlPullParser createParser()
/*     */   {
/*  58 */     return new MXParser();
/*     */   }
/*     */ 
/*     */   protected int pullNextEvent() {
/*     */     try {
/*  63 */       switch (this.parser.next()) {
/*     */       case 0:
/*     */       case 2:
/*  66 */         return 1;
/*     */       case 1:
/*     */       case 3:
/*  69 */         return 2;
/*     */       case 4:
/*  71 */         return 3;
/*     */       case 9:
/*  73 */         return 4;
/*     */       case 5:
/*     */       case 6:
/*     */       case 7:
/*  75 */       case 8: } return 0;
/*     */     }
/*     */     catch (XmlPullParserException e) {
/*  78 */       throw new StreamException(e); } catch (IOException e) {
/*     */     }
/*  80 */     throw new StreamException(e);
/*     */   }
/*     */ 
/*     */   protected String pullElementName()
/*     */   {
/*  85 */     return this.parser.getName();
/*     */   }
/*     */ 
/*     */   protected String pullText() {
/*  89 */     return this.parser.getText();
/*     */   }
/*     */ 
/*     */   public String getAttribute(String name) {
/*  93 */     return this.parser.getAttributeValue(null, escapeXmlName(name));
/*     */   }
/*     */ 
/*     */   public String getAttribute(int index) {
/*  97 */     return this.parser.getAttributeValue(index);
/*     */   }
/*     */ 
/*     */   public int getAttributeCount() {
/* 101 */     return this.parser.getAttributeCount();
/*     */   }
/*     */ 
/*     */   public String getAttributeName(int index) {
/* 105 */     return unescapeXmlName(this.parser.getAttributeName(index));
/*     */   }
/*     */ 
/*     */   public void appendErrors(ErrorWriter errorWriter) {
/* 109 */     errorWriter.add("line number", String.valueOf(this.parser.getLineNumber()));
/*     */   }
/*     */ 
/*     */   public void close() {
/*     */     try {
/* 114 */       this.reader.close();
/*     */     } catch (IOException e) {
/* 116 */       throw new StreamException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.XppReader
 * JD-Core Version:    0.6.0
 */