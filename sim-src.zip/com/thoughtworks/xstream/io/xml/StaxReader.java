/*     */ package com.thoughtworks.xstream.io.xml;
/*     */ 
/*     */ import com.thoughtworks.xstream.converters.ErrorWriter;
/*     */ import com.thoughtworks.xstream.io.StreamException;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.Location;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ 
/*     */ public class StaxReader extends AbstractPullReader
/*     */ {
/*     */   private final QNameMap qnameMap;
/*     */   private final XMLStreamReader in;
/*     */ 
/*     */   public StaxReader(QNameMap qnameMap, XMLStreamReader in)
/*     */   {
/*  34 */     this(qnameMap, in, new XmlFriendlyReplacer());
/*     */   }
/*     */ 
/*     */   public StaxReader(QNameMap qnameMap, XMLStreamReader in, XmlFriendlyReplacer replacer)
/*     */   {
/*  41 */     super(replacer);
/*  42 */     this.qnameMap = qnameMap;
/*  43 */     this.in = in;
/*  44 */     moveDown();
/*     */   }
/*     */ 
/*     */   protected int pullNextEvent() {
/*     */     try {
/*  49 */       switch (this.in.next()) {
/*     */       case 1:
/*     */       case 7:
/*  52 */         return 1;
/*     */       case 2:
/*     */       case 8:
/*  55 */         return 2;
/*     */       case 4:
/*  57 */         return 3;
/*     */       case 5:
/*  59 */         return 4;
/*     */       case 3:
/*  61 */       case 6: } return 0;
/*     */     } catch (XMLStreamException e) {
/*     */     }
/*  64 */     throw new StreamException(e);
/*     */   }
/*     */ 
/*     */   protected String pullElementName()
/*     */   {
/*  70 */     QName qname = this.in.getName();
/*  71 */     return this.qnameMap.getJavaClassName(qname);
/*     */   }
/*     */ 
/*     */   protected String pullText() {
/*  75 */     return this.in.getText();
/*     */   }
/*     */ 
/*     */   public String getAttribute(String name) {
/*  79 */     return this.in.getAttributeValue(null, name);
/*     */   }
/*     */ 
/*     */   public String getAttribute(int index) {
/*  83 */     return this.in.getAttributeValue(index);
/*     */   }
/*     */ 
/*     */   public int getAttributeCount() {
/*  87 */     return this.in.getAttributeCount();
/*     */   }
/*     */ 
/*     */   public String getAttributeName(int index) {
/*  91 */     return unescapeXmlName(this.in.getAttributeLocalName(index));
/*     */   }
/*     */ 
/*     */   public void appendErrors(ErrorWriter errorWriter) {
/*  95 */     errorWriter.add("line number", String.valueOf(this.in.getLocation().getLineNumber()));
/*     */   }
/*     */ 
/*     */   public void close() {
/*     */     try {
/* 100 */       this.in.close();
/*     */     } catch (XMLStreamException e) {
/* 102 */       throw new StreamException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.StaxReader
 * JD-Core Version:    0.6.0
 */