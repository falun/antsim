/*     */ package com.thoughtworks.xstream.io.xml;
/*     */ 
/*     */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*     */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*     */ import com.thoughtworks.xstream.io.StreamException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLOutputFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ 
/*     */ public class StaxDriver extends AbstractXmlDriver
/*     */ {
/*     */   private static boolean libraryPresent;
/*     */   private QNameMap qnameMap;
/*     */   private XMLInputFactory inputFactory;
/*     */   private XMLOutputFactory outputFactory;
/*     */ 
/*     */   public StaxDriver()
/*     */   {
/*  44 */     this.qnameMap = new QNameMap();
/*     */   }
/*     */ 
/*     */   public StaxDriver(QNameMap qnameMap) {
/*  48 */     this(qnameMap, false);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public StaxDriver(QNameMap qnameMap, boolean repairingNamespace)
/*     */   {
/*  55 */     this(qnameMap, new XmlFriendlyReplacer());
/*  56 */     setRepairingNamespace(repairingNamespace);
/*     */   }
/*     */ 
/*     */   public StaxDriver(QNameMap qnameMap, XmlFriendlyReplacer replacer)
/*     */   {
/*  63 */     super(replacer);
/*  64 */     this.qnameMap = qnameMap;
/*     */   }
/*     */ 
/*     */   public StaxDriver(XmlFriendlyReplacer replacer)
/*     */   {
/*  71 */     this(new QNameMap(), replacer);
/*     */   }
/*     */ 
/*     */   public HierarchicalStreamReader createReader(Reader xml) {
/*  75 */     loadLibrary();
/*     */     try {
/*  77 */       return createStaxReader(createParser(xml));
/*     */     } catch (XMLStreamException e) {
/*     */     }
/*  80 */     throw new StreamException(e);
/*     */   }
/*     */ 
/*     */   public HierarchicalStreamReader createReader(InputStream in)
/*     */   {
/*  85 */     loadLibrary();
/*     */     try {
/*  87 */       return createStaxReader(createParser(in));
/*     */     } catch (XMLStreamException e) {
/*     */     }
/*  90 */     throw new StreamException(e);
/*     */   }
/*     */ 
/*     */   private void loadLibrary()
/*     */   {
/*  95 */     if (!libraryPresent) {
/*     */       try {
/*  97 */         Class.forName("javax.xml.stream.XMLStreamReader");
/*     */       }
/*     */       catch (ClassNotFoundException e) {
/* 100 */         throw new IllegalArgumentException("StAX API is not present. Specify another driver. For example: new XStream(new DomDriver())");
/*     */       }
/*     */ 
/* 103 */       libraryPresent = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public HierarchicalStreamWriter createWriter(Writer out) {
/*     */     try {
/* 109 */       return createStaxWriter(getOutputFactory().createXMLStreamWriter(out));
/*     */     } catch (XMLStreamException e) {
/*     */     }
/* 112 */     throw new StreamException(e);
/*     */   }
/*     */ 
/*     */   public HierarchicalStreamWriter createWriter(OutputStream out)
/*     */   {
/*     */     try {
/* 118 */       return createStaxWriter(getOutputFactory().createXMLStreamWriter(out));
/*     */     } catch (XMLStreamException e) {
/*     */     }
/* 121 */     throw new StreamException(e);
/*     */   }
/*     */ 
/*     */   public AbstractPullReader createStaxReader(XMLStreamReader in)
/*     */   {
/* 126 */     return new StaxReader(this.qnameMap, in, xmlFriendlyReplacer());
/*     */   }
/*     */ 
/*     */   public StaxWriter createStaxWriter(XMLStreamWriter out, boolean writeStartEndDocument) throws XMLStreamException {
/* 130 */     return new StaxWriter(this.qnameMap, out, writeStartEndDocument, isRepairingNamespace(), xmlFriendlyReplacer());
/*     */   }
/*     */ 
/*     */   public StaxWriter createStaxWriter(XMLStreamWriter out) throws XMLStreamException {
/* 134 */     return createStaxWriter(out, true);
/*     */   }
/*     */ 
/*     */   public QNameMap getQnameMap()
/*     */   {
/* 141 */     return this.qnameMap;
/*     */   }
/*     */ 
/*     */   public void setQnameMap(QNameMap qnameMap) {
/* 145 */     this.qnameMap = qnameMap;
/*     */   }
/*     */ 
/*     */   public XMLInputFactory getInputFactory() {
/* 149 */     if (this.inputFactory == null) {
/* 150 */       this.inputFactory = XMLInputFactory.newInstance();
/*     */     }
/* 152 */     return this.inputFactory;
/*     */   }
/*     */ 
/*     */   public XMLOutputFactory getOutputFactory() {
/* 156 */     if (this.outputFactory == null) {
/* 157 */       this.outputFactory = XMLOutputFactory.newInstance();
/*     */     }
/* 159 */     return this.outputFactory;
/*     */   }
/*     */ 
/*     */   public boolean isRepairingNamespace() {
/* 163 */     return Boolean.TRUE.equals(getOutputFactory().getProperty("javax.xml.stream.isRepairingNamespaces"));
/*     */   }
/*     */ 
/*     */   public void setRepairingNamespace(boolean repairing)
/*     */   {
/* 171 */     getOutputFactory().setProperty("javax.xml.stream.isRepairingNamespaces", repairing ? Boolean.TRUE : Boolean.FALSE);
/*     */   }
/*     */ 
/*     */   protected XMLStreamReader createParser(Reader xml)
/*     */     throws XMLStreamException
/*     */   {
/* 179 */     return getInputFactory().createXMLStreamReader(xml);
/*     */   }
/*     */ 
/*     */   protected XMLStreamReader createParser(InputStream xml) throws XMLStreamException {
/* 183 */     return getInputFactory().createXMLStreamReader(xml);
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.StaxDriver
 * JD-Core Version:    0.6.0
 */