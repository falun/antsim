/*    */ package com.thoughtworks.xstream.io.xml;
/*    */ 
/*    */ import com.thoughtworks.xstream.io.xml.xppdom.Xpp3Dom;
/*    */ import java.util.List;
/*    */ 
/*    */ public class XppDomWriter extends AbstractDocumentWriter
/*    */ {
/*    */   public XppDomWriter()
/*    */   {
/* 19 */     this(null, new XmlFriendlyReplacer());
/*    */   }
/*    */ 
/*    */   public XppDomWriter(Xpp3Dom parent)
/*    */   {
/* 26 */     this(parent, new XmlFriendlyReplacer());
/*    */   }
/*    */ 
/*    */   public XppDomWriter(XmlFriendlyReplacer replacer)
/*    */   {
/* 33 */     this(null, replacer);
/*    */   }
/*    */ 
/*    */   public XppDomWriter(Xpp3Dom parent, XmlFriendlyReplacer replacer)
/*    */   {
/* 40 */     super(parent, replacer);
/*    */   }
/*    */ 
/*    */   public Xpp3Dom getConfiguration() {
/* 44 */     return (Xpp3Dom)getTopLevelNodes().get(0);
/*    */   }
/*    */ 
/*    */   protected Object createNode(String name) {
/* 48 */     Xpp3Dom newNode = new Xpp3Dom(escapeXmlName(name));
/* 49 */     Xpp3Dom top = top();
/* 50 */     if (top != null) {
/* 51 */       top().addChild(newNode);
/*    */     }
/* 53 */     return newNode;
/*    */   }
/*    */ 
/*    */   public void setValue(String text) {
/* 57 */     top().setValue(text);
/*    */   }
/*    */ 
/*    */   public void addAttribute(String key, String value) {
/* 61 */     top().setAttribute(escapeXmlName(key), value);
/*    */   }
/*    */ 
/*    */   private Xpp3Dom top() {
/* 65 */     return (Xpp3Dom)getCurrent();
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.XppDomWriter
 * JD-Core Version:    0.6.0
 */