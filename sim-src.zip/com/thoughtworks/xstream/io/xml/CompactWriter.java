/*    */ package com.thoughtworks.xstream.io.xml;
/*    */ 
/*    */ import java.io.Writer;
/*    */ 
/*    */ public class CompactWriter extends PrettyPrintWriter
/*    */ {
/*    */   public CompactWriter(Writer writer)
/*    */   {
/* 19 */     super(writer);
/*    */   }
/*    */ 
/*    */   public CompactWriter(Writer writer, int mode)
/*    */   {
/* 26 */     super(writer, mode);
/*    */   }
/*    */ 
/*    */   public CompactWriter(Writer writer, XmlFriendlyReplacer replacer) {
/* 30 */     super(writer, replacer);
/*    */   }
/*    */ 
/*    */   public CompactWriter(Writer writer, int mode, XmlFriendlyReplacer replacer)
/*    */   {
/* 37 */     super(writer, mode, replacer);
/*    */   }
/*    */ 
/*    */   protected void endOfLine()
/*    */   {
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.CompactWriter
 * JD-Core Version:    0.6.0
 */