/*    */ package com.thoughtworks.xstream.io.xml;
/*    */ 
/*    */ import com.thoughtworks.xstream.core.util.XmlHeaderAwareReader;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*    */ import com.thoughtworks.xstream.io.StreamException;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.io.OutputStreamWriter;
/*    */ import java.io.Reader;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.io.Writer;
/*    */ 
/*    */ public class XppDriver extends AbstractXmlDriver
/*    */ {
/*    */   private static boolean xppLibraryPresent;
/*    */ 
/*    */   public XppDriver()
/*    */   {
/* 32 */     super(new XmlFriendlyReplacer());
/*    */   }
/*    */ 
/*    */   public XppDriver(XmlFriendlyReplacer replacer)
/*    */   {
/* 39 */     super(replacer);
/*    */   }
/*    */ 
/*    */   public HierarchicalStreamReader createReader(Reader xml) {
/* 43 */     loadLibrary();
/* 44 */     return new XppReader(xml, xmlFriendlyReplacer());
/*    */   }
/*    */ 
/*    */   public HierarchicalStreamReader createReader(InputStream in) {
/*    */     try {
/* 49 */       return createReader(new XmlHeaderAwareReader(in));
/*    */     } catch (UnsupportedEncodingException e) {
/* 51 */       throw new StreamException(e); } catch (IOException e) {
/*    */     }
/* 53 */     throw new StreamException(e);
/*    */   }
/*    */ 
/*    */   private void loadLibrary()
/*    */   {
/* 58 */     if (!xppLibraryPresent) {
/*    */       try {
/* 60 */         Class.forName("org.xmlpull.mxp1.MXParser", false, getClass().getClassLoader());
/*    */       } catch (ClassNotFoundException e) {
/* 62 */         throw new IllegalArgumentException("XPP3 pull parser library not present. Specify another driver. For example: new XStream(new DomDriver())");
/*    */       }
/*    */ 
/* 65 */       xppLibraryPresent = true;
/*    */     }
/*    */   }
/*    */ 
/*    */   public HierarchicalStreamWriter createWriter(Writer out) {
/* 70 */     return new PrettyPrintWriter(out, xmlFriendlyReplacer());
/*    */   }
/*    */ 
/*    */   public HierarchicalStreamWriter createWriter(OutputStream out) {
/* 74 */     return createWriter(new OutputStreamWriter(out));
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.XppDriver
 * JD-Core Version:    0.6.0
 */