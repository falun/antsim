/*    */ package com.thoughtworks.xstream.io.xml;
/*    */ 
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamDriver;
/*    */ 
/*    */ public abstract class AbstractXmlDriver
/*    */   implements HierarchicalStreamDriver
/*    */ {
/*    */   private XmlFriendlyReplacer replacer;
/*    */ 
/*    */   public AbstractXmlDriver()
/*    */   {
/* 31 */     this(new XmlFriendlyReplacer());
/*    */   }
/*    */ 
/*    */   public AbstractXmlDriver(XmlFriendlyReplacer replacer)
/*    */   {
/* 39 */     this.replacer = replacer;
/*    */   }
/*    */ 
/*    */   protected XmlFriendlyReplacer xmlFriendlyReplacer() {
/* 43 */     return this.replacer;
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.AbstractXmlDriver
 * JD-Core Version:    0.6.0
 */