/*    */ package com.thoughtworks.xstream.io.xml;
/*    */ 
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*    */ 
/*    */ public abstract class AbstractXmlReader
/*    */   implements HierarchicalStreamReader, XmlFriendlyReader
/*    */ {
/*    */   private XmlFriendlyReplacer replacer;
/*    */ 
/*    */   protected AbstractXmlReader()
/*    */   {
/* 28 */     this(new XmlFriendlyReplacer());
/*    */   }
/*    */ 
/*    */   protected AbstractXmlReader(XmlFriendlyReplacer replacer) {
/* 32 */     this.replacer = replacer;
/*    */   }
/*    */ 
/*    */   public String unescapeXmlName(String name)
/*    */   {
/* 42 */     return this.replacer.unescapeName(name);
/*    */   }
/*    */ 
/*    */   protected String escapeXmlName(String name)
/*    */   {
/* 52 */     return this.replacer.escapeName(name);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.AbstractXmlReader
 * JD-Core Version:    0.6.0
 */