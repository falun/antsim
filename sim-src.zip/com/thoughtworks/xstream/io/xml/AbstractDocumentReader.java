/*    */ package com.thoughtworks.xstream.io.xml;
/*    */ 
/*    */ import com.thoughtworks.xstream.converters.ErrorWriter;
/*    */ import com.thoughtworks.xstream.core.util.FastStack;
/*    */ import com.thoughtworks.xstream.io.AttributeNameIterator;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ public abstract class AbstractDocumentReader extends AbstractXmlReader
/*    */   implements DocumentReader
/*    */ {
/* 23 */   private FastStack pointers = new FastStack(16);
/*    */   private Object current;
/*    */ 
/*    */   protected AbstractDocumentReader(Object rootElement)
/*    */   {
/* 27 */     this(rootElement, new XmlFriendlyReplacer());
/*    */   }
/*    */ 
/*    */   protected AbstractDocumentReader(Object rootElement, XmlFriendlyReplacer replacer)
/*    */   {
/* 34 */     super(replacer);
/* 35 */     this.current = rootElement;
/* 36 */     this.pointers.push(new Pointer(null));
/* 37 */     reassignCurrentElement(this.current); } 
/*    */   protected abstract void reassignCurrentElement(Object paramObject);
/*    */ 
/*    */   protected abstract Object getParent();
/*    */ 
/*    */   protected abstract Object getChild(int paramInt);
/*    */ 
/*    */   protected abstract int getChildCount();
/*    */ 
/* 50 */   public boolean hasMoreChildren() { Pointer pointer = (Pointer)this.pointers.peek();
/*    */ 
/* 53 */     return pointer.v < getChildCount();
/*    */   }
/*    */ 
/*    */   public void moveUp()
/*    */   {
/* 60 */     this.current = getParent();
/* 61 */     this.pointers.popSilently();
/* 62 */     reassignCurrentElement(this.current);
/*    */   }
/*    */ 
/*    */   public void moveDown() {
/* 66 */     Pointer pointer = (Pointer)this.pointers.peek();
/* 67 */     this.pointers.push(new Pointer(null));
/*    */ 
/* 69 */     this.current = getChild(pointer.v);
/*    */ 
/* 71 */     pointer.v += 1;
/* 72 */     reassignCurrentElement(this.current);
/*    */   }
/*    */ 
/*    */   public Iterator getAttributeNames() {
/* 76 */     return new AttributeNameIterator(this);
/*    */   }
/*    */ 
/*    */   public void appendErrors(ErrorWriter errorWriter)
/*    */   {
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public Object peekUnderlyingNode() {
/* 86 */     return this.current;
/*    */   }
/*    */ 
/*    */   public Object getCurrent() {
/* 90 */     return this.current;
/*    */   }
/*    */ 
/*    */   public void close()
/*    */   {
/*    */   }
/*    */ 
/*    */   public HierarchicalStreamReader underlyingReader() {
/* 98 */     return this;
/*    */   }
/*    */ 
/*    */   private static class Pointer
/*    */   {
/*    */     public int v;
/*    */ 
/*    */     private Pointer()
/*    */     {
/*    */     }
/*    */ 
/*    */     Pointer(AbstractDocumentReader.1 x0)
/*    */     {
/* 45 */       this();
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.AbstractDocumentReader
 * JD-Core Version:    0.6.0
 */