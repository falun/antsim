/*     */ package com.thoughtworks.xstream.io.xml;
/*     */ 
/*     */ import com.thoughtworks.xstream.io.StreamException;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ 
/*     */ public class StaxWriter extends AbstractXmlWriter
/*     */ {
/*     */   private final QNameMap qnameMap;
/*     */   private final XMLStreamWriter out;
/*     */   private final boolean writeEnclosingDocument;
/*     */   private boolean namespaceRepairingMode;
/*     */   private int tagDepth;
/*     */ 
/*     */   public StaxWriter(QNameMap qnameMap, XMLStreamWriter out)
/*     */     throws XMLStreamException
/*     */   {
/*  36 */     this(qnameMap, out, true, true);
/*     */   }
/*     */ 
/*     */   public StaxWriter(QNameMap qnameMap, XMLStreamWriter out, boolean writeEnclosingDocument, boolean namespaceRepairingMode)
/*     */     throws XMLStreamException
/*     */   {
/*  48 */     this(qnameMap, out, writeEnclosingDocument, namespaceRepairingMode, new XmlFriendlyReplacer());
/*     */   }
/*     */ 
/*     */   public StaxWriter(QNameMap qnameMap, XMLStreamWriter out, boolean writeEnclosingDocument, boolean namespaceRepairingMode, XmlFriendlyReplacer replacer)
/*     */     throws XMLStreamException
/*     */   {
/*  64 */     super(replacer);
/*  65 */     this.qnameMap = qnameMap;
/*  66 */     this.out = out;
/*  67 */     this.writeEnclosingDocument = writeEnclosingDocument;
/*  68 */     this.namespaceRepairingMode = namespaceRepairingMode;
/*  69 */     if (writeEnclosingDocument)
/*  70 */       out.writeStartDocument();
/*     */   }
/*     */ 
/*     */   public void flush()
/*     */   {
/*     */     try {
/*  76 */       this.out.flush();
/*     */     }
/*     */     catch (XMLStreamException e) {
/*  79 */       throw new StreamException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void close()
/*     */   {
/*     */     try
/*     */     {
/*  88 */       this.out.close();
/*     */     }
/*     */     catch (XMLStreamException e) {
/*  91 */       throw new StreamException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addAttribute(String name, String value) {
/*     */     try {
/*  97 */       this.out.writeAttribute(escapeXmlName(name), value);
/*     */     }
/*     */     catch (XMLStreamException e) {
/* 100 */       throw new StreamException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void endNode() {
/*     */     try {
/* 106 */       this.tagDepth -= 1;
/* 107 */       this.out.writeEndElement();
/* 108 */       if ((this.tagDepth == 0) && (this.writeEnclosingDocument))
/* 109 */         this.out.writeEndDocument();
/*     */     }
/*     */     catch (XMLStreamException e)
/*     */     {
/* 113 */       throw new StreamException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setValue(String text) {
/*     */     try {
/* 119 */       this.out.writeCharacters(text);
/*     */     }
/*     */     catch (XMLStreamException e) {
/* 122 */       throw new StreamException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void startNode(String name) {
/*     */     try {
/* 128 */       QName qname = this.qnameMap.getQName(escapeXmlName(name));
/* 129 */       String prefix = qname.getPrefix();
/* 130 */       String uri = qname.getNamespaceURI();
/*     */ 
/* 135 */       boolean hasPrefix = (prefix != null) && (prefix.length() > 0);
/* 136 */       boolean hasURI = (uri != null) && (uri.length() > 0);
/* 137 */       boolean writeNamespace = false;
/*     */ 
/* 139 */       if (hasURI) {
/* 140 */         if (hasPrefix) {
/* 141 */           String currentNamespace = this.out.getNamespaceContext().getNamespaceURI(prefix);
/* 142 */           if ((currentNamespace == null) || (!currentNamespace.equals(uri)))
/* 143 */             writeNamespace = true;
/*     */         }
/*     */         else
/*     */         {
/* 147 */           String defaultNamespace = this.out.getNamespaceContext().getNamespaceURI("");
/* 148 */           if ((defaultNamespace == null) || (!defaultNamespace.equals(uri))) {
/* 149 */             writeNamespace = true;
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 154 */       if (hasPrefix) {
/* 155 */         this.out.setPrefix(prefix, uri);
/*     */       }
/* 157 */       else if ((hasURI) && 
/* 158 */         (writeNamespace)) {
/* 159 */         this.out.setDefaultNamespace(uri);
/*     */       }
/*     */ 
/* 162 */       this.out.writeStartElement(prefix, qname.getLocalPart(), uri);
/* 163 */       if ((hasURI) && (writeNamespace) && (!isNamespaceRepairingMode())) {
/* 164 */         if (hasPrefix) {
/* 165 */           this.out.writeNamespace(prefix, uri);
/*     */         }
/*     */         else {
/* 168 */           this.out.writeDefaultNamespace(uri);
/*     */         }
/*     */       }
/* 171 */       this.tagDepth += 1;
/*     */     }
/*     */     catch (XMLStreamException e) {
/* 174 */       throw new StreamException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isNamespaceRepairingMode()
/*     */   {
/* 182 */     return this.namespaceRepairingMode;
/*     */   }
/*     */ 
/*     */   protected QNameMap getQNameMap() {
/* 186 */     return this.qnameMap;
/*     */   }
/*     */ 
/*     */   protected XMLStreamWriter getXMLStreamWriter() {
/* 190 */     return this.out;
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.StaxWriter
 * JD-Core Version:    0.6.0
 */