/*     */ package com.thoughtworks.xstream.io.xml;
/*     */ 
/*     */ import com.thoughtworks.xstream.core.util.FastStack;
/*     */ import com.thoughtworks.xstream.io.AttributeNameIterator;
/*     */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public abstract class AbstractPullReader extends AbstractXmlReader
/*     */ {
/*     */   protected static final int START_NODE = 1;
/*     */   protected static final int END_NODE = 2;
/*     */   protected static final int TEXT = 3;
/*     */   protected static final int COMMENT = 4;
/*     */   protected static final int OTHER = 0;
/*  35 */   private final FastStack elementStack = new FastStack(16);
/*     */ 
/*  37 */   private final FastStack lookahead = new FastStack(4);
/*  38 */   private final FastStack lookback = new FastStack(4);
/*     */   private boolean marked;
/*     */ 
/*     */   protected AbstractPullReader(XmlFriendlyReplacer replacer)
/*     */   {
/*  50 */     super(replacer);
/*     */   }
/*     */ 
/*     */   protected abstract int pullNextEvent();
/*     */ 
/*     */   protected abstract String pullElementName();
/*     */ 
/*     */   protected abstract String pullText();
/*     */ 
/*     */   public boolean hasMoreChildren()
/*     */   {
/*  76 */     mark();
/*     */     while (true)
/*  78 */       switch (readEvent().type) {
/*     */       case 1:
/*  80 */         reset();
/*  81 */         return true;
/*     */       case 2:
/*  83 */         reset();
/*  84 */         return false;
/*     */       }
/*     */   }
/*     */ 
/*     */   public void moveDown()
/*     */   {
/*  92 */     int currentDepth = this.elementStack.size();
/*  93 */     while (this.elementStack.size() <= currentDepth) {
/*  94 */       move();
/*  95 */       if (this.elementStack.size() < currentDepth)
/*  96 */         throw new RuntimeException();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void moveUp()
/*     */   {
/* 102 */     int currentDepth = this.elementStack.size();
/* 103 */     while (this.elementStack.size() >= currentDepth)
/* 104 */       move();
/*     */   }
/*     */ 
/*     */   private void move()
/*     */   {
/* 109 */     switch (readEvent().type) {
/*     */     case 1:
/* 111 */       this.elementStack.push(pullElementName());
/* 112 */       break;
/*     */     case 2:
/* 114 */       this.elementStack.pop();
/*     */     }
/*     */   }
/*     */ 
/*     */   private Event readEvent()
/*     */   {
/* 120 */     if (this.marked) {
/* 121 */       if (this.lookback.hasStuff()) {
/* 122 */         return (Event)this.lookahead.push(this.lookback.pop());
/*     */       }
/* 124 */       return (Event)this.lookahead.push(readRealEvent());
/*     */     }
/*     */ 
/* 127 */     if (this.lookback.hasStuff()) {
/* 128 */       return (Event)this.lookback.pop();
/*     */     }
/* 130 */     return readRealEvent();
/*     */   }
/*     */ 
/*     */   private Event readRealEvent()
/*     */   {
/* 136 */     Event event = new Event(null);
/* 137 */     event.type = pullNextEvent();
/* 138 */     if (event.type == 3)
/* 139 */       event.value = pullText();
/* 140 */     else if (event.type == 1) {
/* 141 */       event.value = pullElementName();
/*     */     }
/* 143 */     return event;
/*     */   }
/*     */ 
/*     */   public void mark() {
/* 147 */     this.marked = true;
/*     */   }
/*     */ 
/*     */   public void reset() {
/* 151 */     while (this.lookahead.hasStuff()) {
/* 152 */       this.lookback.push(this.lookahead.pop());
/*     */     }
/* 154 */     this.marked = false;
/*     */   }
/*     */ 
/*     */   public String getValue()
/*     */   {
/* 163 */     String last = null;
/* 164 */     StringBuffer buffer = null;
/*     */ 
/* 166 */     mark();
/* 167 */     Event event = readEvent();
/*     */     while (true) {
/* 169 */       if (event.type == 3) {
/* 170 */         String text = event.value;
/* 171 */         if ((text != null) && (text.length() > 0))
/* 172 */           if (last == null) {
/* 173 */             last = text;
/*     */           } else {
/* 175 */             if (buffer == null) {
/* 176 */               buffer = new StringBuffer(last);
/*     */             }
/* 178 */             buffer.append(text);
/*     */           }
/*     */       } else {
/* 181 */         if (event.type != 4)
/*     */           break;
/*     */       }
/* 184 */       event = readEvent();
/*     */     }
/* 186 */     reset();
/* 187 */     if (buffer != null) {
/* 188 */       return buffer.toString();
/*     */     }
/* 190 */     return last == null ? "" : last;
/*     */   }
/*     */ 
/*     */   public Iterator getAttributeNames()
/*     */   {
/* 195 */     return new AttributeNameIterator(this);
/*     */   }
/*     */ 
/*     */   public String getNodeName() {
/* 199 */     return unescapeXmlName((String)this.elementStack.peek());
/*     */   }
/*     */ 
/*     */   public HierarchicalStreamReader underlyingReader() {
/* 203 */     return this;
/*     */   }
/*     */ 
/*     */   private static class Event
/*     */   {
/*     */     int type;
/*     */     String value;
/*     */ 
/*     */     private Event()
/*     */     {
/*     */     }
/*     */ 
/*     */     Event(AbstractPullReader.1 x0)
/*     */     {
/*  41 */       this();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.AbstractPullReader
 * JD-Core Version:    0.6.0
 */