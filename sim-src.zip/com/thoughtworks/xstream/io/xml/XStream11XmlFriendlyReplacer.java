/*     */ package com.thoughtworks.xstream.io.xml;
/*     */ 
/*     */ public class XStream11XmlFriendlyReplacer extends XmlFriendlyReplacer
/*     */ {
/*  22 */   private char dollarReplacementInClass = '-';
/*  23 */   private String dollarReplacementInField = "_DOLLAR_";
/*  24 */   private String underscoreReplacementInField = "__";
/*  25 */   private String noPackagePrefix = "default";
/*     */ 
/*     */   public String unescapeName(String name)
/*     */   {
/*  39 */     return name;
/*     */   }
/*     */ 
/*     */   protected String escapeClassName(String className)
/*     */   {
/*  44 */     className = className.replace('$', this.dollarReplacementInClass);
/*     */ 
/*  47 */     if (className.charAt(0) == this.dollarReplacementInClass) {
/*  48 */       className = this.noPackagePrefix + className;
/*     */     }
/*     */ 
/*  51 */     return className;
/*     */   }
/*     */ 
/*     */   protected String escapeFieldName(String fieldName) {
/*  55 */     StringBuffer result = new StringBuffer();
/*  56 */     int length = fieldName.length();
/*  57 */     for (int i = 0; i < length; i++) {
/*  58 */       char c = fieldName.charAt(i);
/*  59 */       if (c == '$')
/*  60 */         result.append(this.dollarReplacementInField);
/*  61 */       else if (c == '_')
/*  62 */         result.append(this.underscoreReplacementInField);
/*     */       else {
/*  64 */         result.append(c);
/*     */       }
/*     */     }
/*  67 */     return result.toString();
/*     */   }
/*     */ 
/*     */   protected String unescapeClassName(String className)
/*     */   {
/*  72 */     if (className.startsWith(this.noPackagePrefix + this.dollarReplacementInClass)) {
/*  73 */       className = className.substring(this.noPackagePrefix.length());
/*     */     }
/*     */ 
/*  77 */     className = className.replace(this.dollarReplacementInClass, '$');
/*     */ 
/*  79 */     return className;
/*     */   }
/*     */ 
/*     */   protected String unescapeFieldName(String xmlName) {
/*  83 */     StringBuffer result = new StringBuffer();
/*  84 */     int length = xmlName.length();
/*  85 */     for (int i = 0; i < length; i++) {
/*  86 */       char c = xmlName.charAt(i);
/*  87 */       if (stringFoundAt(xmlName, i, this.underscoreReplacementInField)) {
/*  88 */         i += this.underscoreReplacementInField.length() - 1;
/*  89 */         result.append('_');
/*  90 */       } else if (stringFoundAt(xmlName, i, this.dollarReplacementInField)) {
/*  91 */         i += this.dollarReplacementInField.length() - 1;
/*  92 */         result.append('$');
/*     */       } else {
/*  94 */         result.append(c);
/*     */       }
/*     */     }
/*  97 */     return result.toString();
/*     */   }
/*     */ 
/*     */   private boolean stringFoundAt(String name, int i, String replacement)
/*     */   {
/* 103 */     return (name.length() >= i + replacement.length()) && (name.substring(i, i + replacement.length()).equals(replacement));
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.XStream11XmlFriendlyReplacer
 * JD-Core Version:    0.6.0
 */