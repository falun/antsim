/*    */ package com.thoughtworks.xstream.io.xml;
/*    */ 
/*    */ import com.thoughtworks.xstream.core.util.FastStack;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public abstract class AbstractDocumentWriter extends AbstractXmlWriter
/*    */   implements DocumentWriter
/*    */ {
/* 31 */   private final List result = new ArrayList();
/* 32 */   private final FastStack nodeStack = new FastStack(16);
/*    */ 
/*    */   public AbstractDocumentWriter(Object container, XmlFriendlyReplacer replacer)
/*    */   {
/* 43 */     super(replacer);
/* 44 */     if (container != null) {
/* 45 */       this.nodeStack.push(container);
/* 46 */       this.result.add(container);
/*    */     }
/*    */   }
/*    */ 
/*    */   public final void startNode(String name) {
/* 51 */     Object node = createNode(name);
/* 52 */     this.nodeStack.push(node);
/*    */   }
/*    */ 
/*    */   protected abstract Object createNode(String paramString);
/*    */ 
/*    */   public final void endNode()
/*    */   {
/* 66 */     endNodeInternally();
/* 67 */     Object node = this.nodeStack.pop();
/* 68 */     if (this.nodeStack.size() == 0)
/* 69 */       this.result.add(node);
/*    */   }
/*    */ 
/*    */   public void endNodeInternally()
/*    */   {
/*    */   }
/*    */ 
/*    */   protected final Object getCurrent()
/*    */   {
/* 85 */     return this.nodeStack.peek();
/*    */   }
/*    */ 
/*    */   public List getTopLevelNodes() {
/* 89 */     return this.result;
/*    */   }
/*    */ 
/*    */   public void flush()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void close()
/*    */   {
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.AbstractDocumentWriter
 * JD-Core Version:    0.6.0
 */