/*     */ package com.thoughtworks.xstream.io.xml;
/*     */ 
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ 
/*     */ public class XmlFriendlyReplacer
/*     */ {
/*     */   private String dollarReplacement;
/*     */   private String underscoreReplacement;
/*     */   private transient Map escapeCache;
/*     */   private transient Map unescapeCache;
/*     */ 
/*     */   public XmlFriendlyReplacer()
/*     */   {
/*  44 */     this("_-", "__");
/*     */   }
/*     */ 
/*     */   public XmlFriendlyReplacer(String dollarReplacement, String underscoreReplacement)
/*     */   {
/*  54 */     this.dollarReplacement = dollarReplacement;
/*  55 */     this.underscoreReplacement = underscoreReplacement;
/*  56 */     this.escapeCache = new WeakHashMap();
/*  57 */     this.unescapeCache = new WeakHashMap();
/*     */   }
/*     */ 
/*     */   public String escapeName(String name)
/*     */   {
/*  67 */     WeakReference ref = (WeakReference)this.escapeCache.get(name);
/*  68 */     String s = (String)(ref == null ? null : ref.get());
/*     */ 
/*  70 */     if (s == null) {
/*  71 */       int length = name.length();
/*     */ 
/*  74 */       int i = 0;
/*     */ 
/*  76 */       for (; i < length; i++) {
/*  77 */         char c = name.charAt(i);
/*  78 */         if ((c == '$') || (c == '_'))
/*     */         {
/*     */           break;
/*     */         }
/*     */       }
/*  83 */       if (i == length) {
/*  84 */         return name;
/*     */       }
/*     */ 
/*  88 */       StringBuffer result = new StringBuffer(length + 8);
/*     */ 
/*  91 */       if (i > 0) {
/*  92 */         result.append(name.substring(0, i));
/*     */       }
/*     */ 
/*  95 */       for (; i < length; i++) {
/*  96 */         char c = name.charAt(i);
/*  97 */         if (c == '$')
/*  98 */           result.append(this.dollarReplacement);
/*  99 */         else if (c == '_')
/* 100 */           result.append(this.underscoreReplacement);
/*     */         else {
/* 102 */           result.append(c);
/*     */         }
/*     */       }
/* 105 */       s = result.toString();
/* 106 */       this.escapeCache.put(name, new WeakReference(s));
/*     */     }
/* 108 */     return s;
/*     */   }
/*     */ 
/*     */   public String unescapeName(String name)
/*     */   {
/* 118 */     WeakReference ref = (WeakReference)this.unescapeCache.get(name);
/* 119 */     String s = (String)(ref == null ? null : ref.get());
/*     */ 
/* 121 */     if (s == null) {
/* 122 */       char dollarReplacementFirstChar = this.dollarReplacement.charAt(0);
/* 123 */       char underscoreReplacementFirstChar = this.underscoreReplacement.charAt(0);
/* 124 */       int length = name.length();
/*     */ 
/* 127 */       int i = 0;
/*     */ 
/* 129 */       for (; i < length; i++) {
/* 130 */         char c = name.charAt(i);
/*     */ 
/* 132 */         if ((c == dollarReplacementFirstChar) || (c == underscoreReplacementFirstChar))
/*     */         {
/*     */           break;
/*     */         }
/*     */       }
/*     */ 
/* 138 */       if (i == length) {
/* 139 */         return name;
/*     */       }
/*     */ 
/* 143 */       StringBuffer result = new StringBuffer(length + 8);
/*     */ 
/* 146 */       if (i > 0) {
/* 147 */         result.append(name.substring(0, i));
/*     */       }
/*     */ 
/* 150 */       for (; i < length; i++) {
/* 151 */         char c = name.charAt(i);
/* 152 */         if ((c == dollarReplacementFirstChar) && (name.startsWith(this.dollarReplacement, i))) {
/* 153 */           i += this.dollarReplacement.length() - 1;
/* 154 */           result.append('$');
/* 155 */         } else if ((c == underscoreReplacementFirstChar) && (name.startsWith(this.underscoreReplacement, i)))
/*     */         {
/* 157 */           i += this.underscoreReplacement.length() - 1;
/* 158 */           result.append('_');
/*     */         } else {
/* 160 */           result.append(c);
/*     */         }
/*     */       }
/*     */ 
/* 164 */       s = result.toString();
/* 165 */       this.unescapeCache.put(name, new WeakReference(s));
/*     */     }
/* 167 */     return s;
/*     */   }
/*     */ 
/*     */   private Object readResolve() {
/* 171 */     this.escapeCache = new WeakHashMap();
/* 172 */     this.unescapeCache = new WeakHashMap();
/* 173 */     return this;
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.XmlFriendlyReplacer
 * JD-Core Version:    0.6.0
 */