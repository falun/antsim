/*    */ package com.thoughtworks.xstream.io.xml;
/*    */ 
/*    */ import com.thoughtworks.xstream.core.util.XmlHeaderAwareReader;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*    */ import com.thoughtworks.xstream.io.StreamException;
/*    */ import com.thoughtworks.xstream.io.xml.xppdom.Xpp3DomBuilder;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.io.OutputStreamWriter;
/*    */ import java.io.Reader;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.io.Writer;
/*    */ 
/*    */ public class XppDomDriver extends AbstractXmlDriver
/*    */ {
/*    */   public XppDomDriver()
/*    */   {
/* 31 */     super(new XmlFriendlyReplacer());
/*    */   }
/*    */ 
/*    */   public XppDomDriver(XmlFriendlyReplacer replacer)
/*    */   {
/* 38 */     super(replacer);
/*    */   }
/*    */ 
/*    */   public HierarchicalStreamReader createReader(Reader xml) {
/*    */     try {
/* 43 */       return new XppDomReader(Xpp3DomBuilder.build(xml), xmlFriendlyReplacer()); } catch (Exception e) {
/*    */     }
/* 45 */     throw new StreamException(e);
/*    */   }
/*    */ 
/*    */   public HierarchicalStreamReader createReader(InputStream in)
/*    */   {
/*    */     try {
/* 51 */       return createReader(new XmlHeaderAwareReader(in));
/*    */     } catch (UnsupportedEncodingException e) {
/* 53 */       throw new StreamException(e); } catch (IOException e) {
/*    */     }
/* 55 */     throw new StreamException(e);
/*    */   }
/*    */ 
/*    */   public HierarchicalStreamWriter createWriter(Writer out)
/*    */   {
/* 60 */     return new PrettyPrintWriter(out, xmlFriendlyReplacer());
/*    */   }
/*    */ 
/*    */   public HierarchicalStreamWriter createWriter(OutputStream out) {
/* 64 */     return createWriter(new OutputStreamWriter(out));
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.XppDomDriver
 * JD-Core Version:    0.6.0
 */