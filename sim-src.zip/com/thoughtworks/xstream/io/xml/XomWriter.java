/*    */ package com.thoughtworks.xstream.io.xml;
/*    */ 
/*    */ import nu.xom.Attribute;
/*    */ import nu.xom.Element;
/*    */ 
/*    */ public class XomWriter extends AbstractDocumentWriter
/*    */ {
/*    */   public XomWriter()
/*    */   {
/* 24 */     this(null);
/*    */   }
/*    */ 
/*    */   public XomWriter(Element parentElement) {
/* 28 */     this(parentElement, new XmlFriendlyReplacer());
/*    */   }
/*    */ 
/*    */   public XomWriter(Element parentElement, XmlFriendlyReplacer replacer)
/*    */   {
/* 35 */     super(parentElement, replacer);
/*    */   }
/*    */ 
/*    */   protected Object createNode(String name) {
/* 39 */     Element newNode = new Element(escapeXmlName(name));
/* 40 */     Element top = top();
/* 41 */     if (top != null) {
/* 42 */       top().appendChild(newNode);
/*    */     }
/* 44 */     return newNode;
/*    */   }
/*    */ 
/*    */   public void addAttribute(String name, String value) {
/* 48 */     top().addAttribute(new Attribute(escapeXmlName(name), value));
/*    */   }
/*    */ 
/*    */   public void setValue(String text) {
/* 52 */     top().appendChild(text);
/*    */   }
/*    */ 
/*    */   private Element top() {
/* 56 */     return (Element)getCurrent();
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.XomWriter
 * JD-Core Version:    0.6.0
 */