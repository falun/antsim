/*    */ package com.thoughtworks.xstream.io.xml;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.jdom.DefaultJDOMFactory;
/*    */ import org.jdom.Element;
/*    */ import org.jdom.JDOMFactory;
/*    */ 
/*    */ public class JDomWriter extends AbstractDocumentWriter
/*    */ {
/*    */   private final JDOMFactory documentFactory;
/*    */ 
/*    */   public JDomWriter(Element container, JDOMFactory factory, XmlFriendlyReplacer replacer)
/*    */   {
/* 34 */     super(container, replacer);
/* 35 */     this.documentFactory = factory;
/*    */   }
/*    */ 
/*    */   public JDomWriter(Element container, JDOMFactory factory) {
/* 39 */     this(container, factory, new XmlFriendlyReplacer());
/*    */   }
/*    */ 
/*    */   public JDomWriter(JDOMFactory factory, XmlFriendlyReplacer replacer)
/*    */   {
/* 46 */     this(null, factory, replacer);
/*    */   }
/*    */ 
/*    */   public JDomWriter(JDOMFactory factory) {
/* 50 */     this(null, factory);
/*    */   }
/*    */ 
/*    */   public JDomWriter(Element container, XmlFriendlyReplacer replacer)
/*    */   {
/* 57 */     this(container, new DefaultJDOMFactory(), replacer);
/*    */   }
/*    */ 
/*    */   public JDomWriter(Element container) {
/* 61 */     this(container, new DefaultJDOMFactory());
/*    */   }
/*    */ 
/*    */   public JDomWriter() {
/* 65 */     this(new DefaultJDOMFactory());
/*    */   }
/*    */ 
/*    */   protected Object createNode(String name) {
/* 69 */     Element element = this.documentFactory.element(escapeXmlName(name));
/* 70 */     Element parent = top();
/* 71 */     if (parent != null) {
/* 72 */       parent.addContent(element);
/*    */     }
/* 74 */     return element;
/*    */   }
/*    */ 
/*    */   public void setValue(String text) {
/* 78 */     top().addContent(this.documentFactory.text(text));
/*    */   }
/*    */ 
/*    */   public void addAttribute(String key, String value) {
/* 82 */     top().setAttribute(this.documentFactory.attribute(escapeXmlName(key), value));
/*    */   }
/*    */ 
/*    */   private Element top() {
/* 86 */     return (Element)getCurrent();
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public List getResult()
/*    */   {
/* 93 */     return getTopLevelNodes();
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.JDomWriter
 * JD-Core Version:    0.6.0
 */