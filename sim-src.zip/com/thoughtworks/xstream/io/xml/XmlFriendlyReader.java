package com.thoughtworks.xstream.io.xml;

public abstract interface XmlFriendlyReader
{
  public abstract String unescapeXmlName(String paramString);
}

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.XmlFriendlyReader
 * JD-Core Version:    0.6.0
 */