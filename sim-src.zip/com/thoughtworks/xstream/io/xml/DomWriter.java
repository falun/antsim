/*    */ package com.thoughtworks.xstream.io.xml;
/*    */ 
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ public class DomWriter extends AbstractDocumentWriter
/*    */ {
/*    */   private final Document document;
/*    */   private boolean hasRootElement;
/*    */ 
/*    */   public DomWriter(Document document)
/*    */   {
/* 27 */     this(document, new XmlFriendlyReplacer());
/*    */   }
/*    */ 
/*    */   public DomWriter(Element rootElement) {
/* 31 */     this(rootElement, new XmlFriendlyReplacer());
/*    */   }
/*    */ 
/*    */   public DomWriter(Document document, XmlFriendlyReplacer replacer)
/*    */   {
/* 38 */     this(document.getDocumentElement(), document, replacer);
/*    */   }
/*    */ 
/*    */   public DomWriter(Element element, Document document, XmlFriendlyReplacer replacer)
/*    */   {
/* 45 */     super(element, replacer);
/* 46 */     this.document = document;
/* 47 */     this.hasRootElement = (document.getDocumentElement() != null);
/*    */   }
/*    */ 
/*    */   public DomWriter(Element rootElement, XmlFriendlyReplacer replacer)
/*    */   {
/* 54 */     this(rootElement.getOwnerDocument(), replacer);
/*    */   }
/*    */ 
/*    */   protected Object createNode(String name) {
/* 58 */     Element child = this.document.createElement(escapeXmlName(name));
/* 59 */     Element top = top();
/* 60 */     if (top != null) {
/* 61 */       top().appendChild(child);
/* 62 */     } else if (!this.hasRootElement) {
/* 63 */       this.document.appendChild(child);
/* 64 */       this.hasRootElement = true;
/*    */     }
/* 66 */     return child;
/*    */   }
/*    */ 
/*    */   public void addAttribute(String name, String value) {
/* 70 */     top().setAttribute(escapeXmlName(name), value);
/*    */   }
/*    */ 
/*    */   public void setValue(String text) {
/* 74 */     top().appendChild(this.document.createTextNode(text));
/*    */   }
/*    */ 
/*    */   private Element top() {
/* 78 */     return (Element)getCurrent();
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.DomWriter
 * JD-Core Version:    0.6.0
 */