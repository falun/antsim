/*     */ package com.thoughtworks.xstream.io.xml;
/*     */ 
/*     */ import com.thoughtworks.xstream.XStream;
/*     */ import com.thoughtworks.xstream.io.StreamException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.xml.sax.ContentHandler;
/*     */ import org.xml.sax.DTDHandler;
/*     */ import org.xml.sax.EntityResolver;
/*     */ import org.xml.sax.ErrorHandler;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXNotRecognizedException;
/*     */ import org.xml.sax.SAXNotSupportedException;
/*     */ import org.xml.sax.XMLReader;
/*     */ import org.xml.sax.helpers.AttributesImpl;
/*     */ 
/*     */ public final class SaxWriter extends AbstractXmlWriter
/*     */   implements XMLReader
/*     */ {
/*     */   public static final String CONFIGURED_XSTREAM_PROPERTY = "http://com.thoughtworks.xstream/sax/property/configured-xstream";
/*     */   public static final String SOURCE_OBJECT_LIST_PROPERTY = "http://com.thoughtworks.xstream/sax/property/source-object-list";
/*  85 */   private EntityResolver entityResolver = null;
/*     */ 
/*  90 */   private DTDHandler dtdHandler = null;
/*     */ 
/*  95 */   private ContentHandler contentHandler = null;
/*     */ 
/* 100 */   private ErrorHandler errorHandler = null;
/*     */ 
/* 110 */   private Map features = new HashMap();
/*     */ 
/* 115 */   private final Map properties = new HashMap();
/*     */   private final boolean includeEnclosingDocument;
/* 574 */   private int depth = 0;
/* 575 */   private List elementStack = new LinkedList();
/* 576 */   private char[] buffer = new char[''];
/* 577 */   private boolean startTagInProgress = false;
/* 578 */   private final AttributesImpl attributeList = new AttributesImpl();
/*     */ 
/*     */   public SaxWriter(XmlFriendlyReplacer replacer)
/*     */   {
/* 121 */     this(true, replacer);
/*     */   }
/*     */ 
/*     */   public SaxWriter(boolean includeEnclosingDocument, XmlFriendlyReplacer replacer)
/*     */   {
/* 126 */     super(replacer);
/* 127 */     this.includeEnclosingDocument = includeEnclosingDocument;
/*     */   }
/*     */ 
/*     */   public SaxWriter(boolean includeEnclosingDocument) {
/* 131 */     this(includeEnclosingDocument, new XmlFriendlyReplacer());
/*     */   }
/*     */ 
/*     */   public SaxWriter() {
/* 135 */     this(true);
/*     */   }
/*     */ 
/*     */   public void setFeature(String name, boolean value)
/*     */     throws SAXNotRecognizedException
/*     */   {
/* 168 */     if ((name.equals("http://xml.org/sax/features/namespaces")) || (name.equals("http://xml.org/sax/features/namespace-prefixes")))
/*     */     {
/* 170 */       this.features.put(name, value ? Boolean.TRUE : Boolean.FALSE);
/*     */     }
/* 172 */     else throw new SAXNotRecognizedException(name);
/*     */   }
/*     */ 
/*     */   public boolean getFeature(String name)
/*     */     throws SAXNotRecognizedException
/*     */   {
/* 205 */     if ((name.equals("http://xml.org/sax/features/namespaces")) || (name.equals("http://xml.org/sax/features/namespace-prefixes")))
/*     */     {
/* 207 */       Boolean value = (Boolean)(Boolean)this.features.get(name);
/*     */ 
/* 209 */       if (value == null) {
/* 210 */         value = Boolean.FALSE;
/*     */       }
/* 212 */       return value.booleanValue();
/*     */     }
/* 214 */     throw new SAXNotRecognizedException(name);
/*     */   }
/*     */ 
/*     */   public void setProperty(String name, Object value)
/*     */     throws SAXNotRecognizedException, SAXNotSupportedException
/*     */   {
/* 252 */     if (name.equals("http://com.thoughtworks.xstream/sax/property/configured-xstream")) {
/* 253 */       if (!(value instanceof XStream)) {
/* 254 */         throw new SAXNotSupportedException("Value for property \"http://com.thoughtworks.xstream/sax/property/configured-xstream\" must be a non-null XStream object");
/*     */       }
/*     */ 
/*     */     }
/* 258 */     else if (name.equals("http://com.thoughtworks.xstream/sax/property/source-object-list")) {
/* 259 */       if ((value instanceof List)) {
/* 260 */         List list = (List)value;
/*     */ 
/* 262 */         if (list.isEmpty()) {
/* 263 */           throw new SAXNotSupportedException("Value for property \"http://com.thoughtworks.xstream/sax/property/source-object-list\" shall not be an empty list");
/*     */         }
/*     */ 
/* 269 */         value = Collections.unmodifiableList(new ArrayList(list));
/*     */       }
/*     */       else {
/* 272 */         throw new SAXNotSupportedException("Value for property \"http://com.thoughtworks.xstream/sax/property/source-object-list\" must be a non-null List object");
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 277 */       throw new SAXNotRecognizedException(name);
/*     */     }
/* 279 */     this.properties.put(name, value);
/*     */   }
/*     */ 
/*     */   public Object getProperty(String name)
/*     */     throws SAXNotRecognizedException
/*     */   {
/* 307 */     if ((name.equals("http://com.thoughtworks.xstream/sax/property/configured-xstream")) || (name.equals("http://com.thoughtworks.xstream/sax/property/source-object-list")))
/*     */     {
/* 309 */       return this.properties.get(name);
/*     */     }
/* 311 */     throw new SAXNotRecognizedException(name);
/*     */   }
/*     */ 
/*     */   public void setEntityResolver(EntityResolver resolver)
/*     */   {
/* 335 */     if (resolver == null) {
/* 336 */       throw new NullPointerException("resolver");
/*     */     }
/* 338 */     this.entityResolver = resolver;
/*     */   }
/*     */ 
/*     */   public EntityResolver getEntityResolver()
/*     */   {
/* 350 */     return this.entityResolver;
/*     */   }
/*     */ 
/*     */   public void setDTDHandler(DTDHandler handler)
/*     */   {
/* 369 */     if (handler == null) {
/* 370 */       throw new NullPointerException("handler");
/*     */     }
/* 372 */     this.dtdHandler = handler;
/*     */   }
/*     */ 
/*     */   public DTDHandler getDTDHandler()
/*     */   {
/* 384 */     return this.dtdHandler;
/*     */   }
/*     */ 
/*     */   public void setContentHandler(ContentHandler handler)
/*     */   {
/* 404 */     if (handler == null) {
/* 405 */       throw new NullPointerException("handler");
/*     */     }
/* 407 */     this.contentHandler = handler;
/*     */   }
/*     */ 
/*     */   public ContentHandler getContentHandler()
/*     */   {
/* 419 */     return this.contentHandler;
/*     */   }
/*     */ 
/*     */   public void setErrorHandler(ErrorHandler handler)
/*     */   {
/* 441 */     if (handler == null) {
/* 442 */       throw new NullPointerException("handler");
/*     */     }
/* 444 */     this.errorHandler = handler;
/*     */   }
/*     */ 
/*     */   public ErrorHandler getErrorHandler()
/*     */   {
/* 456 */     return this.errorHandler;
/*     */   }
/*     */ 
/*     */   public void parse(String systemId)
/*     */     throws SAXException
/*     */   {
/* 490 */     parse();
/*     */   }
/*     */ 
/*     */   public void parse(InputSource input)
/*     */     throws SAXException
/*     */   {
/* 532 */     parse();
/*     */   }
/*     */ 
/*     */   private void parse()
/*     */     throws SAXException
/*     */   {
/* 543 */     XStream xstream = (XStream)(XStream)this.properties.get("http://com.thoughtworks.xstream/sax/property/configured-xstream");
/* 544 */     if (xstream == null) {
/* 545 */       xstream = new XStream();
/*     */     }
/*     */ 
/* 548 */     List source = (List)(List)this.properties.get("http://com.thoughtworks.xstream/sax/property/source-object-list");
/* 549 */     if ((source == null) || (source.isEmpty())) {
/* 550 */       throw new SAXException("Missing or empty source object list. Setting property \"http://com.thoughtworks.xstream/sax/property/source-object-list\" is mandatory");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 555 */       startDocument(true);
/* 556 */       for (Iterator i = source.iterator(); i.hasNext(); ) {
/* 557 */         xstream.marshal(i.next(), this);
/*     */       }
/* 559 */       endDocument(true);
/*     */     } catch (StreamException e) {
/* 561 */       if ((e.getCause() instanceof SAXException)) {
/* 562 */         throw ((SAXException)(SAXException)e.getCause());
/*     */       }
/* 564 */       throw new SAXException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void startNode(String name)
/*     */   {
/*     */     try
/*     */     {
/* 582 */       if (this.depth != 0)
/* 583 */         flushStartTag();
/* 584 */       else if (this.includeEnclosingDocument) {
/* 585 */         startDocument(false);
/*     */       }
/* 587 */       this.elementStack.add(0, escapeXmlName(name));
/*     */ 
/* 589 */       this.startTagInProgress = true;
/* 590 */       this.depth += 1;
/*     */     } catch (SAXException e) {
/* 592 */       throw new StreamException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addAttribute(String name, String value) {
/* 597 */     if (this.startTagInProgress) {
/* 598 */       String escapedName = escapeXmlName(name);
/* 599 */       this.attributeList.addAttribute("", escapedName, escapedName, "CDATA", value);
/*     */     } else {
/* 601 */       throw new StreamException(new IllegalStateException("No startElement being processed"));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setValue(String text) {
/*     */     try {
/* 607 */       flushStartTag();
/*     */ 
/* 609 */       int lg = text.length();
/* 610 */       if (lg > this.buffer.length) {
/* 611 */         this.buffer = new char[lg];
/*     */       }
/* 613 */       text.getChars(0, lg, this.buffer, 0);
/*     */ 
/* 615 */       this.contentHandler.characters(this.buffer, 0, lg);
/*     */     } catch (SAXException e) {
/* 617 */       throw new StreamException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void endNode() {
/*     */     try {
/* 623 */       flushStartTag();
/*     */ 
/* 625 */       String tagName = (String)(String)this.elementStack.remove(0);
/*     */ 
/* 627 */       this.contentHandler.endElement("", tagName, tagName);
/*     */ 
/* 629 */       this.depth -= 1;
/* 630 */       if ((this.depth == 0) && (this.includeEnclosingDocument))
/* 631 */         endDocument(false);
/*     */     }
/*     */     catch (SAXException e) {
/* 634 */       throw new StreamException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void startDocument(boolean multiObjectMode)
/*     */     throws SAXException
/*     */   {
/* 648 */     if (this.depth == 0)
/*     */     {
/* 650 */       this.contentHandler.startDocument();
/*     */ 
/* 652 */       if (multiObjectMode)
/*     */       {
/* 655 */         this.depth += 1;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void endDocument(boolean multiObjectMode)
/*     */     throws SAXException
/*     */   {
/* 670 */     if ((this.depth == 0) || ((this.depth == 1) && (multiObjectMode))) {
/* 671 */       this.contentHandler.endDocument();
/* 672 */       this.depth = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void flushStartTag()
/*     */     throws SAXException
/*     */   {
/* 683 */     if (this.startTagInProgress) {
/* 684 */       String tagName = (String)(String)this.elementStack.get(0);
/*     */ 
/* 686 */       this.contentHandler.startElement("", tagName, tagName, this.attributeList);
/*     */ 
/* 688 */       this.attributeList.clear();
/* 689 */       this.startTagInProgress = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void flush()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void close()
/*     */   {
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.SaxWriter
 * JD-Core Version:    0.6.0
 */