/*    */ package com.thoughtworks.xstream.io.xml;
/*    */ 
/*    */ import org.dom4j.Branch;
/*    */ import org.dom4j.DocumentFactory;
/*    */ import org.dom4j.Element;
/*    */ 
/*    */ public class Dom4JWriter extends AbstractDocumentWriter
/*    */ {
/*    */   private final DocumentFactory documentFactory;
/*    */ 
/*    */   public Dom4JWriter(Branch root, DocumentFactory factory, XmlFriendlyReplacer replacer)
/*    */   {
/* 29 */     super(root, replacer);
/* 30 */     this.documentFactory = factory;
/*    */   }
/*    */ 
/*    */   public Dom4JWriter(DocumentFactory factory, XmlFriendlyReplacer replacer)
/*    */   {
/* 37 */     this(null, factory, replacer);
/*    */   }
/*    */ 
/*    */   public Dom4JWriter(DocumentFactory documentFactory)
/*    */   {
/* 44 */     this(documentFactory, new XmlFriendlyReplacer());
/*    */   }
/*    */ 
/*    */   public Dom4JWriter(Branch root, XmlFriendlyReplacer replacer)
/*    */   {
/* 51 */     this(root, new DocumentFactory(), replacer);
/*    */   }
/*    */ 
/*    */   public Dom4JWriter(Branch root) {
/* 55 */     this(root, new DocumentFactory(), new XmlFriendlyReplacer());
/*    */   }
/*    */ 
/*    */   public Dom4JWriter()
/*    */   {
/* 62 */     this(new DocumentFactory(), new XmlFriendlyReplacer());
/*    */   }
/*    */ 
/*    */   protected Object createNode(String name) {
/* 66 */     Element element = this.documentFactory.createElement(escapeXmlName(name));
/* 67 */     Branch top = top();
/* 68 */     if (top != null) {
/* 69 */       top().add(element);
/*    */     }
/* 71 */     return element;
/*    */   }
/*    */ 
/*    */   public void setValue(String text) {
/* 75 */     top().setText(text);
/*    */   }
/*    */ 
/*    */   public void addAttribute(String key, String value) {
/* 79 */     ((Element)top()).addAttribute(escapeXmlName(key), value);
/*    */   }
/*    */ 
/*    */   private Branch top() {
/* 83 */     return (Branch)getCurrent();
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.Dom4JWriter
 * JD-Core Version:    0.6.0
 */