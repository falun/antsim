package com.thoughtworks.xstream.io.xml;

import com.thoughtworks.xstream.io.HierarchicalStreamReader;

public abstract interface DocumentReader extends HierarchicalStreamReader
{
  public abstract Object getCurrent();
}

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.io.xml.DocumentReader
 * JD-Core Version:    0.6.0
 */