package com.thoughtworks.xstream.persistence;

import java.util.Iterator;

public abstract interface PersistenceStrategy
{
  public abstract Iterator iterator();

  public abstract int size();

  public abstract Object get(Object paramObject);

  public abstract Object put(Object paramObject1, Object paramObject2);

  public abstract Object remove(Object paramObject);
}

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.persistence.PersistenceStrategy
 * JD-Core Version:    0.6.0
 */