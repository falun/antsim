package com.thoughtworks.xstream.persistence;

/** @deprecated */
public abstract interface StreamStrategy extends PersistenceStrategy
{
}

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.persistence.StreamStrategy
 * JD-Core Version:    0.6.0
 */