/*     */ package com.thoughtworks.xstream.persistence;
/*     */ 
/*     */ import com.thoughtworks.xstream.XStream;
/*     */ import com.thoughtworks.xstream.converters.ConverterLookup;
/*     */ import com.thoughtworks.xstream.io.StreamException;
/*     */ import com.thoughtworks.xstream.mapper.Mapper;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FilenameFilter;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ public abstract class AbstractFilePersistenceStrategy
/*     */   implements PersistenceStrategy
/*     */ {
/*     */   private final FilenameFilter filter;
/*     */   private final File baseDirectory;
/*     */   private final String encoding;
/*     */   private final transient XStream xstream;
/*     */ 
/*     */   public AbstractFilePersistenceStrategy(File baseDirectory, XStream xstream, String encoding)
/*     */   {
/*  49 */     this.baseDirectory = baseDirectory;
/*  50 */     this.xstream = xstream;
/*  51 */     this.encoding = encoding;
/*  52 */     this.filter = new ValidFilenameFilter();
/*     */   }
/*     */ 
/*     */   protected ConverterLookup getConverterLookup() {
/*  56 */     return this.xstream.getConverterLookup();
/*     */   }
/*     */ 
/*     */   protected Mapper getMapper() {
/*  60 */     return this.xstream.getMapper();
/*     */   }
/*     */ 
/*     */   protected boolean isValid(File dir, String name) {
/*  64 */     return name.endsWith(".xml");
/*     */   }
/*     */ 
/*     */   protected abstract Object extractKey(String paramString);
/*     */ 
/*     */   protected abstract String getName(Object paramObject);
/*     */ 
/*     */   private void writeFile(File file, Object value)
/*     */   {
/*     */     try
/*     */     {
/* 143 */       FileOutputStream out = new FileOutputStream(file);
/* 144 */       Writer writer = this.encoding != null ? new OutputStreamWriter(out, this.encoding) : new OutputStreamWriter(out);
/*     */       try
/*     */       {
/* 148 */         this.xstream.toXML(value, writer);
/*     */       } finally {
/* 150 */         writer.close();
/*     */       }
/*     */     } catch (IOException e) {
/* 153 */       throw new StreamException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private File getFile(String filename) {
/* 158 */     return new File(this.baseDirectory, filename);
/*     */   }
/*     */ 
/*     */   private Object readFile(File file) {
/*     */     try {
/* 163 */       FileInputStream in = new FileInputStream(file);
/* 164 */       Reader reader = this.encoding != null ? new InputStreamReader(in, this.encoding) : new InputStreamReader(in);
/*     */       try
/*     */       {
/* 168 */         Object localObject1 = this.xstream.fromXML(reader);
/*     */         return localObject1; } finally { reader.close(); }
/*     */     }
/*     */     catch (FileNotFoundException e)
/*     */     {
/* 174 */       return null; } catch (IOException e) {
/*     */     }
/* 176 */     throw new StreamException(e);
/*     */   }
/*     */ 
/*     */   public Object put(Object key, Object value)
/*     */   {
/* 181 */     Object oldValue = get(key);
/* 182 */     String filename = getName(key);
/* 183 */     writeFile(new File(this.baseDirectory, filename), value);
/* 184 */     return oldValue;
/*     */   }
/*     */ 
/*     */   public Iterator iterator() {
/* 188 */     return new XmlMapEntriesIterator();
/*     */   }
/*     */ 
/*     */   public int size() {
/* 192 */     return this.baseDirectory.list(this.filter).length;
/*     */   }
/*     */ 
/*     */   public boolean containsKey(Object key)
/*     */   {
/* 197 */     File file = getFile(getName(key));
/* 198 */     return file.isFile();
/*     */   }
/*     */ 
/*     */   public Object get(Object key) {
/* 202 */     return readFile(getFile(getName(key)));
/*     */   }
/*     */ 
/*     */   public Object remove(Object key)
/*     */   {
/* 207 */     File file = getFile(getName(key));
/* 208 */     Object value = null;
/* 209 */     if (file.isFile()) {
/* 210 */       value = readFile(file);
/* 211 */       file.delete();
/*     */     }
/* 213 */     return value;
/*     */   }
/*     */ 
/*     */   protected class XmlMapEntriesIterator
/*     */     implements Iterator
/*     */   {
/*  91 */     private final File[] files = AbstractFilePersistenceStrategy.this.baseDirectory.listFiles(AbstractFilePersistenceStrategy.this.filter);
/*     */ 
/*  93 */     private int position = -1;
/*     */ 
/*  95 */     private File current = null;
/*     */ 
/*     */     protected XmlMapEntriesIterator() {  }
/*     */ 
/*  98 */     public boolean hasNext() { return this.position + 1 < this.files.length; }
/*     */ 
/*     */     public void remove()
/*     */     {
/* 102 */       if (this.current == null) {
/* 103 */         throw new IllegalStateException();
/*     */       }
/*     */ 
/* 106 */       this.current.delete();
/*     */     }
/*     */ 
/*     */     public Object next() {
/* 110 */       return new Map.Entry() {
/* 111 */         private final File file = AbstractFilePersistenceStrategy.XmlMapEntriesIterator.access$202(AbstractFilePersistenceStrategy.XmlMapEntriesIterator.this, AbstractFilePersistenceStrategy.XmlMapEntriesIterator.this.files[AbstractFilePersistenceStrategy.XmlMapEntriesIterator.access$404(AbstractFilePersistenceStrategy.XmlMapEntriesIterator.this)]);
/* 112 */         private final Object key = AbstractFilePersistenceStrategy.this.extractKey(this.file.getName());
/*     */ 
/*     */         public Object getKey() {
/* 115 */           return this.key;
/*     */         }
/*     */ 
/*     */         public Object getValue() {
/* 119 */           return AbstractFilePersistenceStrategy.this.readFile(this.file);
/*     */         }
/*     */ 
/*     */         public Object setValue(Object value) {
/* 123 */           return AbstractFilePersistenceStrategy.this.put(this.key, value);
/*     */         }
/*     */ 
/*     */         public boolean equals(Object obj) {
/* 127 */           if (!(obj instanceof Map.Entry)) {
/* 128 */             return false;
/*     */           }
/* 130 */           Object value = getValue();
/* 131 */           Map.Entry e2 = (Map.Entry)obj;
/* 132 */           Object key2 = e2.getKey();
/* 133 */           Object value2 = e2.getValue();
/* 134 */           return (this.key == null ? key2 == null : this.key.equals(key2)) && (value == null ? value2 == null : getValue().equals(e2.getValue()));
/*     */         }
/*     */       };
/*     */     }
/*     */   }
/*     */ 
/*     */   protected class ValidFilenameFilter
/*     */     implements FilenameFilter
/*     */   {
/*     */     protected ValidFilenameFilter()
/*     */     {
/*     */     }
/*     */ 
/*     */     public boolean accept(File dir, String name)
/*     */     {
/*  85 */       return (new File(dir, name).isFile()) && (AbstractFilePersistenceStrategy.this.isValid(dir, name));
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.persistence.AbstractFilePersistenceStrategy
 * JD-Core Version:    0.6.0
 */