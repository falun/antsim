/*    */ package com.thoughtworks.xstream.persistence;
/*    */ 
/*    */ import java.util.AbstractMap;
/*    */ import java.util.AbstractSet;
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class XmlMap extends AbstractMap
/*    */ {
/*    */   private final PersistenceStrategy persistenceStrategy;
/*    */ 
/*    */   public XmlMap(PersistenceStrategy streamStrategy)
/*    */   {
/* 31 */     this.persistenceStrategy = streamStrategy;
/*    */   }
/*    */ 
/*    */   public int size() {
/* 35 */     return this.persistenceStrategy.size();
/*    */   }
/*    */ 
/*    */   public Object get(Object key)
/*    */   {
/* 40 */     return this.persistenceStrategy.get(key);
/*    */   }
/*    */ 
/*    */   public Object put(Object key, Object value) {
/* 44 */     return this.persistenceStrategy.put(key, value);
/*    */   }
/*    */ 
/*    */   public Object remove(Object key) {
/* 48 */     return this.persistenceStrategy.remove(key);
/*    */   }
/*    */ 
/*    */   public Set entrySet() {
/* 52 */     return new XmlMapEntries();
/*    */   }
/*    */   class XmlMapEntries extends AbstractSet {
/*    */     XmlMapEntries() {
/*    */     }
/*    */     public int size() {
/* 58 */       return XmlMap.this.size();
/*    */     }
/*    */ 
/*    */     public boolean isEmpty() {
/* 62 */       return XmlMap.this.isEmpty();
/*    */     }
/*    */ 
/*    */     public Iterator iterator() {
/* 66 */       return XmlMap.this.persistenceStrategy.iterator();
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.persistence.XmlMap
 * JD-Core Version:    0.6.0
 */