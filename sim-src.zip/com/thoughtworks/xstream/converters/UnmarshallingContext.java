package com.thoughtworks.xstream.converters;

public abstract interface UnmarshallingContext extends DataHolder
{
  public abstract Object convertAnother(Object paramObject, Class paramClass);

  public abstract Object convertAnother(Object paramObject, Class paramClass, Converter paramConverter);

  public abstract Object currentObject();

  public abstract Class getRequiredType();

  public abstract void addCompletionCallback(Runnable paramRunnable, int paramInt);
}

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.UnmarshallingContext
 * JD-Core Version:    0.6.0
 */