/*    */ package com.thoughtworks.xstream.converters.reflection;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ public class ImmutableFieldKeySorter
/*    */   implements FieldKeySorter
/*    */ {
/*    */   public Map sort(Class type, Map keyedByFieldKey)
/*    */   {
/* 24 */     return keyedByFieldKey;
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.reflection.ImmutableFieldKeySorter
 * JD-Core Version:    0.6.0
 */