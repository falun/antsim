/*     */ package com.thoughtworks.xstream.converters.reflection;
/*     */ 
/*     */ import com.thoughtworks.xstream.converters.ConversionException;
/*     */ import com.thoughtworks.xstream.converters.MarshallingContext;
/*     */ import com.thoughtworks.xstream.converters.UnmarshallingContext;
/*     */ import com.thoughtworks.xstream.io.ExtendedHierarchicalStreamWriterHelper;
/*     */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*     */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*     */ import com.thoughtworks.xstream.mapper.CGLIBMapper.Marker;
/*     */ import com.thoughtworks.xstream.mapper.Mapper;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import net.sf.cglib.proxy.Callback;
/*     */ import net.sf.cglib.proxy.CallbackFilter;
/*     */ import net.sf.cglib.proxy.Enhancer;
/*     */ import net.sf.cglib.proxy.Factory;
/*     */ import net.sf.cglib.proxy.MethodInterceptor;
/*     */ import net.sf.cglib.proxy.NoOp;
/*     */ 
/*     */ public class CGLIBEnhancedConverter extends SerializableConverter
/*     */ {
/*  59 */   private static String DEFAULT_NAMING_MARKER = "$$EnhancerByCGLIB$$";
/*  60 */   private static String CALLBACK_MARKER = "CGLIB$CALLBACK_";
/*     */   private transient Map fieldCache;
/*     */ 
/*     */   public CGLIBEnhancedConverter(Mapper mapper, ReflectionProvider reflectionProvider)
/*     */   {
/*  64 */     super(mapper, new CGLIBFilteringReflectionProvider(reflectionProvider));
/*  65 */     this.fieldCache = new HashMap();
/*     */   }
/*     */ 
/*     */   public boolean canConvert(Class type) {
/*  69 */     return ((Enhancer.isEnhanced(type)) && (type.getName().indexOf(DEFAULT_NAMING_MARKER) > 0)) || (type == CGLIBMapper.Marker.class);
/*     */   }
/*     */ 
/*     */   public void marshal(Object source, HierarchicalStreamWriter writer, MarshallingContext context)
/*     */   {
/*  75 */     Class type = source.getClass();
/*  76 */     boolean hasFactory = Factory.class.isAssignableFrom(type);
/*  77 */     ExtendedHierarchicalStreamWriterHelper.startNode(writer, "type", type);
/*  78 */     context.convertAnother(type.getSuperclass());
/*  79 */     writer.endNode();
/*  80 */     writer.startNode("interfaces");
/*  81 */     Class[] interfaces = type.getInterfaces();
/*  82 */     for (int i = 0; i < interfaces.length; i++) {
/*  83 */       if (interfaces[i] == Factory.class) {
/*     */         continue;
/*     */       }
/*  86 */       ExtendedHierarchicalStreamWriterHelper.startNode(writer, this.mapper.serializedClass(interfaces[i].getClass()), interfaces[i].getClass());
/*     */ 
/*  88 */       context.convertAnother(interfaces[i]);
/*  89 */       writer.endNode();
/*     */     }
/*  91 */     writer.endNode();
/*  92 */     writer.startNode("hasFactory");
/*  93 */     writer.setValue(String.valueOf(hasFactory));
/*  94 */     writer.endNode();
/*  95 */     Map callbackIndexMap = null;
/*  96 */     Callback[] callbacks = hasFactory ? ((Factory)source).getCallbacks() : getCallbacks(source);
/*     */ 
/*  99 */     if (callbacks.length > 1) {
/* 100 */       if (hasFactory) {
/* 101 */         callbackIndexMap = createCallbackIndexMap((Factory)source);
/*     */       } else {
/* 103 */         ConversionException exception = new ConversionException("Cannot handle CGLIB enhanced proxies without factory that have multiple callbacks");
/*     */ 
/* 105 */         exception.add("proxy superclass", type.getSuperclass().getName());
/* 106 */         exception.add("number of callbacks", String.valueOf(callbacks.length));
/* 107 */         throw exception;
/*     */       }
/* 109 */       writer.startNode("callbacks");
/* 110 */       writer.startNode("mapping");
/* 111 */       context.convertAnother(callbackIndexMap);
/* 112 */       writer.endNode();
/*     */     }
/* 114 */     boolean hasInterceptor = false;
/* 115 */     for (int i = 0; i < callbacks.length; i++) {
/* 116 */       Callback callback = callbacks[i];
/* 117 */       if (callback == null) {
/* 118 */         String name = this.mapper.serializedClass(null);
/* 119 */         writer.startNode(name);
/* 120 */         writer.endNode();
/*     */       } else {
/* 122 */         hasInterceptor = (hasInterceptor) || (MethodInterceptor.class.isAssignableFrom(callback.getClass()));
/*     */ 
/* 124 */         ExtendedHierarchicalStreamWriterHelper.startNode(writer, this.mapper.serializedClass(callback.getClass()), callback.getClass());
/*     */ 
/* 126 */         context.convertAnother(callback);
/* 127 */         writer.endNode();
/*     */       }
/*     */     }
/* 130 */     if (callbacks.length > 1)
/* 131 */       writer.endNode();
/*     */     try
/*     */     {
/* 134 */       Field field = type.getDeclaredField("serialVersionUID");
/* 135 */       field.setAccessible(true);
/* 136 */       long serialVersionUID = field.getLong(null);
/* 137 */       ExtendedHierarchicalStreamWriterHelper.startNode(writer, "serialVersionUID", String.class);
/*     */ 
/* 139 */       writer.setValue(String.valueOf(serialVersionUID));
/* 140 */       writer.endNode();
/*     */     } catch (NoSuchFieldException e) {
/*     */     }
/*     */     catch (IllegalAccessException e) {
/* 144 */       throw new ObjectAccessException("Access to serialverionUID of " + type.getName() + " not allowed");
/*     */     }
/*     */ 
/* 148 */     if (hasInterceptor) {
/* 149 */       writer.startNode("instance");
/* 150 */       super.doMarshalConditionally(source, writer, context);
/* 151 */       writer.endNode();
/*     */     }
/*     */   }
/*     */ 
/*     */   private Callback[] getCallbacks(Object source) {
/* 156 */     Class type = source.getClass();
/* 157 */     List fields = (List)this.fieldCache.get(type.getName());
/* 158 */     if (fields == null) {
/* 159 */       fields = new ArrayList();
/* 160 */       this.fieldCache.put(type.getName(), fields);
/* 161 */       for (int i = 0; ; i++) {
/*     */         try {
/* 163 */           Field field = type.getDeclaredField(CALLBACK_MARKER + i);
/* 164 */           field.setAccessible(true);
/* 165 */           fields.add(field);
/*     */         } catch (NoSuchFieldException e) {
/* 167 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 171 */     List list = new ArrayList();
/* 172 */     for (int i = 0; i < fields.size(); i++) {
/*     */       try {
/* 174 */         Field field = (Field)fields.get(i);
/* 175 */         Object callback = field.get(source);
/* 176 */         list.add(callback);
/*     */       } catch (IllegalAccessException e) {
/* 178 */         throw new ObjectAccessException("Access to " + type.getName() + "." + CALLBACK_MARKER + i + " not allowed");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 186 */     return (Callback[])(Callback[])list.toArray(new Callback[list.size()]);
/*     */   }
/*     */ 
/*     */   private Map createCallbackIndexMap(Factory source) {
/* 190 */     Callback[] originalCallbacks = source.getCallbacks();
/* 191 */     Callback[] reverseEngineeringCallbacks = new Callback[originalCallbacks.length];
/* 192 */     Map callbackIndexMap = new HashMap();
/* 193 */     int idxNoOp = -1;
/* 194 */     for (int i = 0; i < originalCallbacks.length; i++) {
/* 195 */       Callback callback = originalCallbacks[i];
/* 196 */       if (callback == null) {
/* 197 */         reverseEngineeringCallbacks[i] = null;
/* 198 */       } else if (NoOp.class.isAssignableFrom(callback.getClass())) {
/* 199 */         reverseEngineeringCallbacks[i] = NoOp.INSTANCE;
/* 200 */         idxNoOp = i;
/*     */       } else {
/* 202 */         reverseEngineeringCallbacks[i] = createReverseEngineeredCallbackOfProperType(callback, i, callbackIndexMap);
/*     */       }
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 208 */       source.setCallbacks(reverseEngineeringCallbacks);
/* 209 */       Set interfaces = new HashSet();
/* 210 */       Set methods = new HashSet();
/* 211 */       Class type = source.getClass();
/*     */       do {
/* 213 */         methods.addAll(Arrays.asList(type.getDeclaredMethods()));
/* 214 */         methods.addAll(Arrays.asList(type.getMethods()));
/* 215 */         Class[] implementedInterfaces = type.getInterfaces();
/* 216 */         interfaces.addAll(Arrays.asList(implementedInterfaces));
/* 217 */         type = type.getSuperclass();
/* 218 */       }while (type != null);
/* 219 */       for (Iterator iterator = interfaces.iterator(); iterator.hasNext(); ) {
/* 220 */         type = (Class)iterator.next();
/* 221 */         methods.addAll(Arrays.asList(type.getDeclaredMethods()));
/*     */       }
/* 223 */       for (Iterator iter = methods.iterator(); iter.hasNext(); ) {
/* 224 */         Method method = (Method)iter.next();
/* 225 */         method.setAccessible(true);
/* 226 */         if ((Factory.class.isAssignableFrom(method.getDeclaringClass())) || ((method.getModifiers() & 0x18) > 0))
/*     */         {
/* 228 */           iter.remove();
/* 229 */           continue;
/*     */         }
/* 231 */         Class[] parameterTypes = method.getParameterTypes();
/* 232 */         Method calledMethod = method;
/*     */         try {
/* 234 */           if ((method.getModifiers() & 0x400) > 0) {
/* 235 */             calledMethod = source.getClass().getMethod(method.getName(), method.getParameterTypes());
/*     */           }
/*     */ 
/* 238 */           callbackIndexMap.put(null, method);
/* 239 */           calledMethod.invoke(source, parameterTypes == null ? (Object[])null : createNullArguments(parameterTypes));
/*     */         }
/*     */         catch (IllegalAccessException e)
/*     */         {
/* 243 */           throw new ObjectAccessException("Access to " + calledMethod + " not allowed");
/*     */         }
/*     */         catch (InvocationTargetException e)
/*     */         {
/*     */         }
/*     */         catch (NoSuchMethodException e) {
/* 249 */           ConversionException exception = new ConversionException("CGLIB enhanced proxies wit abstract nethod that has not been implemented");
/*     */ 
/* 251 */           exception.add("proxy superclass", type.getSuperclass().getName());
/* 252 */           exception.add("method", method.toString());
/* 253 */           throw exception;
/*     */         }
/* 255 */         if (callbackIndexMap.containsKey(method)) {
/* 256 */           iter.remove();
/*     */         }
/*     */       }
/* 259 */       if (idxNoOp >= 0) {
/* 260 */         idx = new Integer(idxNoOp);
/* 261 */         for (iter = methods.iterator(); iter.hasNext(); )
/* 262 */           callbackIndexMap.put(iter.next(), idx);
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       Integer idx;
/*     */       Iterator iter;
/* 266 */       source.setCallbacks(originalCallbacks);
/*     */     }
/*     */ 
/* 269 */     callbackIndexMap.remove(null);
/* 270 */     return callbackIndexMap;
/*     */   }
/*     */ 
/*     */   private Object[] createNullArguments(Class[] parameterTypes) {
/* 274 */     Object[] arguments = new Object[parameterTypes.length];
/* 275 */     for (int i = 0; i < arguments.length; i++) {
/* 276 */       Class type = parameterTypes[i];
/* 277 */       if (type.isPrimitive()) {
/* 278 */         if (type == Byte.TYPE)
/* 279 */           arguments[i] = new Byte(0);
/* 280 */         else if (type == Short.TYPE)
/* 281 */           arguments[i] = new Short(0);
/* 282 */         else if (type == Integer.TYPE)
/* 283 */           arguments[i] = new Integer(0);
/* 284 */         else if (type == Long.TYPE)
/* 285 */           arguments[i] = new Long(0L);
/* 286 */         else if (type == Float.TYPE)
/* 287 */           arguments[i] = new Float(0.0F);
/* 288 */         else if (type == Double.TYPE)
/* 289 */           arguments[i] = new Double(0.0D);
/* 290 */         else if (type == Character.TYPE)
/* 291 */           arguments[i] = new Character('\000');
/*     */         else {
/* 293 */           arguments[i] = Boolean.FALSE;
/*     */         }
/*     */       }
/*     */     }
/* 297 */     return arguments;
/*     */   }
/*     */ 
/*     */   private Callback createReverseEngineeredCallbackOfProperType(Callback callback, int index, Map callbackIndexMap)
/*     */   {
/* 302 */     Class iface = null;
/* 303 */     Class[] interfaces = callback.getClass().getInterfaces();
/* 304 */     for (int i = 0; i < interfaces.length; i++) {
/* 305 */       if (Callback.class.isAssignableFrom(interfaces[i])) {
/* 306 */         iface = interfaces[i];
/* 307 */         if (iface == Callback.class) {
/* 308 */           ConversionException exception = new ConversionException("Cannot handle CGLIB callback");
/*     */ 
/* 310 */           exception.add("CGLIB callback type", callback.getClass().getName());
/* 311 */           throw exception;
/*     */         }
/* 313 */         interfaces = iface.getInterfaces();
/* 314 */         if (Arrays.asList(interfaces).contains(Callback.class)) {
/*     */           break;
/*     */         }
/* 317 */         i = -1;
/*     */       }
/*     */     }
/* 320 */     return (Callback)Proxy.newProxyInstance(iface.getClassLoader(), new Class[] { iface }, new ReverseEngineeringInvocationHandler(index, callbackIndexMap));
/*     */   }
/*     */ 
/*     */   public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext context)
/*     */   {
/* 326 */     Enhancer enhancer = new Enhancer();
/* 327 */     reader.moveDown();
/* 328 */     enhancer.setSuperclass((Class)context.convertAnother(null, Class.class));
/* 329 */     reader.moveUp();
/* 330 */     reader.moveDown();
/* 331 */     List interfaces = new ArrayList();
/* 332 */     while (reader.hasMoreChildren()) {
/* 333 */       reader.moveDown();
/* 334 */       interfaces.add(context.convertAnother(null, this.mapper.realClass(reader.getNodeName())));
/*     */ 
/* 336 */       reader.moveUp();
/*     */     }
/* 338 */     enhancer.setInterfaces((Class[])(Class[])interfaces.toArray(new Class[interfaces.size()]));
/* 339 */     reader.moveUp();
/* 340 */     reader.moveDown();
/* 341 */     boolean useFactory = Boolean.valueOf(reader.getValue()).booleanValue();
/* 342 */     enhancer.setUseFactory(useFactory);
/* 343 */     reader.moveUp();
/*     */ 
/* 345 */     List callbacksToEnhance = new ArrayList();
/* 346 */     List callbacks = new ArrayList();
/* 347 */     Map callbackIndexMap = null;
/* 348 */     reader.moveDown();
/* 349 */     if ("callbacks".equals(reader.getNodeName())) {
/* 350 */       reader.moveDown();
/* 351 */       callbackIndexMap = (Map)context.convertAnother(null, HashMap.class);
/* 352 */       reader.moveUp();
/* 353 */       while (reader.hasMoreChildren()) {
/* 354 */         reader.moveDown();
/* 355 */         readCallback(reader, context, callbacksToEnhance, callbacks);
/* 356 */         reader.moveUp();
/*     */       }
/*     */     }
/* 359 */     readCallback(reader, context, callbacksToEnhance, callbacks);
/*     */ 
/* 361 */     enhancer.setCallbacks((Callback[])(Callback[])callbacksToEnhance.toArray(new Callback[callbacksToEnhance.size()]));
/*     */ 
/* 363 */     if (callbackIndexMap != null) {
/* 364 */       enhancer.setCallbackFilter(new ReverseEngineeredCallbackFilter(callbackIndexMap));
/*     */     }
/* 366 */     reader.moveUp();
/* 367 */     Object result = null;
/* 368 */     while (reader.hasMoreChildren()) {
/* 369 */       reader.moveDown();
/* 370 */       if (reader.getNodeName().equals("serialVersionUID")) {
/* 371 */         enhancer.setSerialVersionUID(Long.valueOf(reader.getValue()));
/* 372 */       } else if (reader.getNodeName().equals("instance")) {
/* 373 */         result = create(enhancer, callbacks, useFactory);
/* 374 */         super.doUnmarshalConditionally(result, reader, context);
/*     */       }
/* 376 */       reader.moveUp();
/*     */     }
/* 378 */     if (result == null) {
/* 379 */       result = create(enhancer, callbacks, useFactory);
/*     */     }
/* 381 */     return this.serializationMethodInvoker.callReadResolve(result);
/*     */   }
/*     */ 
/*     */   private void readCallback(HierarchicalStreamReader reader, UnmarshallingContext context, List callbacksToEnhance, List callbacks)
/*     */   {
/* 386 */     Callback callback = (Callback)context.convertAnother(null, this.mapper.realClass(reader.getNodeName()));
/*     */ 
/* 388 */     callbacks.add(callback);
/* 389 */     if (callback == null)
/* 390 */       callbacksToEnhance.add(NoOp.INSTANCE);
/*     */     else
/* 392 */       callbacksToEnhance.add(callback);
/*     */   }
/*     */ 
/*     */   private Object create(Enhancer enhancer, List callbacks, boolean useFactory)
/*     */   {
/* 397 */     Object result = enhancer.create();
/* 398 */     if (useFactory) {
/* 399 */       ((Factory)result).setCallbacks((Callback[])(Callback[])callbacks.toArray(new Callback[callbacks.size()]));
/*     */     }
/*     */ 
/* 402 */     return result;
/*     */   }
/*     */ 
/*     */   protected List hierarchyFor(Class type) {
/* 406 */     List typeHierarchy = super.hierarchyFor(type);
/*     */ 
/* 408 */     typeHierarchy.remove(typeHierarchy.size() - 1);
/* 409 */     return typeHierarchy;
/*     */   }
/*     */ 
/*     */   private Object readResolve() {
/* 413 */     this.fieldCache = new HashMap();
/* 414 */     return this;
/*     */   }
/*     */ 
/*     */   private static class ReverseEngineeredCallbackFilter
/*     */     implements CallbackFilter
/*     */   {
/*     */     private final Map callbackIndexMap;
/*     */ 
/*     */     public ReverseEngineeredCallbackFilter(Map callbackIndexMap)
/*     */     {
/* 454 */       this.callbackIndexMap = callbackIndexMap;
/*     */     }
/*     */ 
/*     */     public int accept(Method method) {
/* 458 */       if (!this.callbackIndexMap.containsKey(method)) {
/* 459 */         ConversionException exception = new ConversionException("CGLIB callback not detected in reverse engineering");
/*     */ 
/* 461 */         exception.add("CGLIB callback", method.toString());
/* 462 */         throw exception;
/*     */       }
/* 464 */       return ((Integer)this.callbackIndexMap.get(method)).intValue();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static final class ReverseEngineeringInvocationHandler
/*     */     implements InvocationHandler
/*     */   {
/*     */     private final Integer index;
/*     */     private final Map indexMap;
/*     */ 
/*     */     public ReverseEngineeringInvocationHandler(int index, Map indexMap)
/*     */     {
/* 439 */       this.indexMap = indexMap;
/* 440 */       this.index = new Integer(index);
/*     */     }
/*     */ 
/*     */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/* 444 */       this.indexMap.put(this.indexMap.get(null), this.index);
/* 445 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class CGLIBFilteringReflectionProvider extends ReflectionProviderWrapper
/*     */   {
/*     */     public CGLIBFilteringReflectionProvider(ReflectionProvider reflectionProvider)
/*     */     {
/* 420 */       super();
/*     */     }
/*     */ 
/*     */     public void visitSerializableFields(Object object, ReflectionProvider.Visitor visitor) {
/* 424 */       this.wrapped.visitSerializableFields(object, new ReflectionProvider.Visitor(visitor) { private final ReflectionProvider.Visitor val$visitor;
/*     */ 
/* 426 */         public void visit(String name, Class type, Class definedIn, Object value) { if (!name.startsWith("CGLIB$"))
/* 427 */             this.val$visitor.visit(name, type, definedIn, value);
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.reflection.CGLIBEnhancedConverter
 * JD-Core Version:    0.6.0
 */