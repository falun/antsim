/*     */ package com.thoughtworks.xstream.converters.reflection;
/*     */ 
/*     */ import com.thoughtworks.xstream.converters.ConversionException;
/*     */ import com.thoughtworks.xstream.converters.MarshallingContext;
/*     */ import com.thoughtworks.xstream.converters.UnmarshallingContext;
/*     */ import com.thoughtworks.xstream.core.util.CustomObjectInputStream;
/*     */ import com.thoughtworks.xstream.core.util.CustomObjectInputStream.StreamCallback;
/*     */ import com.thoughtworks.xstream.core.util.CustomObjectOutputStream;
/*     */ import com.thoughtworks.xstream.core.util.CustomObjectOutputStream.StreamCallback;
/*     */ import com.thoughtworks.xstream.core.util.HierarchicalStreams;
/*     */ import com.thoughtworks.xstream.io.ExtendedHierarchicalStreamWriterHelper;
/*     */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*     */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*     */ import com.thoughtworks.xstream.mapper.Mapper;
/*     */ import java.io.IOException;
/*     */ import java.io.InvalidObjectException;
/*     */ import java.io.ObjectInputValidation;
/*     */ import java.io.ObjectStreamClass;
/*     */ import java.io.ObjectStreamField;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class SerializableConverter extends AbstractReflectionConverter
/*     */ {
/*     */   private static final String ELEMENT_NULL = "null";
/*     */   private static final String ELEMENT_DEFAULT = "default";
/*     */   private static final String ELEMENT_UNSERIALIZABLE_PARENTS = "unserializable-parents";
/*     */   private static final String ATTRIBUTE_CLASS = "class";
/*     */   private static final String ATTRIBUTE_SERIALIZATION = "serialization";
/*     */   private static final String ATTRIBUTE_VALUE_CUSTOM = "custom";
/*     */   private static final String ELEMENT_FIELDS = "fields";
/*     */   private static final String ELEMENT_FIELD = "field";
/*     */   private static final String ATTRIBUTE_NAME = "name";
/*     */ 
/*     */   public SerializableConverter(Mapper mapper, ReflectionProvider reflectionProvider)
/*     */   {
/*  73 */     super(mapper, new UnserializableParentsReflectionProvider(reflectionProvider));
/*     */   }
/*     */ 
/*     */   public boolean canConvert(Class type) {
/*  77 */     return isSerializable(type);
/*     */   }
/*     */ 
/*     */   private boolean isSerializable(Class type) {
/*  81 */     return (Serializable.class.isAssignableFrom(type)) && ((this.serializationMethodInvoker.supportsReadObject(type, true)) || (this.serializationMethodInvoker.supportsWriteObject(type, true)));
/*     */   }
/*     */ 
/*     */   public void doMarshal(Object source, HierarchicalStreamWriter writer, MarshallingContext context)
/*     */   {
/*  87 */     String attributeName = this.mapper.aliasForSystemAttribute("serialization");
/*  88 */     if (attributeName != null) {
/*  89 */       writer.addAttribute(attributeName, "custom");
/*     */     }
/*     */ 
/*  93 */     Class[] currentType = new Class[1];
/*  94 */     boolean[] writtenClassWrapper = { false };
/*     */ 
/*  96 */     CustomObjectOutputStream.StreamCallback callback = new CustomObjectOutputStream.StreamCallback(writer, context, currentType, source, writtenClassWrapper) { private final HierarchicalStreamWriter val$writer;
/*     */       private final MarshallingContext val$context;
/*     */       private final Class[] val$currentType;
/*     */       private final Object val$source;
/*     */       private final boolean[] val$writtenClassWrapper;
/*     */ 
/*  99 */       public void writeToStream(Object object) { if (object == null) {
/* 100 */           this.val$writer.startNode("null");
/* 101 */           this.val$writer.endNode();
/*     */         } else {
/* 103 */           ExtendedHierarchicalStreamWriterHelper.startNode(this.val$writer, SerializableConverter.this.mapper.serializedClass(object.getClass()), object.getClass());
/* 104 */           this.val$context.convertAnother(object);
/* 105 */           this.val$writer.endNode();
/*     */         } }
/*     */ 
/*     */       public void writeFieldsToStream(Map fields)
/*     */       {
/* 110 */         ObjectStreamClass objectStreamClass = ObjectStreamClass.lookup(this.val$currentType[0]);
/*     */ 
/* 112 */         this.val$writer.startNode("default");
/* 113 */         for (Iterator iterator = fields.keySet().iterator(); iterator.hasNext(); ) {
/* 114 */           String name = (String)iterator.next();
/* 115 */           if (!SerializableConverter.this.mapper.shouldSerializeMember(this.val$currentType[0], name)) {
/*     */             continue;
/*     */           }
/* 118 */           ObjectStreamField field = objectStreamClass.getField(name);
/* 119 */           Object value = fields.get(name);
/* 120 */           if (field == null) {
/* 121 */             throw new ObjectAccessException("Class " + value.getClass().getName() + " may not write a field named '" + name + "'");
/*     */           }
/*     */ 
/* 124 */           if (value != null) {
/* 125 */             ExtendedHierarchicalStreamWriterHelper.startNode(this.val$writer, SerializableConverter.this.mapper.serializedMember(this.val$source.getClass(), name), field.getType());
/* 126 */             if ((field.getType() != value.getClass()) && (!field.getType().isPrimitive())) {
/* 127 */               String attributeName = SerializableConverter.this.mapper.aliasForSystemAttribute("class");
/* 128 */               if (attributeName != null) {
/* 129 */                 this.val$writer.addAttribute(attributeName, SerializableConverter.this.mapper.serializedClass(value.getClass()));
/*     */               }
/*     */             }
/* 132 */             this.val$context.convertAnother(value);
/* 133 */             this.val$writer.endNode();
/*     */           }
/*     */         }
/* 136 */         this.val$writer.endNode();
/*     */       }
/*     */ 
/*     */       public void defaultWriteObject() {
/* 140 */         boolean writtenDefaultFields = false;
/*     */ 
/* 142 */         ObjectStreamClass objectStreamClass = ObjectStreamClass.lookup(this.val$currentType[0]);
/*     */ 
/* 144 */         if (objectStreamClass == null) {
/* 145 */           return;
/*     */         }
/*     */ 
/* 148 */         ObjectStreamField[] fields = objectStreamClass.getFields();
/* 149 */         for (int i = 0; i < fields.length; i++) {
/* 150 */           ObjectStreamField field = fields[i];
/* 151 */           Object value = SerializableConverter.this.readField(field, this.val$currentType[0], this.val$source);
/* 152 */           if (value != null) {
/* 153 */             if (this.val$writtenClassWrapper[0] == 0) {
/* 154 */               this.val$writer.startNode(SerializableConverter.this.mapper.serializedClass(this.val$currentType[0]));
/* 155 */               this.val$writtenClassWrapper[0] = true;
/*     */             }
/* 157 */             if (!writtenDefaultFields) {
/* 158 */               this.val$writer.startNode("default");
/* 159 */               writtenDefaultFields = true;
/*     */             }
/* 161 */             if (!SerializableConverter.this.mapper.shouldSerializeMember(this.val$currentType[0], field.getName()))
/*     */             {
/*     */               continue;
/*     */             }
/* 165 */             ExtendedHierarchicalStreamWriterHelper.startNode(this.val$writer, SerializableConverter.this.mapper.serializedMember(this.val$source.getClass(), field.getName()), field.getType());
/*     */ 
/* 167 */             Class actualType = value.getClass();
/* 168 */             Class defaultType = SerializableConverter.this.mapper.defaultImplementationOf(field.getType());
/* 169 */             if (!actualType.equals(defaultType)) {
/* 170 */               String attributeName = SerializableConverter.this.mapper.aliasForSystemAttribute("class");
/* 171 */               if (attributeName != null) {
/* 172 */                 this.val$writer.addAttribute(attributeName, SerializableConverter.this.mapper.serializedClass(actualType));
/*     */               }
/*     */             }
/*     */ 
/* 176 */             this.val$context.convertAnother(value);
/*     */ 
/* 178 */             this.val$writer.endNode();
/*     */           }
/*     */         }
/* 181 */         if ((this.val$writtenClassWrapper[0] != 0) && (!writtenDefaultFields)) {
/* 182 */           this.val$writer.startNode("default");
/* 183 */           this.val$writer.endNode();
/* 184 */         } else if (writtenDefaultFields) {
/* 185 */           this.val$writer.endNode();
/*     */         }
/*     */       }
/*     */ 
/*     */       public void flush() {
/* 190 */         this.val$writer.flush();
/*     */       }
/*     */ 
/*     */       public void close() {
/* 194 */         throw new UnsupportedOperationException("Objects are not allowed to call ObjectOutputStream.close() from writeObject()");
/*     */       } } ;
/*     */     try
/*     */     {
/* 199 */       boolean mustHandleUnserializableParent = false;
/* 200 */       Iterator classHieararchy = hierarchyFor(source.getClass()).iterator();
/* 201 */       while (classHieararchy.hasNext()) {
/* 202 */         currentType[0] = ((Class)classHieararchy.next());
/* 203 */         if (!Serializable.class.isAssignableFrom(currentType[0])) {
/* 204 */           mustHandleUnserializableParent = true;
/* 205 */           continue;
/*     */         }
/* 207 */         if (mustHandleUnserializableParent) {
/* 208 */           marshalUnserializableParent(writer, context, source);
/* 209 */           mustHandleUnserializableParent = false;
/*     */         }
/* 211 */         if (this.serializationMethodInvoker.supportsWriteObject(currentType[0], false)) {
/* 212 */           writtenClassWrapper[0] = true;
/* 213 */           writer.startNode(this.mapper.serializedClass(currentType[0]));
/* 214 */           CustomObjectOutputStream objectOutputStream = CustomObjectOutputStream.getInstance(context, callback);
/* 215 */           this.serializationMethodInvoker.callWriteObject(currentType[0], source, objectOutputStream);
/* 216 */           objectOutputStream.popCallback();
/* 217 */           writer.endNode();
/* 218 */           continue; } if (this.serializationMethodInvoker.supportsReadObject(currentType[0], false))
/*     */         {
/* 222 */           writtenClassWrapper[0] = true;
/* 223 */           writer.startNode(this.mapper.serializedClass(currentType[0]));
/* 224 */           callback.defaultWriteObject();
/* 225 */           writer.endNode(); continue;
/*     */         }
/* 227 */         writtenClassWrapper[0] = false;
/* 228 */         callback.defaultWriteObject();
/* 229 */         if (writtenClassWrapper[0] != 0) {
/* 230 */           writer.endNode();
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 236 */       throw new ObjectAccessException("Could not call defaultWriteObject()", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void marshalUnserializableParent(HierarchicalStreamWriter writer, MarshallingContext context, Object replacedSource) {
/* 241 */     writer.startNode("unserializable-parents");
/* 242 */     super.doMarshal(replacedSource, writer, context);
/* 243 */     writer.endNode();
/*     */   }
/*     */ 
/*     */   private Object readField(ObjectStreamField field, Class type, Object instance) {
/*     */     try {
/* 248 */       Field javaField = type.getDeclaredField(field.getName());
/* 249 */       javaField.setAccessible(true);
/* 250 */       return javaField.get(instance);
/*     */     } catch (IllegalArgumentException e) {
/* 252 */       throw new ObjectAccessException("Could not get field " + field.getClass() + "." + field.getName(), e);
/*     */     } catch (IllegalAccessException e) {
/* 254 */       throw new ObjectAccessException("Could not get field " + field.getClass() + "." + field.getName(), e);
/*     */     } catch (NoSuchFieldException e) {
/* 256 */       throw new ObjectAccessException("Could not get field " + field.getClass() + "." + field.getName(), e); } catch (SecurityException e) {
/*     */     }
/* 258 */     throw new ObjectAccessException("Could not get field " + field.getClass() + "." + field.getName(), e);
/*     */   }
/*     */ 
/*     */   protected List hierarchyFor(Class type)
/*     */   {
/* 263 */     List result = new ArrayList();
/* 264 */     while (type != Object.class) {
/* 265 */       result.add(type);
/* 266 */       type = type.getSuperclass();
/*     */     }
/*     */ 
/* 270 */     Collections.reverse(result);
/*     */ 
/* 272 */     return result;
/*     */   }
/*     */ 
/*     */   public Object doUnmarshal(Object result, HierarchicalStreamReader reader, UnmarshallingContext context)
/*     */   {
/* 277 */     Class[] currentType = new Class[1];
/*     */ 
/* 279 */     String attributeName = this.mapper.aliasForSystemAttribute("serialization");
/* 280 */     if ((attributeName != null) && (!"custom".equals(reader.getAttribute(attributeName)))) {
/* 281 */       throw new ConversionException("Cannot deserialize object with new readObject()/writeObject() methods");
/*     */     }
/*     */ 
/* 284 */     CustomObjectInputStream.StreamCallback callback = new CustomObjectInputStream.StreamCallback(reader, context, result, currentType) { private final HierarchicalStreamReader val$reader;
/*     */       private final UnmarshallingContext val$context;
/*     */       private final Object val$result;
/*     */       private final Class[] val$currentType;
/*     */ 
/* 286 */       public Object readFromStream() { this.val$reader.moveDown();
/* 287 */         Class type = HierarchicalStreams.readClassType(this.val$reader, SerializableConverter.this.mapper);
/* 288 */         Object value = this.val$context.convertAnother(this.val$result, type);
/* 289 */         this.val$reader.moveUp();
/* 290 */         return value; }
/*     */ 
/*     */       public Map readFieldsFromStream()
/*     */       {
/* 294 */         Map fields = new HashMap();
/* 295 */         this.val$reader.moveDown();
/* 296 */         if (this.val$reader.getNodeName().equals("fields"))
/*     */         {
/* 298 */           while (this.val$reader.hasMoreChildren()) {
/* 299 */             this.val$reader.moveDown();
/* 300 */             if (!this.val$reader.getNodeName().equals("field")) {
/* 301 */               throw new ConversionException("Expected <field/> element inside <field/>");
/*     */             }
/* 303 */             String name = this.val$reader.getAttribute("name");
/* 304 */             Class type = SerializableConverter.this.mapper.realClass(this.val$reader.getAttribute("class"));
/* 305 */             Object value = this.val$context.convertAnother(this.val$result, type);
/* 306 */             fields.put(name, value);
/* 307 */             this.val$reader.moveUp();
/*     */           }
/*     */         }
/* 309 */         if (this.val$reader.getNodeName().equals("default"))
/*     */         {
/* 311 */           ObjectStreamClass objectStreamClass = ObjectStreamClass.lookup(this.val$currentType[0]);
/* 312 */           while (this.val$reader.hasMoreChildren()) {
/* 313 */             this.val$reader.moveDown();
/* 314 */             String name = SerializableConverter.this.mapper.realMember(this.val$currentType[0], this.val$reader.getNodeName());
/* 315 */             if (SerializableConverter.this.mapper.shouldSerializeMember(this.val$currentType[0], name)) {
/* 316 */               String classAttribute = HierarchicalStreams.readClassAttribute(this.val$reader, SerializableConverter.this.mapper);
/*     */               Class type;
/*     */               Class type;
/* 318 */               if (classAttribute != null) {
/* 319 */                 type = SerializableConverter.this.mapper.realClass(classAttribute);
/*     */               } else {
/* 321 */                 ObjectStreamField field = objectStreamClass.getField(name);
/* 322 */                 if (field == null) {
/* 323 */                   throw new ObjectAccessException("Class " + this.val$currentType[0] + " does not contain a field named '" + name + "'");
/*     */                 }
/*     */ 
/* 326 */                 type = field.getType();
/*     */               }
/* 328 */               Object value = this.val$context.convertAnother(this.val$result, type);
/* 329 */               fields.put(name, value);
/*     */             }
/* 331 */             this.val$reader.moveUp();
/*     */           }
/*     */         } else {
/* 334 */           throw new ConversionException("Expected <fields/> or <default/> element when calling ObjectInputStream.readFields()");
/*     */         }
/*     */ 
/* 337 */         this.val$reader.moveUp();
/* 338 */         return fields;
/*     */       }
/*     */ 
/*     */       public void defaultReadObject() {
/* 342 */         if (!this.val$reader.hasMoreChildren()) {
/* 343 */           return;
/*     */         }
/* 345 */         this.val$reader.moveDown();
/* 346 */         if (!this.val$reader.getNodeName().equals("default")) {
/* 347 */           throw new ConversionException("Expected <default/> element in readObject() stream");
/*     */         }
/* 349 */         while (this.val$reader.hasMoreChildren()) {
/* 350 */           this.val$reader.moveDown();
/*     */ 
/* 352 */           String fieldName = SerializableConverter.this.mapper.realMember(this.val$currentType[0], this.val$reader.getNodeName());
/* 353 */           if (SerializableConverter.this.mapper.shouldSerializeMember(this.val$currentType[0], fieldName)) {
/* 354 */             String classAttribute = HierarchicalStreams.readClassAttribute(this.val$reader, SerializableConverter.this.mapper);
/*     */             Class type;
/*     */             Class type;
/* 356 */             if (classAttribute != null)
/* 357 */               type = SerializableConverter.this.mapper.realClass(classAttribute);
/*     */             else {
/* 359 */               type = SerializableConverter.this.mapper.defaultImplementationOf(SerializableConverter.this.reflectionProvider.getFieldType(this.val$result, fieldName, this.val$currentType[0]));
/*     */             }
/*     */ 
/* 362 */             Object value = this.val$context.convertAnother(this.val$result, type);
/* 363 */             SerializableConverter.this.reflectionProvider.writeField(this.val$result, fieldName, value, this.val$currentType[0]);
/*     */           }
/*     */ 
/* 366 */           this.val$reader.moveUp();
/*     */         }
/* 368 */         this.val$reader.moveUp();
/*     */       }
/*     */ 
/*     */       public void registerValidation(ObjectInputValidation validation, int priority) {
/* 372 */         this.val$context.addCompletionCallback(new Runnable(validation) { private final ObjectInputValidation val$validation;
/*     */ 
/*     */           public void run() { try { this.val$validation.validateObject();
/*     */             } catch (InvalidObjectException e) {
/* 377 */               throw new ObjectAccessException("Cannot validate object : " + e.getMessage(), e);
/*     */             }
/*     */           }
/*     */         }
/*     */         , priority);
/*     */       }
/*     */ 
/*     */       public void close()
/*     */       {
/* 384 */         throw new UnsupportedOperationException("Objects are not allowed to call ObjectInputStream.close() from readObject()");
/*     */       }
/*     */     };
/* 388 */     while (reader.hasMoreChildren()) {
/* 389 */       reader.moveDown();
/* 390 */       String nodeName = reader.getNodeName();
/* 391 */       if (nodeName.equals("unserializable-parents")) {
/* 392 */         super.doUnmarshal(result, reader, context);
/*     */       } else {
/* 394 */         String classAttribute = HierarchicalStreams.readClassAttribute(reader, this.mapper);
/* 395 */         if (classAttribute == null)
/* 396 */           currentType[0] = this.mapper.defaultImplementationOf(this.mapper.realClass(nodeName));
/*     */         else {
/* 398 */           currentType[0] = this.mapper.realClass(classAttribute);
/*     */         }
/* 400 */         if (this.serializationMethodInvoker.supportsReadObject(currentType[0], false)) {
/* 401 */           CustomObjectInputStream objectInputStream = CustomObjectInputStream.getInstance(context, callback);
/* 402 */           this.serializationMethodInvoker.callReadObject(currentType[0], result, objectInputStream);
/* 403 */           objectInputStream.popCallback();
/*     */         } else {
/*     */           try {
/* 406 */             callback.defaultReadObject();
/*     */           } catch (IOException e) {
/* 408 */             throw new ObjectAccessException("Could not call defaultWriteObject()", e);
/*     */           }
/*     */         }
/*     */       }
/* 412 */       reader.moveUp();
/*     */     }
/*     */ 
/* 415 */     return result;
/*     */   }
/*     */ 
/*     */   protected void doMarshalConditionally(Object source, HierarchicalStreamWriter writer, MarshallingContext context) {
/* 419 */     if (isSerializable(source.getClass()))
/* 420 */       doMarshal(source, writer, context);
/*     */     else
/* 422 */       super.doMarshal(source, writer, context);
/*     */   }
/*     */ 
/*     */   protected Object doUnmarshalConditionally(Object result, HierarchicalStreamReader reader, UnmarshallingContext context)
/*     */   {
/* 427 */     return isSerializable(result.getClass()) ? doUnmarshal(result, reader, context) : super.doUnmarshal(result, reader, context);
/*     */   }
/*     */ 
/*     */   private static class UnserializableParentsReflectionProvider extends ReflectionProviderWrapper
/*     */   {
/*     */     public UnserializableParentsReflectionProvider(ReflectionProvider reflectionProvider) {
/* 433 */       super();
/*     */     }
/*     */ 
/*     */     public void visitSerializableFields(Object object, ReflectionProvider.Visitor visitor) {
/* 437 */       this.wrapped.visitSerializableFields(object, new ReflectionProvider.Visitor(visitor) { private final ReflectionProvider.Visitor val$visitor;
/*     */ 
/* 439 */         public void visit(String name, Class type, Class definedIn, Object value) { if (!Serializable.class.isAssignableFrom(definedIn))
/* 440 */             this.val$visitor.visit(name, type, definedIn, value);
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.reflection.SerializableConverter
 * JD-Core Version:    0.6.0
 */