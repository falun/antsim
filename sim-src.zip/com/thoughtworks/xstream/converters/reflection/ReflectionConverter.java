/*    */ package com.thoughtworks.xstream.converters.reflection;
/*    */ 
/*    */ import com.thoughtworks.xstream.mapper.Mapper;
/*    */ 
/*    */ public class ReflectionConverter extends AbstractReflectionConverter
/*    */ {
/*    */   public ReflectionConverter(Mapper mapper, ReflectionProvider reflectionProvider)
/*    */   {
/* 19 */     super(mapper, reflectionProvider);
/*    */   }
/*    */ 
/*    */   public boolean canConvert(Class type) {
/* 23 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.reflection.ReflectionConverter
 * JD-Core Version:    0.6.0
 */