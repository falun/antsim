/*     */ package com.thoughtworks.xstream.converters.reflection;
/*     */ 
/*     */ import com.thoughtworks.xstream.converters.ConversionException;
/*     */ import com.thoughtworks.xstream.converters.Converter;
/*     */ import com.thoughtworks.xstream.converters.MarshallingContext;
/*     */ import com.thoughtworks.xstream.converters.SingleValueConverter;
/*     */ import com.thoughtworks.xstream.converters.UnmarshallingContext;
/*     */ import com.thoughtworks.xstream.core.util.HierarchicalStreams;
/*     */ import com.thoughtworks.xstream.core.util.Primitives;
/*     */ import com.thoughtworks.xstream.io.ExtendedHierarchicalStreamWriterHelper;
/*     */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*     */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*     */ import com.thoughtworks.xstream.mapper.Mapper;
/*     */ import com.thoughtworks.xstream.mapper.Mapper.ImplicitCollectionMapping;
/*     */ import com.thoughtworks.xstream.mapper.Mapper.Null;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public abstract class AbstractReflectionConverter
/*     */   implements Converter
/*     */ {
/*     */   protected final ReflectionProvider reflectionProvider;
/*     */   protected final Mapper mapper;
/*     */   protected transient SerializationMethodInvoker serializationMethodInvoker;
/*     */   private transient ReflectionProvider pureJavaReflectionProvider;
/*     */ 
/*     */   public AbstractReflectionConverter(Mapper mapper, ReflectionProvider reflectionProvider)
/*     */   {
/*  43 */     this.mapper = mapper;
/*  44 */     this.reflectionProvider = reflectionProvider;
/*  45 */     this.serializationMethodInvoker = new SerializationMethodInvoker();
/*     */   }
/*     */ 
/*     */   public void marshal(Object original, HierarchicalStreamWriter writer, MarshallingContext context) {
/*  49 */     Object source = this.serializationMethodInvoker.callWriteReplace(original);
/*     */ 
/*  51 */     if (source.getClass() != original.getClass()) {
/*  52 */       String attributeName = this.mapper.aliasForSystemAttribute("resolves-to");
/*  53 */       if (attributeName != null) {
/*  54 */         writer.addAttribute(attributeName, this.mapper.serializedClass(source.getClass()));
/*     */       }
/*  56 */       context.convertAnother(source);
/*     */     } else {
/*  58 */       doMarshal(source, writer, context);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void doMarshal(Object source, HierarchicalStreamWriter writer, MarshallingContext context) {
/*  63 */     Set seenFields = new HashSet();
/*  64 */     Map defaultFieldDefinition = new HashMap();
/*     */ 
/*  67 */     this.reflectionProvider.visitSerializableFields(source, new ReflectionProvider.Visitor(defaultFieldDefinition, source, seenFields, writer) { private final Map val$defaultFieldDefinition;
/*     */       private final Object val$source;
/*     */       private final Set val$seenFields;
/*     */       private final HierarchicalStreamWriter val$writer;
/*     */ 
/*  69 */       public void visit(String fieldName, Class type, Class definedIn, Object value) { if (!AbstractReflectionConverter.this.mapper.shouldSerializeMember(definedIn, fieldName)) {
/*  70 */           return;
/*     */         }
/*  72 */         if (!this.val$defaultFieldDefinition.containsKey(fieldName)) {
/*  73 */           Class lookupType = this.val$source.getClass();
/*     */ 
/*  78 */           this.val$defaultFieldDefinition.put(fieldName, AbstractReflectionConverter.this.reflectionProvider.getField(lookupType, fieldName));
/*     */         }
/*     */ 
/*  81 */         SingleValueConverter converter = AbstractReflectionConverter.this.mapper.getConverterFromItemType(fieldName, type, definedIn);
/*  82 */         if (converter != null) {
/*  83 */           if (value != null) {
/*  84 */             if (this.val$seenFields.contains(fieldName)) {
/*  85 */               throw new ConversionException("Cannot write field with name '" + fieldName + "' twice as attribute for object of type " + this.val$source.getClass().getName());
/*     */             }
/*     */ 
/*  88 */             String str = converter.toString(value);
/*  89 */             if (str != null) {
/*  90 */               this.val$writer.addAttribute(AbstractReflectionConverter.this.mapper.aliasForAttribute(AbstractReflectionConverter.this.mapper.serializedMember(definedIn, fieldName)), str);
/*     */             }
/*     */           }
/*     */ 
/*  94 */           this.val$seenFields.add(fieldName);
/*     */         }
/*     */       }
/*     */     });
/* 100 */     this.reflectionProvider.visitSerializableFields(source, new ReflectionProvider.Visitor(seenFields, source, context, writer, defaultFieldDefinition) { private final Set val$seenFields;
/*     */       private final Object val$source;
/*     */       private final MarshallingContext val$context;
/*     */       private final HierarchicalStreamWriter val$writer;
/*     */       private final Map val$defaultFieldDefinition;
/*     */ 
/* 102 */       public void visit(String fieldName, Class fieldType, Class definedIn, Object newObj) { if (!AbstractReflectionConverter.this.mapper.shouldSerializeMember(definedIn, fieldName)) {
/* 103 */           return;
/*     */         }
/* 105 */         if ((!this.val$seenFields.contains(fieldName)) && (newObj != null)) {
/* 106 */           Mapper.ImplicitCollectionMapping mapping = AbstractReflectionConverter.this.mapper.getImplicitCollectionDefForFieldName(this.val$source.getClass(), fieldName);
/* 107 */           if (mapping != null)
/*     */           {
/*     */             Iterator iter;
/* 108 */             if (mapping.getItemFieldName() != null) {
/* 109 */               Collection list = (Collection)newObj;
/* 110 */               for (iter = list.iterator(); iter.hasNext(); ) {
/* 111 */                 Object obj = iter.next();
/* 112 */                 writeField(fieldName, obj == null ? AbstractReflectionConverter.this.mapper.serializedClass(null) : mapping.getItemFieldName(), mapping.getItemType(), definedIn, obj);
/*     */               }
/*     */             } else {
/* 115 */               this.val$context.convertAnother(newObj);
/*     */             }
/*     */           } else {
/* 118 */             writeField(fieldName, null, fieldType, definedIn, newObj);
/*     */           }
/*     */         } }
/*     */ 
/*     */       private void writeField(String fieldName, String aliasName, Class fieldType, Class definedIn, Object newObj)
/*     */       {
/* 124 */         ExtendedHierarchicalStreamWriterHelper.startNode(this.val$writer, aliasName != null ? aliasName : AbstractReflectionConverter.this.mapper.serializedMember(this.val$source.getClass(), fieldName), fieldType);
/*     */ 
/* 126 */         if (newObj != null) {
/* 127 */           Class actualType = newObj.getClass();
/* 128 */           Class defaultType = AbstractReflectionConverter.this.mapper.defaultImplementationOf(fieldType);
/* 129 */           if (!actualType.equals(defaultType)) {
/* 130 */             String serializedClassName = AbstractReflectionConverter.this.mapper.serializedClass(actualType);
/* 131 */             if (!serializedClassName.equals(AbstractReflectionConverter.this.mapper.serializedClass(defaultType))) {
/* 132 */               String attributeName = AbstractReflectionConverter.this.mapper.aliasForSystemAttribute("class");
/* 133 */               if (attributeName != null) {
/* 134 */                 this.val$writer.addAttribute(attributeName, serializedClassName);
/*     */               }
/*     */             }
/*     */           }
/*     */ 
/* 139 */           Field defaultField = (Field)this.val$defaultFieldDefinition.get(fieldName);
/* 140 */           if (defaultField.getDeclaringClass() != definedIn) {
/* 141 */             String attributeName = AbstractReflectionConverter.this.mapper.aliasForSystemAttribute("defined-in");
/* 142 */             if (attributeName != null) {
/* 143 */               this.val$writer.addAttribute(attributeName, AbstractReflectionConverter.this.mapper.serializedClass(definedIn));
/*     */             }
/*     */           }
/*     */ 
/* 147 */           Field field = AbstractReflectionConverter.this.reflectionProvider.getField(definedIn, fieldName);
/* 148 */           AbstractReflectionConverter.this.marshallField(this.val$context, newObj, field);
/*     */         }
/* 150 */         this.val$writer.endNode();
/*     */       } } );
/*     */   }
/*     */ 
/*     */   protected void marshallField(MarshallingContext context, Object newObj, Field field)
/*     */   {
/* 157 */     context.convertAnother(newObj, this.mapper.getLocalConverter(field.getDeclaringClass(), field.getName()));
/*     */   }
/*     */ 
/*     */   public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext context) {
/* 161 */     Object result = instantiateNewInstance(reader, context);
/* 162 */     result = doUnmarshal(result, reader, context);
/* 163 */     return this.serializationMethodInvoker.callReadResolve(result);
/*     */   }
/*     */ 
/*     */   public Object doUnmarshal(Object result, HierarchicalStreamReader reader, UnmarshallingContext context) {
/* 167 */     SeenFields seenFields = new SeenFields(null);
/* 168 */     Iterator it = reader.getAttributeNames();
/*     */ 
/* 171 */     while (it.hasNext()) {
/* 172 */       String attrAlias = (String)it.next();
/* 173 */       String attrName = this.mapper.realMember(result.getClass(), this.mapper.attributeForAlias(attrAlias));
/* 174 */       Class classDefiningField = determineWhichClassDefinesField(reader);
/* 175 */       boolean fieldExistsInClass = this.reflectionProvider.fieldDefinedInClass(attrName, result.getClass());
/* 176 */       if (fieldExistsInClass) {
/* 177 */         Field field = this.reflectionProvider.getField(result.getClass(), attrName);
/* 178 */         if ((Modifier.isTransient(field.getModifiers())) && (!shouldUnmarshalTransientFields())) {
/*     */           continue;
/*     */         }
/* 181 */         SingleValueConverter converter = this.mapper.getConverterFromAttribute(field.getDeclaringClass(), attrName, field.getType());
/* 182 */         Class type = field.getType();
/* 183 */         if (converter != null) {
/* 184 */           Object value = converter.fromString(reader.getAttribute(attrAlias));
/* 185 */           if (type.isPrimitive()) {
/* 186 */             type = Primitives.box(type);
/*     */           }
/* 188 */           if ((value != null) && (!type.isAssignableFrom(value.getClass()))) {
/* 189 */             throw new ConversionException("Cannot convert type " + value.getClass().getName() + " to type " + type.getName());
/*     */           }
/* 191 */           this.reflectionProvider.writeField(result, attrName, value, classDefiningField);
/* 192 */           seenFields.add(classDefiningField, attrName);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 197 */     Map implicitCollectionsForCurrentObject = null;
/* 198 */     while (reader.hasMoreChildren()) {
/* 199 */       reader.moveDown();
/*     */ 
/* 201 */       String originalNodeName = reader.getNodeName();
/* 202 */       String fieldName = this.mapper.realMember(result.getClass(), originalNodeName);
/* 203 */       Mapper.ImplicitCollectionMapping implicitCollectionMapping = this.mapper.getImplicitCollectionDefForFieldName(result.getClass(), fieldName);
/*     */ 
/* 205 */       Class classDefiningField = determineWhichClassDefinesField(reader);
/* 206 */       boolean fieldExistsInClass = (implicitCollectionMapping == null) && (this.reflectionProvider.fieldDefinedInClass(fieldName, result.getClass()));
/*     */ 
/* 208 */       Class type = implicitCollectionMapping == null ? determineType(reader, fieldExistsInClass, result, fieldName, classDefiningField) : implicitCollectionMapping.getItemType();
/*     */       Object value;
/* 212 */       if (fieldExistsInClass) {
/* 213 */         Field field = this.reflectionProvider.getField(classDefiningField != null ? classDefiningField : result.getClass(), fieldName);
/* 214 */         if ((Modifier.isTransient(field.getModifiers())) && (!shouldUnmarshalTransientFields())) {
/* 215 */           reader.moveUp();
/* 216 */           continue;
/*     */         }
/* 218 */         Object value = unmarshallField(context, result, type, field);
/*     */ 
/* 220 */         Class definedType = this.reflectionProvider.getFieldType(result, fieldName, classDefiningField);
/* 221 */         if (!definedType.isPrimitive())
/* 222 */           type = definedType;
/*     */       }
/*     */       else {
/* 225 */         value = type != null ? context.convertAnother(result, type) : null;
/*     */       }
/*     */ 
/* 228 */       if ((value != null) && (!type.isAssignableFrom(value.getClass()))) {
/* 229 */         throw new ConversionException("Cannot convert type " + value.getClass().getName() + " to type " + type.getName());
/*     */       }
/*     */ 
/* 232 */       if (fieldExistsInClass) {
/* 233 */         this.reflectionProvider.writeField(result, fieldName, value, classDefiningField);
/* 234 */         seenFields.add(classDefiningField, fieldName);
/* 235 */       } else if (type != null) {
/* 236 */         implicitCollectionsForCurrentObject = writeValueToImplicitCollection(context, value, implicitCollectionsForCurrentObject, result, originalNodeName);
/*     */       }
/*     */ 
/* 239 */       reader.moveUp();
/*     */     }
/*     */ 
/* 242 */     return result;
/*     */   }
/*     */ 
/*     */   protected Object unmarshallField(UnmarshallingContext context, Object result, Class type, Field field) {
/* 246 */     return context.convertAnother(result, type, this.mapper.getLocalConverter(field.getDeclaringClass(), field.getName()));
/*     */   }
/*     */ 
/*     */   protected boolean shouldUnmarshalTransientFields() {
/* 250 */     return false;
/*     */   }
/*     */ 
/*     */   private Map writeValueToImplicitCollection(UnmarshallingContext context, Object value, Map implicitCollections, Object result, String itemFieldName)
/*     */   {
/* 255 */     String fieldName = this.mapper.getFieldNameForItemTypeAndName(context.getRequiredType(), Mapper.Null.class, itemFieldName);
/*     */ 
/* 258 */     if (fieldName != null) {
/* 259 */       if (implicitCollections == null) {
/* 260 */         implicitCollections = new HashMap();
/*     */       }
/* 262 */       Collection collection = (Collection)implicitCollections.get(fieldName);
/* 263 */       if (collection == null) {
/* 264 */         Class fieldType = this.mapper.defaultImplementationOf(this.reflectionProvider.getFieldType(result, fieldName, null));
/*     */ 
/* 266 */         if (!Collection.class.isAssignableFrom(fieldType)) {
/* 267 */           throw new ObjectAccessException("Field " + fieldName + " of " + result.getClass().getName() + " is configured for an implicit Collection, but field is of type " + fieldType.getName());
/*     */         }
/*     */ 
/* 274 */         if (this.pureJavaReflectionProvider == null) {
/* 275 */           this.pureJavaReflectionProvider = new PureJavaReflectionProvider();
/*     */         }
/* 277 */         collection = (Collection)this.pureJavaReflectionProvider.newInstance(fieldType);
/* 278 */         this.reflectionProvider.writeField(result, fieldName, collection, null);
/* 279 */         implicitCollections.put(fieldName, collection);
/*     */       }
/* 281 */       collection.add(value);
/*     */     } else {
/* 283 */       throw new ConversionException("Element " + itemFieldName + " of type " + value.getClass().getName() + " is not defined as field in type " + result.getClass().getName());
/*     */     }
/*     */ 
/* 290 */     return implicitCollections;
/*     */   }
/*     */ 
/*     */   private Class determineWhichClassDefinesField(HierarchicalStreamReader reader) {
/* 294 */     String attributeName = this.mapper.aliasForSystemAttribute("defined-in");
/* 295 */     String definedIn = attributeName == null ? null : reader.getAttribute(attributeName);
/* 296 */     return definedIn == null ? null : this.mapper.realClass(definedIn);
/*     */   }
/*     */ 
/*     */   protected Object instantiateNewInstance(HierarchicalStreamReader reader, UnmarshallingContext context) {
/* 300 */     String attributeName = this.mapper.aliasForSystemAttribute("resolves-to");
/* 301 */     String readResolveValue = attributeName == null ? null : reader.getAttribute(attributeName);
/* 302 */     Object currentObject = context.currentObject();
/* 303 */     if (currentObject != null)
/* 304 */       return currentObject;
/* 305 */     if (readResolveValue != null) {
/* 306 */       return this.reflectionProvider.newInstance(this.mapper.realClass(readResolveValue));
/*     */     }
/* 308 */     return this.reflectionProvider.newInstance(context.getRequiredType());
/*     */   }
/*     */ 
/*     */   private Class determineType(HierarchicalStreamReader reader, boolean validField, Object result, String fieldName, Class definedInCls)
/*     */   {
/* 331 */     String classAttribute = HierarchicalStreams.readClassAttribute(reader, this.mapper);
/* 332 */     if (classAttribute != null)
/* 333 */       return this.mapper.realClass(classAttribute);
/* 334 */     if (!validField) {
/* 335 */       Class itemType = this.mapper.getItemTypeForItemFieldName(result.getClass(), fieldName);
/* 336 */       if (itemType != null) {
/* 337 */         return itemType;
/*     */       }
/* 339 */       String originalNodeName = reader.getNodeName();
/* 340 */       if (definedInCls == null) {
/* 341 */         for (definedInCls = result.getClass(); definedInCls != null; definedInCls = definedInCls.getSuperclass()) {
/* 342 */           if (!this.mapper.shouldSerializeMember(definedInCls, originalNodeName)) {
/* 343 */             return null;
/*     */           }
/*     */         }
/*     */       }
/* 347 */       return this.mapper.realClass(originalNodeName);
/*     */     }
/*     */ 
/* 350 */     return this.mapper.defaultImplementationOf(this.reflectionProvider.getFieldType(result, fieldName, definedInCls));
/*     */   }
/*     */ 
/*     */   private Object readResolve()
/*     */   {
/* 355 */     this.serializationMethodInvoker = new SerializationMethodInvoker();
/* 356 */     return this;
/*     */   }
/*     */ 
/*     */   public static class DuplicateFieldException extends ConversionException {
/*     */     public DuplicateFieldException(String msg) {
/* 361 */       super();
/* 362 */       add("duplicate-field", msg);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class SeenFields
/*     */   {
/* 314 */     private Set seen = new HashSet();
/*     */ 
/*     */     private SeenFields() {  }
/*     */ 
/* 317 */     public void add(Class definedInCls, String fieldName) { String uniqueKey = fieldName;
/* 318 */       if (definedInCls != null) {
/* 319 */         uniqueKey = uniqueKey + " [" + definedInCls.getName() + "]";
/*     */       }
/* 321 */       if (this.seen.contains(uniqueKey)) {
/* 322 */         throw new AbstractReflectionConverter.DuplicateFieldException(uniqueKey);
/*     */       }
/* 324 */       this.seen.add(uniqueKey);
/*     */     }
/*     */ 
/*     */     SeenFields(AbstractReflectionConverter.1 x0)
/*     */     {
/* 312 */       this();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.reflection.AbstractReflectionConverter
 * JD-Core Version:    0.6.0
 */