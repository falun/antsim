package com.thoughtworks.xstream.converters.reflection;

import java.util.Map;

public abstract interface FieldKeySorter
{
  public abstract Map sort(Class paramClass, Map paramMap);
}

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.reflection.FieldKeySorter
 * JD-Core Version:    0.6.0
 */