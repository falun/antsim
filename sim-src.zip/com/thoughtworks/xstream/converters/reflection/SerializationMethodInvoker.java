/*     */ package com.thoughtworks.xstream.converters.reflection;
/*     */ 
/*     */ import com.thoughtworks.xstream.converters.ConversionException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class SerializationMethodInvoker
/*     */ {
/*  31 */   private Map cache = Collections.synchronizedMap(new HashMap());
/*  32 */   private static final Object NO_METHOD = new Object();
/*  33 */   private static final Object[] EMPTY_ARGS = new Object[0];
/*     */ 
/*     */   public Object callReadResolve(Object result)
/*     */   {
/*  39 */     if (result == null) {
/*  40 */       return null;
/*     */     }
/*  42 */     Method readResolveMethod = getMethod(result.getClass(), "readResolve", null, true);
/*  43 */     if (readResolveMethod != null) {
/*     */       try {
/*  45 */         return readResolveMethod.invoke(result, EMPTY_ARGS);
/*     */       } catch (IllegalAccessException e) {
/*  47 */         throw new ObjectAccessException("Could not call " + result.getClass().getName() + ".readResolve()", e);
/*     */       } catch (InvocationTargetException e) {
/*  49 */         throw new ObjectAccessException("Could not call " + result.getClass().getName() + ".readResolve()", e.getTargetException());
/*     */       }
/*     */     }
/*  52 */     return result;
/*     */   }
/*     */ 
/*     */   public Object callWriteReplace(Object object)
/*     */   {
/*  58 */     if (object == null) {
/*  59 */       return null;
/*     */     }
/*  61 */     Method writeReplaceMethod = getMethod(object.getClass(), "writeReplace", null, true);
/*  62 */     if (writeReplaceMethod != null) {
/*     */       try {
/*  64 */         Object[] EMPTY_ARGS = new Object[0];
/*  65 */         return writeReplaceMethod.invoke(object, EMPTY_ARGS);
/*     */       } catch (IllegalAccessException e) {
/*  67 */         throw new ObjectAccessException("Could not call " + object.getClass().getName() + ".writeReplace()", e);
/*     */       } catch (InvocationTargetException e) {
/*  69 */         throw new ObjectAccessException("Could not call " + object.getClass().getName() + ".writeReplace()", e.getTargetException());
/*     */       }
/*     */     }
/*  72 */     return object;
/*     */   }
/*     */ 
/*     */   public boolean supportsReadObject(Class type, boolean includeBaseClasses)
/*     */   {
/*  78 */     return getMethod(type, "readObject", new Class[] { ObjectInputStream.class }, includeBaseClasses) != null;
/*     */   }
/*     */ 
/*     */   public void callReadObject(Class type, Object object, ObjectInputStream stream) {
/*     */     try {
/*  83 */       Method readObjectMethod = getMethod(type, "readObject", new Class[] { ObjectInputStream.class }, false);
/*  84 */       readObjectMethod.invoke(object, new Object[] { stream });
/*     */     } catch (IllegalAccessException e) {
/*  86 */       throw new ConversionException("Could not call " + object.getClass().getName() + ".readObject()", e);
/*     */     } catch (InvocationTargetException e) {
/*  88 */       throw new ConversionException("Could not call " + object.getClass().getName() + ".readObject()", e.getTargetException());
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean supportsWriteObject(Class type, boolean includeBaseClasses) {
/*  93 */     return getMethod(type, "writeObject", new Class[] { ObjectOutputStream.class }, includeBaseClasses) != null;
/*     */   }
/*     */ 
/*     */   public void callWriteObject(Class type, Object instance, ObjectOutputStream stream) {
/*     */     try {
/*  98 */       Method readObjectMethod = getMethod(type, "writeObject", new Class[] { ObjectOutputStream.class }, false);
/*  99 */       readObjectMethod.invoke(instance, new Object[] { stream });
/*     */     } catch (IllegalAccessException e) {
/* 101 */       throw new ConversionException("Could not call " + instance.getClass().getName() + ".writeObject()", e);
/*     */     } catch (InvocationTargetException e) {
/* 103 */       throw new ConversionException("Could not call " + instance.getClass().getName() + ".writeObject()", e.getTargetException());
/*     */     }
/*     */   }
/*     */ 
/*     */   private Method getMethod(Class type, String name, Class[] parameterTypes, boolean includeBaseclasses)
/*     */   {
/* 109 */     String typeName = type.getName();
/* 110 */     StringBuffer sb = new StringBuffer(typeName.length() + name.length() + 7);
/* 111 */     sb.append(typeName).append('.').append(name).append('.').append(includeBaseclasses).toString();
/*     */ 
/* 118 */     String key = sb.toString();
/* 119 */     Object resultOb = this.cache.get(key);
/*     */ 
/* 121 */     if (resultOb != null) {
/* 122 */       return resultOb == NO_METHOD ? null : (Method)resultOb;
/*     */     }
/* 124 */     if (includeBaseclasses) {
/* 125 */       while (type != null) {
/*     */         try {
/* 127 */           Method result = type.getDeclaredMethod(name, parameterTypes);
/* 128 */           result.setAccessible(true);
/* 129 */           this.cache.put(key, result);
/* 130 */           return result;
/*     */         } catch (NoSuchMethodException e) {
/* 132 */           type = type.getSuperclass();
/*     */         }
/*     */       }
/* 135 */       this.cache.put(key, NO_METHOD);
/* 136 */       return null;
/*     */     }
/*     */     try {
/* 139 */       Method result = type.getDeclaredMethod(name, parameterTypes);
/* 140 */       result.setAccessible(true);
/* 141 */       this.cache.put(key, result);
/* 142 */       return result;
/*     */     } catch (NoSuchMethodException e) {
/* 144 */       this.cache.put(key, NO_METHOD);
/* 145 */     }return null;
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.reflection.SerializationMethodInvoker
 * JD-Core Version:    0.6.0
 */