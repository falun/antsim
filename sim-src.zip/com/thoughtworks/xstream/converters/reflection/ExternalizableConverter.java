/*     */ package com.thoughtworks.xstream.converters.reflection;
/*     */ 
/*     */ import com.thoughtworks.xstream.converters.ConversionException;
/*     */ import com.thoughtworks.xstream.converters.Converter;
/*     */ import com.thoughtworks.xstream.converters.MarshallingContext;
/*     */ import com.thoughtworks.xstream.converters.UnmarshallingContext;
/*     */ import com.thoughtworks.xstream.core.util.CustomObjectInputStream;
/*     */ import com.thoughtworks.xstream.core.util.CustomObjectInputStream.StreamCallback;
/*     */ import com.thoughtworks.xstream.core.util.CustomObjectOutputStream;
/*     */ import com.thoughtworks.xstream.core.util.CustomObjectOutputStream.StreamCallback;
/*     */ import com.thoughtworks.xstream.core.util.HierarchicalStreams;
/*     */ import com.thoughtworks.xstream.io.ExtendedHierarchicalStreamWriterHelper;
/*     */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*     */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*     */ import com.thoughtworks.xstream.mapper.Mapper;
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.NotActiveException;
/*     */ import java.io.ObjectInputValidation;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class ExternalizableConverter
/*     */   implements Converter
/*     */ {
/*     */   private Mapper mapper;
/*     */ 
/*     */   public ExternalizableConverter(Mapper mapper)
/*     */   {
/*  43 */     this.mapper = mapper;
/*     */   }
/*     */ 
/*     */   public boolean canConvert(Class type) {
/*  47 */     return Externalizable.class.isAssignableFrom(type);
/*     */   }
/*     */ 
/*     */   public void marshal(Object source, HierarchicalStreamWriter writer, MarshallingContext context) {
/*     */     try {
/*  52 */       Externalizable externalizable = (Externalizable)source;
/*  53 */       CustomObjectOutputStream.StreamCallback callback = new CustomObjectOutputStream.StreamCallback(writer, context) { private final HierarchicalStreamWriter val$writer;
/*     */         private final MarshallingContext val$context;
/*     */ 
/*  55 */         public void writeToStream(Object object) { if (object == null) {
/*  56 */             this.val$writer.startNode("null");
/*  57 */             this.val$writer.endNode();
/*     */           } else {
/*  59 */             ExtendedHierarchicalStreamWriterHelper.startNode(this.val$writer, ExternalizableConverter.this.mapper.serializedClass(object.getClass()), object.getClass());
/*  60 */             this.val$context.convertAnother(object);
/*  61 */             this.val$writer.endNode();
/*     */           } }
/*     */ 
/*     */         public void writeFieldsToStream(Map fields)
/*     */         {
/*  66 */           throw new UnsupportedOperationException();
/*     */         }
/*     */ 
/*     */         public void defaultWriteObject() {
/*  70 */           throw new UnsupportedOperationException();
/*     */         }
/*     */ 
/*     */         public void flush() {
/*  74 */           this.val$writer.flush();
/*     */         }
/*     */ 
/*     */         public void close() {
/*  78 */           throw new UnsupportedOperationException("Objects are not allowed to call ObjectOutput.close() from writeExternal()");
/*     */         }
/*     */       };
/*  81 */       CustomObjectOutputStream objectOutput = CustomObjectOutputStream.getInstance(context, callback);
/*  82 */       externalizable.writeExternal(objectOutput);
/*  83 */       objectOutput.popCallback();
/*     */     } catch (IOException e) {
/*  85 */       throw new ConversionException("Cannot serialize " + source.getClass().getName() + " using Externalization", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext context) {
/*  90 */     Class type = context.getRequiredType();
/*     */     try {
/*  92 */       Externalizable externalizable = (Externalizable)type.newInstance();
/*  93 */       CustomObjectInputStream.StreamCallback callback = new CustomObjectInputStream.StreamCallback(reader, context, externalizable) { private final HierarchicalStreamReader val$reader;
/*     */         private final UnmarshallingContext val$context;
/*     */         private final Externalizable val$externalizable;
/*     */ 
/*  95 */         public Object readFromStream() { this.val$reader.moveDown();
/*  96 */           Class type = HierarchicalStreams.readClassType(this.val$reader, ExternalizableConverter.this.mapper);
/*  97 */           Object streamItem = this.val$context.convertAnother(this.val$externalizable, type);
/*  98 */           this.val$reader.moveUp();
/*  99 */           return streamItem; }
/*     */ 
/*     */         public Map readFieldsFromStream()
/*     */         {
/* 103 */           throw new UnsupportedOperationException();
/*     */         }
/*     */ 
/*     */         public void defaultReadObject() {
/* 107 */           throw new UnsupportedOperationException();
/*     */         }
/*     */ 
/*     */         public void registerValidation(ObjectInputValidation validation, int priority) throws NotActiveException {
/* 111 */           throw new NotActiveException("stream inactive");
/*     */         }
/*     */ 
/*     */         public void close() {
/* 115 */           throw new UnsupportedOperationException("Objects are not allowed to call ObjectInput.close() from readExternal()");
/*     */         }
/*     */       };
/* 118 */       CustomObjectInputStream objectInput = CustomObjectInputStream.getInstance(context, callback);
/* 119 */       externalizable.readExternal(objectInput);
/* 120 */       objectInput.popCallback();
/* 121 */       return externalizable;
/*     */     } catch (InstantiationException e) {
/* 123 */       throw new ConversionException("Cannot construct " + type.getClass(), e);
/*     */     } catch (IllegalAccessException e) {
/* 125 */       throw new ConversionException("Cannot construct " + type.getClass(), e);
/*     */     } catch (IOException e) {
/* 127 */       throw new ConversionException("Cannot externalize " + type.getClass(), e); } catch (ClassNotFoundException e) {
/*     */     }
/* 129 */     throw new ConversionException("Cannot externalize " + type.getClass(), e);
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.reflection.ExternalizableConverter
 * JD-Core Version:    0.6.0
 */