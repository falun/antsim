/*     */ package com.thoughtworks.xstream.converters.reflection;
/*     */ 
/*     */ import com.thoughtworks.xstream.core.JVM;
/*     */ import com.thoughtworks.xstream.core.util.OrderRetainingMap;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ 
/*     */ public class FieldDictionary
/*     */ {
/*     */   private transient Map keyedByFieldNameCache;
/*     */   private transient Map keyedByFieldKeyCache;
/*     */   private final FieldKeySorter sorter;
/*     */ 
/*     */   public FieldDictionary()
/*     */   {
/*  42 */     this(new ImmutableFieldKeySorter());
/*     */   }
/*     */ 
/*     */   public FieldDictionary(FieldKeySorter sorter) {
/*  46 */     this.sorter = sorter;
/*  47 */     init();
/*     */   }
/*     */ 
/*     */   private void init() {
/*  51 */     this.keyedByFieldNameCache = new WeakHashMap();
/*  52 */     this.keyedByFieldKeyCache = new WeakHashMap();
/*  53 */     this.keyedByFieldNameCache.put(Object.class, Collections.EMPTY_MAP);
/*  54 */     this.keyedByFieldKeyCache.put(Object.class, Collections.EMPTY_MAP);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public Iterator serializableFieldsFor(Class cls)
/*     */   {
/*  65 */     return fieldsFor(cls);
/*     */   }
/*     */ 
/*     */   public Iterator fieldsFor(Class cls)
/*     */   {
/*  75 */     return buildMap(cls, true).values().iterator();
/*     */   }
/*     */ 
/*     */   public Field field(Class cls, String name, Class definedIn)
/*     */   {
/*  90 */     Map fields = buildMap(cls, definedIn != null);
/*  91 */     Field field = (Field)fields.get(definedIn != null ? new FieldKey(name, definedIn, 0) : name);
/*     */ 
/*  93 */     if (field == null) {
/*  94 */       throw new ObjectAccessException("No such field " + cls.getName() + "." + name);
/*     */     }
/*  96 */     return field;
/*     */   }
/*     */ 
/*     */   private Map buildMap(Class type, boolean tupleKeyed)
/*     */   {
/* 101 */     Class cls = type;
/*     */     Map lastKeyedByFieldName;
/*     */     Map lastKeyedByFieldKey;
/*     */     Iterator iter;
/* 102 */     synchronized (this) {
/* 103 */       if (!this.keyedByFieldNameCache.containsKey(type)) {
/* 104 */         List superClasses = new ArrayList();
/* 105 */         while (!Object.class.equals(cls)) {
/* 106 */           superClasses.add(0, cls);
/* 107 */           cls = cls.getSuperclass();
/*     */         }
/* 109 */         lastKeyedByFieldName = Collections.EMPTY_MAP;
/* 110 */         lastKeyedByFieldKey = Collections.EMPTY_MAP;
/* 111 */         for (iter = superClasses.iterator(); iter.hasNext(); ) {
/* 112 */           cls = (Class)iter.next();
/* 113 */           if (!this.keyedByFieldNameCache.containsKey(cls)) {
/* 114 */             Map keyedByFieldName = new HashMap(lastKeyedByFieldName);
/* 115 */             Map keyedByFieldKey = new OrderRetainingMap(lastKeyedByFieldKey);
/* 116 */             Field[] fields = cls.getDeclaredFields();
/*     */             int i;
/* 117 */             if (JVM.reverseFieldDefinition()) {
/* 118 */               for (i = fields.length >> 1; i-- > 0; ) {
/* 119 */                 int idx = fields.length - i - 1;
/* 120 */                 Field field = fields[i];
/* 121 */                 fields[i] = fields[idx];
/* 122 */                 fields[idx] = field;
/*     */               }
/*     */             }
/* 125 */             for (int i = 0; i < fields.length; i++) {
/* 126 */               Field field = fields[i];
/* 127 */               FieldKey fieldKey = new FieldKey(field.getName(), field.getDeclaringClass(), i);
/*     */ 
/* 129 */               field.setAccessible(true);
/* 130 */               Field existent = (Field)keyedByFieldName.get(field.getName());
/* 131 */               if ((existent == null) || ((existent.getModifiers() & 0x8) != 0) || ((existent != null) && ((field.getModifiers() & 0x8) == 0)))
/*     */               {
/* 136 */                 keyedByFieldName.put(field.getName(), field);
/*     */               }
/* 138 */               keyedByFieldKey.put(fieldKey, field);
/*     */             }
/* 140 */             this.keyedByFieldNameCache.put(cls, keyedByFieldName);
/* 141 */             this.keyedByFieldKeyCache.put(cls, this.sorter.sort(type, keyedByFieldKey));
/*     */           }
/* 143 */           lastKeyedByFieldName = (Map)this.keyedByFieldNameCache.get(cls);
/* 144 */           lastKeyedByFieldKey = (Map)this.keyedByFieldKeyCache.get(cls);
/*     */         }
/*     */       }
/*     */     }
/* 148 */     return (Map)(tupleKeyed ? this.keyedByFieldKeyCache.get(type) : this.keyedByFieldNameCache.get(type));
/*     */   }
/*     */ 
/*     */   protected Object readResolve()
/*     */   {
/* 153 */     init();
/* 154 */     return this;
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.reflection.FieldDictionary
 * JD-Core Version:    0.6.0
 */