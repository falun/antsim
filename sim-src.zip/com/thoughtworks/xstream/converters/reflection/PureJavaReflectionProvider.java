/*     */ package com.thoughtworks.xstream.converters.reflection;
/*     */ 
/*     */ import com.thoughtworks.xstream.core.JVM;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectStreamClass;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class PureJavaReflectionProvider
/*     */   implements ReflectionProvider
/*     */ {
/*  46 */   private transient Map serializedDataCache = Collections.synchronizedMap(new HashMap());
/*     */   protected FieldDictionary fieldDictionary;
/*     */ 
/*     */   public PureJavaReflectionProvider()
/*     */   {
/*  50 */     this(new FieldDictionary(new ImmutableFieldKeySorter()));
/*     */   }
/*     */ 
/*     */   public PureJavaReflectionProvider(FieldDictionary fieldDictionary) {
/*  54 */     this.fieldDictionary = fieldDictionary;
/*     */   }
/*     */ 
/*     */   public Object newInstance(Class type) {
/*     */     try {
/*  59 */       Constructor[] constructors = type.getDeclaredConstructors();
/*  60 */       for (int i = 0; i < constructors.length; i++) {
/*  61 */         if (constructors[i].getParameterTypes().length == 0) {
/*  62 */           if (!Modifier.isPublic(constructors[i].getModifiers())) {
/*  63 */             constructors[i].setAccessible(true);
/*     */           }
/*  65 */           return constructors[i].newInstance(new Object[0]);
/*     */         }
/*     */       }
/*  68 */       if (Serializable.class.isAssignableFrom(type)) {
/*  69 */         return instantiateUsingSerialization(type);
/*     */       }
/*  71 */       throw new ObjectAccessException("Cannot construct " + type.getName() + " as it does not have a no-args constructor");
/*     */     }
/*     */     catch (InstantiationException e)
/*     */     {
/*  75 */       throw new ObjectAccessException("Cannot construct " + type.getName(), e);
/*     */     } catch (IllegalAccessException e) {
/*  77 */       throw new ObjectAccessException("Cannot construct " + type.getName(), e);
/*     */     } catch (InvocationTargetException e) {
/*  79 */       if ((e.getTargetException() instanceof RuntimeException))
/*  80 */         throw ((RuntimeException)e.getTargetException());
/*  81 */       if ((e.getTargetException() instanceof Error))
/*  82 */         throw ((Error)e.getTargetException());
/*     */     }
/*  84 */     throw new ObjectAccessException("Constructor for " + type.getName() + " threw an exception", e.getTargetException());
/*     */   }
/*     */ 
/*     */   private Object instantiateUsingSerialization(Class type)
/*     */   {
/*     */     try
/*     */     {
/*     */       byte[] data;
/*     */       byte[] data;
/*  92 */       if (this.serializedDataCache.containsKey(type)) {
/*  93 */         data = (byte[])(byte[])this.serializedDataCache.get(type);
/*     */       } else {
/*  95 */         ByteArrayOutputStream bytes = new ByteArrayOutputStream();
/*  96 */         DataOutputStream stream = new DataOutputStream(bytes);
/*  97 */         stream.writeShort(-21267);
/*  98 */         stream.writeShort(5);
/*  99 */         stream.writeByte(115);
/* 100 */         stream.writeByte(114);
/* 101 */         stream.writeUTF(type.getName());
/* 102 */         stream.writeLong(ObjectStreamClass.lookup(type).getSerialVersionUID());
/* 103 */         stream.writeByte(2);
/* 104 */         stream.writeShort(0);
/* 105 */         stream.writeByte(120);
/* 106 */         stream.writeByte(112);
/* 107 */         data = bytes.toByteArray();
/* 108 */         this.serializedDataCache.put(type, data);
/*     */       }
/*     */ 
/* 111 */       ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(data));
/* 112 */       return in.readObject();
/*     */     } catch (IOException e) {
/* 114 */       throw new ObjectAccessException("Cannot create " + type.getName() + " by JDK serialization", e); } catch (ClassNotFoundException e) {
/*     */     }
/* 116 */     throw new ObjectAccessException("Cannot find class " + e.getMessage());
/*     */   }
/*     */ 
/*     */   public void visitSerializableFields(Object object, ReflectionProvider.Visitor visitor)
/*     */   {
/* 121 */     for (Iterator iterator = this.fieldDictionary.fieldsFor(object.getClass()); iterator.hasNext(); ) {
/* 122 */       Field field = (Field)iterator.next();
/* 123 */       if (!fieldModifiersSupported(field)) {
/*     */         continue;
/*     */       }
/* 126 */       validateFieldAccess(field);
/*     */       try {
/* 128 */         Object value = field.get(object);
/* 129 */         visitor.visit(field.getName(), field.getType(), field.getDeclaringClass(), value);
/*     */       } catch (IllegalArgumentException e) {
/* 131 */         throw new ObjectAccessException("Could not get field " + field.getClass() + "." + field.getName(), e);
/*     */       } catch (IllegalAccessException e) {
/* 133 */         throw new ObjectAccessException("Could not get field " + field.getClass() + "." + field.getName(), e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void writeField(Object object, String fieldName, Object value, Class definedIn) {
/* 139 */     Field field = this.fieldDictionary.field(object.getClass(), fieldName, definedIn);
/* 140 */     validateFieldAccess(field);
/*     */     try {
/* 142 */       field.set(object, value);
/*     */     } catch (IllegalArgumentException e) {
/* 144 */       throw new ObjectAccessException("Could not set field " + object.getClass() + "." + field.getName(), e);
/*     */     } catch (IllegalAccessException e) {
/* 146 */       throw new ObjectAccessException("Could not set field " + object.getClass() + "." + field.getName(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Class getFieldType(Object object, String fieldName, Class definedIn) {
/* 151 */     return this.fieldDictionary.field(object.getClass(), fieldName, definedIn).getType();
/*     */   }
/*     */ 
/*     */   public boolean fieldDefinedInClass(String fieldName, Class type) {
/*     */     try {
/* 156 */       Field field = this.fieldDictionary.field(type, fieldName, null);
/* 157 */       return (fieldModifiersSupported(field)) || (Modifier.isTransient(field.getModifiers())); } catch (ObjectAccessException e) {
/*     */     }
/* 159 */     return false;
/*     */   }
/*     */ 
/*     */   protected boolean fieldModifiersSupported(Field field)
/*     */   {
/* 164 */     return (!Modifier.isStatic(field.getModifiers())) && (!Modifier.isTransient(field.getModifiers()));
/*     */   }
/*     */ 
/*     */   protected void validateFieldAccess(Field field)
/*     */   {
/* 169 */     if (Modifier.isFinal(field.getModifiers()))
/* 170 */       if (JVM.is15())
/* 171 */         field.setAccessible(true);
/*     */       else
/* 173 */         throw new ObjectAccessException("Invalid final field " + field.getDeclaringClass().getName() + "." + field.getName());
/*     */   }
/*     */ 
/*     */   public Field getField(Class definedIn, String fieldName)
/*     */   {
/* 180 */     return this.fieldDictionary.field(definedIn, fieldName, null);
/*     */   }
/*     */ 
/*     */   public void setFieldDictionary(FieldDictionary dictionary) {
/* 184 */     this.fieldDictionary = dictionary;
/*     */   }
/*     */ 
/*     */   protected Object readResolve() {
/* 188 */     this.serializedDataCache = Collections.synchronizedMap(new HashMap());
/* 189 */     return this;
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.reflection.PureJavaReflectionProvider
 * JD-Core Version:    0.6.0
 */