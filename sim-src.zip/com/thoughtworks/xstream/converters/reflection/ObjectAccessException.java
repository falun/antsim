/*    */ package com.thoughtworks.xstream.converters.reflection;
/*    */ 
/*    */ import com.thoughtworks.xstream.XStreamException;
/*    */ 
/*    */ public class ObjectAccessException extends XStreamException
/*    */ {
/*    */   public ObjectAccessException(String message)
/*    */   {
/* 18 */     super(message);
/*    */   }
/*    */ 
/*    */   public ObjectAccessException(String message, Throwable cause) {
/* 22 */     super(message, cause);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.reflection.ObjectAccessException
 * JD-Core Version:    0.6.0
 */