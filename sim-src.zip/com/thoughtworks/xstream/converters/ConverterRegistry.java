package com.thoughtworks.xstream.converters;

public abstract interface ConverterRegistry
{
  public abstract void registerConverter(Converter paramConverter, int paramInt);
}

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.ConverterRegistry
 * JD-Core Version:    0.6.0
 */