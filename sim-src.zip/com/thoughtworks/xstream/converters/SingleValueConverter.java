package com.thoughtworks.xstream.converters;

public abstract interface SingleValueConverter extends ConverterMatcher
{
  public abstract String toString(Object paramObject);

  public abstract Object fromString(String paramString);
}

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.SingleValueConverter
 * JD-Core Version:    0.6.0
 */