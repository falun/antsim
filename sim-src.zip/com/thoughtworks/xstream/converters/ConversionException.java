/*    */ package com.thoughtworks.xstream.converters;
/*    */ 
/*    */ import com.thoughtworks.xstream.XStreamException;
/*    */ import com.thoughtworks.xstream.core.util.OrderRetainingMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class ConversionException extends XStreamException
/*    */   implements ErrorWriter
/*    */ {
/*    */   private static final String SEPARATOR = "\n-------------------------------";
/* 35 */   private Map stuff = new OrderRetainingMap();
/*    */ 
/*    */   public ConversionException(String msg, Throwable cause) {
/* 38 */     super(msg, cause);
/* 39 */     if (msg != null) {
/* 40 */       add("message", msg);
/*    */     }
/* 42 */     if (cause != null) {
/* 43 */       add("cause-exception", cause.getClass().getName());
/* 44 */       add("cause-message", (cause instanceof ConversionException) ? ((ConversionException)cause).getShortMessage() : cause.getMessage());
/*    */     }
/*    */   }
/*    */ 
/*    */   public ConversionException(String msg) {
/* 49 */     super(msg);
/*    */   }
/*    */ 
/*    */   public ConversionException(Throwable cause) {
/* 53 */     this(cause.getMessage(), cause);
/*    */   }
/*    */ 
/*    */   public String get(String errorKey) {
/* 57 */     return (String)this.stuff.get(errorKey);
/*    */   }
/*    */ 
/*    */   public void add(String name, String information) {
/* 61 */     this.stuff.put(name, information);
/*    */   }
/*    */ 
/*    */   public Iterator keys() {
/* 65 */     return this.stuff.keySet().iterator();
/*    */   }
/*    */ 
/*    */   public String getMessage() {
/* 69 */     StringBuffer result = new StringBuffer();
/* 70 */     if (super.getMessage() != null) {
/* 71 */       result.append(super.getMessage());
/*    */     }
/* 73 */     if (!result.toString().endsWith("\n-------------------------------")) {
/* 74 */       result.append("\n---- Debugging information ----");
/*    */     }
/* 76 */     for (Iterator iterator = keys(); iterator.hasNext(); ) {
/* 77 */       String k = (String)iterator.next();
/* 78 */       String v = get(k);
/* 79 */       result.append('\n').append(k);
/* 80 */       result.append("                    ".substring(Math.min(20, k.length())));
/* 81 */       result.append(": ").append(v);
/*    */     }
/* 83 */     result.append("\n-------------------------------");
/* 84 */     return result.toString();
/*    */   }
/*    */ 
/*    */   public String getShortMessage() {
/* 88 */     return super.getMessage();
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.ConversionException
 * JD-Core Version:    0.6.0
 */