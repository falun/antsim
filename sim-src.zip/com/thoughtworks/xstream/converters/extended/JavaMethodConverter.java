/*     */ package com.thoughtworks.xstream.converters.extended;
/*     */ 
/*     */ import com.thoughtworks.xstream.converters.ConversionException;
/*     */ import com.thoughtworks.xstream.converters.Converter;
/*     */ import com.thoughtworks.xstream.converters.MarshallingContext;
/*     */ import com.thoughtworks.xstream.converters.SingleValueConverter;
/*     */ import com.thoughtworks.xstream.converters.UnmarshallingContext;
/*     */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*     */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class JavaMethodConverter
/*     */   implements Converter
/*     */ {
/*     */   private final SingleValueConverter javaClassConverter;
/*     */ 
/*     */   /** @deprecated */
/*     */   public JavaMethodConverter()
/*     */   {
/*  41 */     this(JavaMethodConverter.class.getClassLoader());
/*     */   }
/*     */ 
/*     */   public JavaMethodConverter(ClassLoader classLoader) {
/*  45 */     this.javaClassConverter = new JavaClassConverter(classLoader);
/*     */   }
/*     */ 
/*     */   public boolean canConvert(Class type) {
/*  49 */     return (type.equals(Method.class)) || (type.equals(Constructor.class));
/*     */   }
/*     */ 
/*     */   public void marshal(Object source, HierarchicalStreamWriter writer, MarshallingContext context) {
/*  53 */     if ((source instanceof Method)) {
/*  54 */       Method method = (Method)source;
/*  55 */       String declaringClassName = this.javaClassConverter.toString(method.getDeclaringClass());
/*  56 */       marshalMethod(writer, declaringClassName, method.getName(), method.getParameterTypes());
/*     */     } else {
/*  58 */       Constructor method = (Constructor)source;
/*  59 */       String declaringClassName = this.javaClassConverter.toString(method.getDeclaringClass());
/*  60 */       marshalMethod(writer, declaringClassName, null, method.getParameterTypes());
/*     */     }
/*     */   }
/*     */ 
/*     */   private void marshalMethod(HierarchicalStreamWriter writer, String declaringClassName, String methodName, Class[] parameterTypes)
/*     */   {
/*  66 */     writer.startNode("class");
/*  67 */     writer.setValue(declaringClassName);
/*  68 */     writer.endNode();
/*     */ 
/*  70 */     if (methodName != null)
/*     */     {
/*  72 */       writer.startNode("name");
/*  73 */       writer.setValue(methodName);
/*  74 */       writer.endNode();
/*     */     }
/*     */ 
/*  77 */     writer.startNode("parameter-types");
/*  78 */     for (int i = 0; i < parameterTypes.length; i++) {
/*  79 */       writer.startNode("class");
/*  80 */       writer.setValue(this.javaClassConverter.toString(parameterTypes[i]));
/*  81 */       writer.endNode();
/*     */     }
/*  83 */     writer.endNode();
/*     */   }
/*     */ 
/*     */   public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext context) {
/*     */     try {
/*  88 */       boolean isMethodNotConstructor = context.getRequiredType().equals(Method.class);
/*     */ 
/*  90 */       reader.moveDown();
/*  91 */       String declaringClassName = reader.getValue();
/*  92 */       Class declaringClass = (Class)this.javaClassConverter.fromString(declaringClassName);
/*  93 */       reader.moveUp();
/*     */ 
/*  95 */       String methodName = null;
/*  96 */       if (isMethodNotConstructor) {
/*  97 */         reader.moveDown();
/*  98 */         methodName = reader.getValue();
/*  99 */         reader.moveUp();
/*     */       }
/*     */ 
/* 102 */       reader.moveDown();
/* 103 */       List parameterTypeList = new ArrayList();
/* 104 */       while (reader.hasMoreChildren()) {
/* 105 */         reader.moveDown();
/* 106 */         String parameterTypeName = reader.getValue();
/* 107 */         parameterTypeList.add(this.javaClassConverter.fromString(parameterTypeName));
/* 108 */         reader.moveUp();
/*     */       }
/* 110 */       Class[] parameterTypes = (Class[])(Class[])parameterTypeList.toArray(new Class[parameterTypeList.size()]);
/* 111 */       reader.moveUp();
/*     */ 
/* 113 */       if (isMethodNotConstructor) {
/* 114 */         return declaringClass.getDeclaredMethod(methodName, parameterTypes);
/*     */       }
/* 116 */       return declaringClass.getDeclaredConstructor(parameterTypes);
/*     */     } catch (NoSuchMethodException e) {
/*     */     }
/* 119 */     throw new ConversionException(e);
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.extended.JavaMethodConverter
 * JD-Core Version:    0.6.0
 */