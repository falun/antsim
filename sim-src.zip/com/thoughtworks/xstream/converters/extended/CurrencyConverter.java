/*    */ package com.thoughtworks.xstream.converters.extended;
/*    */ 
/*    */ import com.thoughtworks.xstream.converters.basic.AbstractSingleValueConverter;
/*    */ import java.util.Currency;
/*    */ 
/*    */ public class CurrencyConverter extends AbstractSingleValueConverter
/*    */ {
/*    */   public boolean canConvert(Class type)
/*    */   {
/* 28 */     return type.equals(Currency.class);
/*    */   }
/*    */ 
/*    */   public Object fromString(String str) {
/* 32 */     return Currency.getInstance(str);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.extended.CurrencyConverter
 * JD-Core Version:    0.6.0
 */