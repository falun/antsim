/*    */ package com.thoughtworks.xstream.converters.extended;
/*    */ 
/*    */ import com.thoughtworks.xstream.converters.Converter;
/*    */ import com.thoughtworks.xstream.converters.MarshallingContext;
/*    */ import com.thoughtworks.xstream.converters.UnmarshallingContext;
/*    */ import com.thoughtworks.xstream.converters.basic.ByteConverter;
/*    */ import com.thoughtworks.xstream.core.util.Base64Encoder;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ 
/*    */ public class EncodedByteArrayConverter
/*    */   implements Converter
/*    */ {
/* 33 */   private static final Base64Encoder base64 = new Base64Encoder();
/* 34 */   private static final ByteConverter byteConverter = new ByteConverter();
/*    */ 
/*    */   public boolean canConvert(Class type) {
/* 37 */     return (type.isArray()) && (type.getComponentType().equals(Byte.TYPE));
/*    */   }
/*    */ 
/*    */   public void marshal(Object source, HierarchicalStreamWriter writer, MarshallingContext context) {
/* 41 */     writer.setValue(base64.encode((byte[])(byte[])source));
/*    */   }
/*    */ 
/*    */   public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext context) {
/* 45 */     String data = reader.getValue();
/* 46 */     if (!reader.hasMoreChildren()) {
/* 47 */       return base64.decode(data);
/*    */     }
/*    */ 
/* 50 */     return unmarshalIndividualByteElements(reader, context);
/*    */   }
/*    */ 
/*    */   private Object unmarshalIndividualByteElements(HierarchicalStreamReader reader, UnmarshallingContext context)
/*    */   {
/* 55 */     List bytes = new ArrayList();
/* 56 */     boolean firstIteration = true;
/* 57 */     while ((firstIteration) || (reader.hasMoreChildren())) {
/* 58 */       reader.moveDown();
/*    */ 
/* 60 */       bytes.add(byteConverter.fromString(reader.getValue()));
/* 61 */       reader.moveUp();
/* 62 */       firstIteration = false;
/*    */     }
/*    */ 
/* 65 */     byte[] result = new byte[bytes.size()];
/* 66 */     int i = 0;
/* 67 */     for (Iterator iterator = bytes.iterator(); iterator.hasNext(); ) {
/* 68 */       Byte b = (Byte)iterator.next();
/* 69 */       result[i] = b.byteValue();
/* 70 */       i++;
/*    */     }
/* 72 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.extended.EncodedByteArrayConverter
 * JD-Core Version:    0.6.0
 */