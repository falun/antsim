/*    */ package com.thoughtworks.xstream.converters.extended;
/*    */ 
/*    */ import com.thoughtworks.xstream.converters.basic.AbstractSingleValueConverter;
/*    */ import java.sql.Date;
/*    */ 
/*    */ public class SqlDateConverter extends AbstractSingleValueConverter
/*    */ {
/*    */   public boolean canConvert(Class type)
/*    */   {
/* 26 */     return type.equals(Date.class);
/*    */   }
/*    */ 
/*    */   public Object fromString(String str) {
/* 30 */     return Date.valueOf(str);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.extended.SqlDateConverter
 * JD-Core Version:    0.6.0
 */