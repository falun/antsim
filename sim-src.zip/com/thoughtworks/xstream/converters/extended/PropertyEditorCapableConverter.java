/*    */ package com.thoughtworks.xstream.converters.extended;
/*    */ 
/*    */ import com.thoughtworks.xstream.converters.SingleValueConverter;
/*    */ import com.thoughtworks.xstream.core.util.ThreadSafePropertyEditor;
/*    */ 
/*    */ public class PropertyEditorCapableConverter
/*    */   implements SingleValueConverter
/*    */ {
/*    */   private final ThreadSafePropertyEditor editor;
/*    */   private final Class type;
/*    */ 
/*    */   public PropertyEditorCapableConverter(Class propertyEditorType, Class type)
/*    */   {
/* 33 */     this.type = type;
/* 34 */     this.editor = new ThreadSafePropertyEditor(propertyEditorType, 2, 5);
/*    */   }
/*    */ 
/*    */   public boolean canConvert(Class type) {
/* 38 */     return this.type == type;
/*    */   }
/*    */ 
/*    */   public Object fromString(String str) {
/* 42 */     return this.editor.setAsText(str);
/*    */   }
/*    */ 
/*    */   public String toString(Object obj) {
/* 46 */     return this.editor.getAsText(obj);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.extended.PropertyEditorCapableConverter
 * JD-Core Version:    0.6.0
 */