/*    */ package com.thoughtworks.xstream.converters.extended;
/*    */ 
/*    */ import com.thoughtworks.xstream.converters.basic.AbstractSingleValueConverter;
/*    */ import java.nio.charset.Charset;
/*    */ 
/*    */ public class CharsetConverter extends AbstractSingleValueConverter
/*    */ {
/*    */   public boolean canConvert(Class type)
/*    */   {
/* 26 */     return Charset.class.isAssignableFrom(type);
/*    */   }
/*    */ 
/*    */   public String toString(Object obj) {
/* 30 */     return obj == null ? null : ((Charset)obj).name();
/*    */   }
/*    */ 
/*    */   public Object fromString(String str)
/*    */   {
/* 35 */     return Charset.forName(str);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.extended.CharsetConverter
 * JD-Core Version:    0.6.0
 */