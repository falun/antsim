/*    */ package com.thoughtworks.xstream.converters.extended;
/*    */ 
/*    */ import com.thoughtworks.xstream.converters.basic.AbstractSingleValueConverter;
/*    */ import java.io.File;
/*    */ 
/*    */ public class FileConverter extends AbstractSingleValueConverter
/*    */ {
/*    */   public boolean canConvert(Class type)
/*    */   {
/* 27 */     return type.equals(File.class);
/*    */   }
/*    */ 
/*    */   public Object fromString(String str) {
/* 31 */     return new File(str);
/*    */   }
/*    */ 
/*    */   public String toString(Object obj) {
/* 35 */     return ((File)obj).getPath();
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.extended.FileConverter
 * JD-Core Version:    0.6.0
 */