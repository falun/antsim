/*    */ package com.thoughtworks.xstream.converters.extended;
/*    */ 
/*    */ import com.thoughtworks.xstream.converters.reflection.AbstractAttributedCharacterIteratorAttributeConverter;
/*    */ import java.awt.font.TextAttribute;
/*    */ 
/*    */ public class TextAttributeConverter extends AbstractAttributedCharacterIteratorAttributeConverter
/*    */ {
/*    */   public TextAttributeConverter()
/*    */   {
/* 33 */     super(TextAttribute.class);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.extended.TextAttributeConverter
 * JD-Core Version:    0.6.0
 */