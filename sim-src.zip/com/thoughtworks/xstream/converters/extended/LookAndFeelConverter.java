/*    */ package com.thoughtworks.xstream.converters.extended;
/*    */ 
/*    */ import com.thoughtworks.xstream.converters.reflection.ReflectionConverter;
/*    */ import com.thoughtworks.xstream.converters.reflection.ReflectionProvider;
/*    */ import com.thoughtworks.xstream.mapper.Mapper;
/*    */ import javax.swing.LookAndFeel;
/*    */ 
/*    */ public class LookAndFeelConverter extends ReflectionConverter
/*    */ {
/*    */   public LookAndFeelConverter(Mapper mapper, ReflectionProvider reflectionProvider)
/*    */   {
/* 40 */     super(mapper, reflectionProvider);
/*    */   }
/*    */ 
/*    */   public boolean canConvert(Class type) {
/* 44 */     return LookAndFeel.class.isAssignableFrom(type);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.extended.LookAndFeelConverter
 * JD-Core Version:    0.6.0
 */