/*    */ package com.thoughtworks.xstream.converters.extended;
/*    */ 
/*    */ import java.util.Calendar;
/*    */ import java.util.Date;
/*    */ 
/*    */ public class ISO8601DateConverter extends ISO8601GregorianCalendarConverter
/*    */ {
/*    */   public boolean canConvert(Class type)
/*    */   {
/* 28 */     return type.equals(Date.class);
/*    */   }
/*    */ 
/*    */   public Object fromString(String str) {
/* 32 */     return ((Calendar)super.fromString(str)).getTime();
/*    */   }
/*    */ 
/*    */   public String toString(Object obj) {
/* 36 */     Calendar calendar = Calendar.getInstance();
/* 37 */     calendar.setTime((Date)obj);
/* 38 */     return super.toString(calendar);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.extended.ISO8601DateConverter
 * JD-Core Version:    0.6.0
 */