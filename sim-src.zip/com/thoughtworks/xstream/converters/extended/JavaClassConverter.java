/*    */ package com.thoughtworks.xstream.converters.extended;
/*    */ 
/*    */ import com.thoughtworks.xstream.converters.ConversionException;
/*    */ import com.thoughtworks.xstream.converters.basic.AbstractSingleValueConverter;
/*    */ 
/*    */ public class JavaClassConverter extends AbstractSingleValueConverter
/*    */ {
/*    */   private ClassLoader classLoader;
/*    */ 
/*    */   /** @deprecated */
/*    */   public JavaClassConverter()
/*    */   {
/* 33 */     this(Thread.currentThread().getContextClassLoader());
/*    */   }
/*    */ 
/*    */   public JavaClassConverter(ClassLoader classLoader) {
/* 37 */     this.classLoader = classLoader;
/*    */   }
/*    */ 
/*    */   public boolean canConvert(Class clazz) {
/* 41 */     return Class.class.equals(clazz);
/*    */   }
/*    */ 
/*    */   public String toString(Object obj) {
/* 45 */     return ((Class)obj).getName();
/*    */   }
/*    */ 
/*    */   public Object fromString(String str) {
/*    */     try {
/* 50 */       return loadClass(str); } catch (ClassNotFoundException e) {
/*    */     }
/* 52 */     throw new ConversionException("Cannot load java class " + str, e);
/*    */   }
/*    */ 
/*    */   private Class loadClass(String className) throws ClassNotFoundException
/*    */   {
/* 57 */     Class resultingClass = primitiveClassForName(className);
/* 58 */     if (resultingClass != null) {
/* 59 */       return resultingClass;
/*    */     }
/*    */ 
/* 62 */     for (int dimension = 0; className.charAt(dimension) == '['; dimension++);
/* 63 */     if (dimension > 0)
/*    */     {
/*    */       ClassLoader classLoaderToUse;
/*    */       ClassLoader classLoaderToUse;
/* 65 */       if (className.charAt(dimension) == 'L') {
/* 66 */         String componentTypeName = className.substring(dimension + 1, className.length() - 1);
/* 67 */         classLoaderToUse = this.classLoader.loadClass(componentTypeName).getClassLoader();
/*    */       } else {
/* 69 */         classLoaderToUse = null;
/*    */       }
/* 71 */       return Class.forName(className, false, classLoaderToUse);
/*    */     }
/* 73 */     return this.classLoader.loadClass(className);
/*    */   }
/*    */ 
/*    */   private Class primitiveClassForName(String name)
/*    */   {
/* 80 */     return name.equals("double") ? Double.TYPE : name.equals("float") ? Float.TYPE : name.equals("long") ? Long.TYPE : name.equals("int") ? Integer.TYPE : name.equals("short") ? Short.TYPE : name.equals("char") ? Character.TYPE : name.equals("byte") ? Byte.TYPE : name.equals("boolean") ? Boolean.TYPE : name.equals("void") ? Void.TYPE : null;
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.extended.JavaClassConverter
 * JD-Core Version:    0.6.0
 */