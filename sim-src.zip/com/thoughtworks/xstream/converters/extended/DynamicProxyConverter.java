/*    */ package com.thoughtworks.xstream.converters.extended;
/*    */ 
/*    */ import com.thoughtworks.xstream.converters.ConversionException;
/*    */ import com.thoughtworks.xstream.converters.Converter;
/*    */ import com.thoughtworks.xstream.converters.MarshallingContext;
/*    */ import com.thoughtworks.xstream.converters.UnmarshallingContext;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*    */ import com.thoughtworks.xstream.mapper.DynamicProxyMapper.DynamicProxy;
/*    */ import com.thoughtworks.xstream.mapper.Mapper;
/*    */ import java.lang.reflect.InvocationHandler;
/*    */ import java.lang.reflect.Proxy;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class DynamicProxyConverter
/*    */   implements Converter
/*    */ {
/*    */   private ClassLoader classLoader;
/*    */   private Mapper mapper;
/*    */ 
/*    */   public DynamicProxyConverter(Mapper mapper)
/*    */   {
/* 40 */     this(mapper, DynamicProxyConverter.class.getClassLoader());
/*    */   }
/*    */ 
/*    */   public DynamicProxyConverter(Mapper mapper, ClassLoader classLoader) {
/* 44 */     this.classLoader = classLoader;
/* 45 */     this.mapper = mapper;
/*    */   }
/*    */ 
/*    */   public boolean canConvert(Class type) {
/* 49 */     return (type.equals(DynamicProxyMapper.DynamicProxy.class)) || (Proxy.isProxyClass(type));
/*    */   }
/*    */ 
/*    */   public void marshal(Object source, HierarchicalStreamWriter writer, MarshallingContext context) {
/* 53 */     InvocationHandler invocationHandler = Proxy.getInvocationHandler(source);
/* 54 */     addInterfacesToXml(source, writer);
/* 55 */     writer.startNode("handler");
/* 56 */     String attributeName = this.mapper.aliasForSystemAttribute("class");
/* 57 */     if (attributeName != null) {
/* 58 */       writer.addAttribute(attributeName, this.mapper.serializedClass(invocationHandler.getClass()));
/*    */     }
/* 60 */     context.convertAnother(invocationHandler);
/* 61 */     writer.endNode();
/*    */   }
/*    */ 
/*    */   private void addInterfacesToXml(Object source, HierarchicalStreamWriter writer) {
/* 65 */     Class[] interfaces = source.getClass().getInterfaces();
/* 66 */     for (int i = 0; i < interfaces.length; i++) {
/* 67 */       Class currentInterface = interfaces[i];
/* 68 */       writer.startNode("interface");
/* 69 */       writer.setValue(this.mapper.serializedClass(currentInterface));
/* 70 */       writer.endNode();
/*    */     }
/*    */   }
/*    */ 
/*    */   public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext context) {
/* 75 */     List interfaces = new ArrayList();
/* 76 */     InvocationHandler handler = null;
/* 77 */     while (reader.hasMoreChildren()) {
/* 78 */       reader.moveDown();
/* 79 */       String elementName = reader.getNodeName();
/* 80 */       if (elementName.equals("interface")) {
/* 81 */         interfaces.add(this.mapper.realClass(reader.getValue()));
/* 82 */       } else if (elementName.equals("handler")) {
/* 83 */         String attributeName = this.mapper.aliasForSystemAttribute("class");
/* 84 */         if (attributeName != null) {
/* 85 */           Class handlerType = this.mapper.realClass(reader.getAttribute(attributeName));
/* 86 */           handler = (InvocationHandler)context.convertAnother(null, handlerType);
/*    */         }
/*    */       }
/* 89 */       reader.moveUp();
/*    */     }
/* 91 */     if (handler == null) {
/* 92 */       throw new ConversionException("No InvocationHandler specified for dynamic proxy");
/*    */     }
/* 94 */     Class[] interfacesAsArray = new Class[interfaces.size()];
/* 95 */     interfaces.toArray(interfacesAsArray);
/* 96 */     return Proxy.newProxyInstance(this.classLoader, interfacesAsArray, handler);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.extended.DynamicProxyConverter
 * JD-Core Version:    0.6.0
 */