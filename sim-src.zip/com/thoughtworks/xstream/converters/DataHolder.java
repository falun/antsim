package com.thoughtworks.xstream.converters;

import java.util.Iterator;

public abstract interface DataHolder
{
  public abstract Object get(Object paramObject);

  public abstract void put(Object paramObject1, Object paramObject2);

  public abstract Iterator keys();
}

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.DataHolder
 * JD-Core Version:    0.6.0
 */