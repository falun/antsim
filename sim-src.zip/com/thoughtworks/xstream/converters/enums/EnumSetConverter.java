/*     */ package com.thoughtworks.xstream.converters.enums;
/*     */ 
/*     */ import com.thoughtworks.xstream.converters.ConversionException;
/*     */ import com.thoughtworks.xstream.converters.Converter;
/*     */ import com.thoughtworks.xstream.converters.MarshallingContext;
/*     */ import com.thoughtworks.xstream.converters.UnmarshallingContext;
/*     */ import com.thoughtworks.xstream.core.util.Fields;
/*     */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*     */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*     */ import com.thoughtworks.xstream.mapper.Mapper;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class EnumSetConverter
/*     */   implements Converter
/*     */ {
/*     */   private static final Field typeField;
/*     */   private final Mapper mapper;
/*     */ 
/*     */   public EnumSetConverter(Mapper mapper)
/*     */   {
/*  62 */     this.mapper = mapper;
/*     */   }
/*     */ 
/*     */   public boolean canConvert(Class type) {
/*  66 */     return EnumSet.class.isAssignableFrom(type);
/*     */   }
/*     */ 
/*     */   public void marshal(Object source, HierarchicalStreamWriter writer, MarshallingContext context) {
/*  70 */     EnumSet set = (EnumSet)source;
/*  71 */     Class enumTypeForSet = (Class)Fields.read(typeField, set);
/*  72 */     String attributeName = this.mapper.aliasForSystemAttribute("enum-type");
/*  73 */     if (attributeName != null) {
/*  74 */       writer.addAttribute(attributeName, this.mapper.serializedClass(enumTypeForSet));
/*     */     }
/*  76 */     writer.setValue(joinEnumValues(set));
/*     */   }
/*     */ 
/*     */   private String joinEnumValues(EnumSet set) {
/*  80 */     boolean seenFirst = false;
/*  81 */     StringBuffer result = new StringBuffer();
/*  82 */     for (Iterator iterator = set.iterator(); iterator.hasNext(); ) {
/*  83 */       Enum value = (Enum)iterator.next();
/*  84 */       if (seenFirst)
/*  85 */         result.append(',');
/*     */       else {
/*  87 */         seenFirst = true;
/*     */       }
/*  89 */       result.append(value.name());
/*     */     }
/*  91 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext context) {
/*  95 */     String attributeName = this.mapper.aliasForSystemAttribute("enum-type");
/*  96 */     if (attributeName == null) {
/*  97 */       throw new ConversionException("No EnumType specified for EnumSet");
/*     */     }
/*  99 */     Class enumTypeForSet = this.mapper.realClass(reader.getAttribute(attributeName));
/* 100 */     EnumSet set = EnumSet.noneOf(enumTypeForSet);
/* 101 */     String[] enumValues = reader.getValue().split(",");
/* 102 */     for (int i = 0; i < enumValues.length; i++) {
/* 103 */       String enumValue = enumValues[i];
/* 104 */       if (enumValue.length() > 0) {
/* 105 */         set.add(Enum.valueOf(enumTypeForSet, enumValue));
/*     */       }
/*     */     }
/* 108 */     return set;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  43 */     Field assumedTypeField = null;
/*  44 */     Field[] fields = EnumSet.class.getDeclaredFields();
/*  45 */     for (int i = 0; i < fields.length; i++) {
/*  46 */       if (fields[i].getType() != Class.class)
/*     */         continue;
/*  48 */       assumedTypeField = fields[i];
/*  49 */       assumedTypeField.setAccessible(true);
/*  50 */       break;
/*     */     }
/*     */ 
/*  53 */     if (assumedTypeField == null) {
/*  54 */       throw new ExceptionInInitializerError("Cannot detect element type of EnumSet");
/*     */     }
/*  56 */     typeField = assumedTypeField;
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.enums.EnumSetConverter
 * JD-Core Version:    0.6.0
 */