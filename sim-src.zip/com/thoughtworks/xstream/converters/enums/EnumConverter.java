/*    */ package com.thoughtworks.xstream.converters.enums;
/*    */ 
/*    */ import com.thoughtworks.xstream.converters.Converter;
/*    */ import com.thoughtworks.xstream.converters.MarshallingContext;
/*    */ import com.thoughtworks.xstream.converters.UnmarshallingContext;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*    */ 
/*    */ public class EnumConverter
/*    */   implements Converter
/*    */ {
/*    */   public boolean canConvert(Class type)
/*    */   {
/* 34 */     return (type.isEnum()) || (Enum.class.isAssignableFrom(type));
/*    */   }
/*    */ 
/*    */   public void marshal(Object source, HierarchicalStreamWriter writer, MarshallingContext context) {
/* 38 */     writer.setValue(((Enum)source).name());
/*    */   }
/*    */ 
/*    */   public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext context) {
/* 42 */     Class type = context.getRequiredType();
/*    */ 
/* 44 */     if (type.getSuperclass() != Enum.class) {
/* 45 */       type = type.getSuperclass();
/*    */     }
/* 47 */     return Enum.valueOf(type, reader.getValue());
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.enums.EnumConverter
 * JD-Core Version:    0.6.0
 */