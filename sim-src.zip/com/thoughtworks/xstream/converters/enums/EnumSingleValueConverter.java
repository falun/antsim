/*    */ package com.thoughtworks.xstream.converters.enums;
/*    */ 
/*    */ import com.thoughtworks.xstream.converters.basic.AbstractSingleValueConverter;
/*    */ 
/*    */ public class EnumSingleValueConverter extends AbstractSingleValueConverter
/*    */ {
/*    */   private final Class enumType;
/*    */ 
/*    */   public EnumSingleValueConverter(Class type)
/*    */   {
/* 28 */     if ((!Enum.class.isAssignableFrom(type)) && (type != Enum.class)) {
/* 29 */       throw new IllegalArgumentException("Converter can only handle defined enums");
/*    */     }
/* 31 */     this.enumType = type;
/*    */   }
/*    */ 
/*    */   public boolean canConvert(Class type) {
/* 35 */     return this.enumType.isAssignableFrom(type);
/*    */   }
/*    */ 
/*    */   public Object fromString(String str) {
/* 39 */     return Enum.valueOf(this.enumType, str);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.enums.EnumSingleValueConverter
 * JD-Core Version:    0.6.0
 */