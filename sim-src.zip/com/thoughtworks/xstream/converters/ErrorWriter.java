package com.thoughtworks.xstream.converters;

import java.util.Iterator;

public abstract interface ErrorWriter
{
  public abstract void add(String paramString1, String paramString2);

  public abstract String get(String paramString);

  public abstract Iterator keys();
}

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.ErrorWriter
 * JD-Core Version:    0.6.0
 */