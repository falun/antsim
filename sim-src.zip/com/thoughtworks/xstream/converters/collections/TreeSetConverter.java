/*     */ package com.thoughtworks.xstream.converters.collections;
/*     */ 
/*     */ import com.thoughtworks.xstream.converters.ConversionException;
/*     */ import com.thoughtworks.xstream.converters.MarshallingContext;
/*     */ import com.thoughtworks.xstream.converters.UnmarshallingContext;
/*     */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*     */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*     */ import com.thoughtworks.xstream.mapper.Mapper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ public class TreeSetConverter extends CollectionConverter
/*     */ {
/*     */   public TreeSetConverter(Mapper mapper)
/*     */   {
/*  41 */     super(mapper);
/*     */   }
/*     */ 
/*     */   public boolean canConvert(Class type) {
/*  45 */     return type.equals(TreeSet.class);
/*     */   }
/*     */ 
/*     */   public void marshal(Object source, HierarchicalStreamWriter writer, MarshallingContext context) {
/*  49 */     TreeSet treeSet = (TreeSet)source;
/*  50 */     Comparator comparator = treeSet.comparator();
/*  51 */     if (comparator == null) {
/*  52 */       writer.startNode("no-comparator");
/*  53 */       writer.endNode();
/*     */     } else {
/*  55 */       writer.startNode("comparator");
/*  56 */       writer.addAttribute("class", mapper().serializedClass(comparator.getClass()));
/*  57 */       context.convertAnother(comparator);
/*  58 */       writer.endNode();
/*     */     }
/*  60 */     super.marshal(source, writer, context);
/*     */   }
/*     */ 
/*     */   public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext context) {
/*  64 */     reader.moveDown();
/*     */     TreeSet result;
/*  67 */     if (reader.getNodeName().equals("comparator")) {
/*  68 */       String comparatorClass = reader.getAttribute("class");
/*  69 */       Comparator comparator = (Comparator)context.convertAnother(null, mapper().realClass(comparatorClass));
/*  70 */       SortedSet sortedSet = new PresortedSet(comparator);
/*  71 */       result = new TreeSet(comparator);
/*     */     }
/*     */     else
/*     */     {
/*     */       TreeSet result;
/*  72 */       if (reader.getNodeName().equals("no-comparator")) {
/*  73 */         SortedSet sortedSet = new PresortedSet();
/*  74 */         result = new TreeSet();
/*     */       } else {
/*  76 */         throw new ConversionException("TreeSet does not contain <comparator> element");
/*     */       }
/*     */     }
/*     */     TreeSet result;
/*     */     SortedSet sortedSet;
/*  78 */     reader.moveUp();
/*  79 */     super.populateCollection(reader, context, sortedSet);
/*  80 */     result.addAll(sortedSet);
/*  81 */     return result;
/*     */   }
/*  85 */   private static class PresortedSet implements SortedSet { private final List list = new ArrayList();
/*     */     private final Comparator comparator;
/*     */ 
/*     */     PresortedSet() {
/*  89 */       this(null);
/*     */     }
/*     */ 
/*     */     PresortedSet(Comparator comparator) {
/*  93 */       this.comparator = comparator;
/*     */     }
/*     */ 
/*     */     public boolean add(Object e) {
/*  97 */       return this.list.add(e);
/*     */     }
/*     */ 
/*     */     public boolean addAll(Collection c) {
/* 101 */       return this.list.addAll(c);
/*     */     }
/*     */ 
/*     */     public void clear() {
/* 105 */       this.list.clear();
/*     */     }
/*     */ 
/*     */     public boolean contains(Object o) {
/* 109 */       return this.list.contains(o);
/*     */     }
/*     */ 
/*     */     public boolean containsAll(Collection c) {
/* 113 */       return this.list.containsAll(c);
/*     */     }
/*     */ 
/*     */     public boolean equals(Object o) {
/* 117 */       return this.list.equals(o);
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 121 */       return this.list.hashCode();
/*     */     }
/*     */ 
/*     */     public boolean isEmpty() {
/* 125 */       return this.list.isEmpty();
/*     */     }
/*     */ 
/*     */     public Iterator iterator() {
/* 129 */       return this.list.iterator();
/*     */     }
/*     */ 
/*     */     public boolean remove(Object o) {
/* 133 */       return this.list.remove(o);
/*     */     }
/*     */ 
/*     */     public boolean removeAll(Collection c) {
/* 137 */       return this.list.removeAll(c);
/*     */     }
/*     */ 
/*     */     public boolean retainAll(Collection c) {
/* 141 */       return this.list.retainAll(c);
/*     */     }
/*     */ 
/*     */     public int size() {
/* 145 */       return this.list.size();
/*     */     }
/*     */ 
/*     */     public List subList(int fromIndex, int toIndex) {
/* 149 */       return this.list.subList(fromIndex, toIndex);
/*     */     }
/*     */ 
/*     */     public Object[] toArray() {
/* 153 */       return this.list.toArray();
/*     */     }
/*     */ 
/*     */     public Object[] toArray(Object[] a) {
/* 157 */       return this.list.toArray(a);
/*     */     }
/*     */ 
/*     */     public Comparator comparator() {
/* 161 */       return this.comparator;
/*     */     }
/*     */ 
/*     */     public Object first() {
/* 165 */       return this.list.isEmpty() ? null : this.list.get(0);
/*     */     }
/*     */ 
/*     */     public SortedSet headSet(Object toElement) {
/* 169 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public Object last() {
/* 173 */       return this.list.isEmpty() ? null : this.list.get(this.list.size() - 1);
/*     */     }
/*     */ 
/*     */     public SortedSet subSet(Object fromElement, Object toElement) {
/* 177 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public SortedSet tailSet(Object fromElement) {
/* 181 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.collections.TreeSetConverter
 * JD-Core Version:    0.6.0
 */