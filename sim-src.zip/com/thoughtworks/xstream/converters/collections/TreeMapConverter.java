/*     */ package com.thoughtworks.xstream.converters.collections;
/*     */ 
/*     */ import com.thoughtworks.xstream.converters.ConversionException;
/*     */ import com.thoughtworks.xstream.converters.MarshallingContext;
/*     */ import com.thoughtworks.xstream.converters.UnmarshallingContext;
/*     */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*     */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*     */ import com.thoughtworks.xstream.mapper.Mapper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ public class TreeMapConverter extends MapConverter
/*     */ {
/*     */   public TreeMapConverter(Mapper mapper)
/*     */   {
/*  42 */     super(mapper);
/*     */   }
/*     */ 
/*     */   public boolean canConvert(Class type) {
/*  46 */     return type.equals(TreeMap.class);
/*     */   }
/*     */ 
/*     */   public void marshal(Object source, HierarchicalStreamWriter writer, MarshallingContext context) {
/*  50 */     TreeMap treeMap = (TreeMap)source;
/*  51 */     Comparator comparator = treeMap.comparator();
/*  52 */     if (comparator == null) {
/*  53 */       writer.startNode("no-comparator");
/*  54 */       writer.endNode();
/*     */     } else {
/*  56 */       writer.startNode("comparator");
/*  57 */       writer.addAttribute("class", mapper().serializedClass(comparator.getClass()));
/*  58 */       context.convertAnother(comparator);
/*  59 */       writer.endNode();
/*     */     }
/*  61 */     super.marshal(source, writer, context);
/*     */   }
/*     */ 
/*     */   public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext context) {
/*  65 */     reader.moveDown();
/*     */     TreeMap result;
/*  68 */     if (reader.getNodeName().equals("comparator")) {
/*  69 */       String comparatorClass = reader.getAttribute("class");
/*  70 */       Comparator comparator = (Comparator)context.convertAnother(null, mapper().realClass(comparatorClass));
/*  71 */       SortedMap sortedMap = new PresortedMap(comparator);
/*  72 */       result = new TreeMap(comparator);
/*     */     }
/*     */     else
/*     */     {
/*     */       TreeMap result;
/*  73 */       if (reader.getNodeName().equals("no-comparator")) {
/*  74 */         SortedMap sortedMap = new PresortedMap();
/*  75 */         result = new TreeMap();
/*     */       } else {
/*  77 */         throw new ConversionException("TreeMap does not contain <comparator> element");
/*     */       }
/*     */     }
/*     */     TreeMap result;
/*     */     SortedMap sortedMap;
/*  79 */     reader.moveUp();
/*  80 */     super.populateMap(reader, context, sortedMap);
/*  81 */     result.putAll(sortedMap);
/*  82 */     return result;
/*     */   }
/*     */ 
/*     */   private static class PresortedMap implements SortedMap {
/*  90 */     private final ArraySet set = new ArraySet(null);
/*     */     private final Comparator comparator;
/*     */ 
/*     */     PresortedMap() {
/*  94 */       this(null);
/*     */     }
/*     */ 
/*     */     PresortedMap(Comparator comparator) {
/*  98 */       this.comparator = comparator;
/*     */     }
/*     */ 
/*     */     public Comparator comparator() {
/* 102 */       return this.comparator;
/*     */     }
/*     */ 
/*     */     public Set entrySet() {
/* 106 */       return this.set;
/*     */     }
/*     */ 
/*     */     public Object firstKey() {
/* 110 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public SortedMap headMap(Object toKey) {
/* 114 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public Set keySet() {
/* 118 */       Set keySet = new ArraySet(null);
/* 119 */       for (Iterator iterator = this.set.iterator(); iterator.hasNext(); ) {
/* 120 */         Map.Entry entry = (Map.Entry)iterator.next();
/* 121 */         keySet.add(entry.getKey());
/*     */       }
/* 123 */       return keySet;
/*     */     }
/*     */ 
/*     */     public Object lastKey() {
/* 127 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public SortedMap subMap(Object fromKey, Object toKey) {
/* 131 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public SortedMap tailMap(Object fromKey) {
/* 135 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public Collection values() {
/* 139 */       Set values = new ArraySet(null);
/* 140 */       for (Iterator iterator = this.set.iterator(); iterator.hasNext(); ) {
/* 141 */         Map.Entry entry = (Map.Entry)iterator.next();
/* 142 */         values.add(entry.getValue());
/*     */       }
/* 144 */       return values;
/*     */     }
/*     */ 
/*     */     public void clear() {
/* 148 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public boolean containsKey(Object key) {
/* 152 */       return false;
/*     */     }
/*     */ 
/*     */     public boolean containsValue(Object value) {
/* 156 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public Object get(Object key) {
/* 160 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public boolean isEmpty() {
/* 164 */       return this.set.isEmpty();
/*     */     }
/*     */ 
/*     */     public Object put(Object key, Object value) {
/* 168 */       this.set.add(new Map.Entry(key, value) { private final Object val$key;
/*     */         private final Object val$value;
/*     */ 
/* 171 */         public Object getKey() { return this.val$key; }
/*     */ 
/*     */         public Object getValue()
/*     */         {
/* 175 */           return this.val$value;
/*     */         }
/*     */ 
/*     */         public Object setValue(Object value) {
/* 179 */           throw new UnsupportedOperationException();
/*     */         }
/*     */       });
/* 181 */       return null;
/*     */     }
/*     */ 
/*     */     public void putAll(Map m) {
/* 185 */       for (Iterator iter = m.entrySet().iterator(); iter.hasNext(); )
/* 186 */         this.set.add(iter.next());
/*     */     }
/*     */ 
/*     */     public Object remove(Object key)
/*     */     {
/* 191 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public int size() {
/* 195 */       return this.set.size();
/*     */     }
/*     */ 
/*     */     private static class ArraySet extends ArrayList
/*     */       implements Set
/*     */     {
/*     */       private ArraySet()
/*     */       {
/*     */       }
/*     */ 
/*     */       ArraySet(TreeMapConverter.1 x0)
/*     */       {
/*  87 */         this();
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.collections.TreeMapConverter
 * JD-Core Version:    0.6.0
 */