/*    */ package com.thoughtworks.xstream.converters.collections;
/*    */ 
/*    */ import com.thoughtworks.xstream.converters.Converter;
/*    */ import com.thoughtworks.xstream.converters.MarshallingContext;
/*    */ import com.thoughtworks.xstream.converters.UnmarshallingContext;
/*    */ import com.thoughtworks.xstream.core.util.Fields;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*    */ import java.lang.reflect.Field;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Properties;
/*    */ import java.util.Set;
/*    */ import java.util.TreeMap;
/*    */ 
/*    */ public class PropertiesConverter
/*    */   implements Converter
/*    */ {
/*    */   private static final Field defaultsField;
/*    */   private final boolean sort;
/*    */ 
/*    */   public PropertiesConverter()
/*    */   {
/* 52 */     this(false);
/*    */   }
/*    */ 
/*    */   public PropertiesConverter(boolean sort) {
/* 56 */     this.sort = sort;
/*    */   }
/*    */ 
/*    */   public boolean canConvert(Class type) {
/* 60 */     return Properties.class == type;
/*    */   }
/*    */ 
/*    */   public void marshal(Object source, HierarchicalStreamWriter writer, MarshallingContext context) {
/* 64 */     Properties properties = (Properties)source;
/* 65 */     Map map = this.sort ? new TreeMap(properties) : properties;
/* 66 */     for (Iterator iterator = map.entrySet().iterator(); iterator.hasNext(); ) {
/* 67 */       Map.Entry entry = (Map.Entry)iterator.next();
/* 68 */       writer.startNode("property");
/* 69 */       writer.addAttribute("name", entry.getKey().toString());
/* 70 */       writer.addAttribute("value", entry.getValue().toString());
/* 71 */       writer.endNode();
/*    */     }
/* 73 */     Properties defaults = (Properties)Fields.read(defaultsField, properties);
/* 74 */     if (defaults != null) {
/* 75 */       writer.startNode("defaults");
/* 76 */       marshal(defaults, writer, context);
/* 77 */       writer.endNode();
/*    */     }
/*    */   }
/*    */ 
/*    */   public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext context) {
/* 82 */     Properties properties = new Properties();
/* 83 */     while (reader.hasMoreChildren()) {
/* 84 */       reader.moveDown();
/* 85 */       if (reader.getNodeName().equals("defaults")) {
/* 86 */         Properties defaults = (Properties)unmarshal(reader, context);
/* 87 */         Fields.write(defaultsField, properties, defaults);
/*    */       } else {
/* 89 */         String name = reader.getAttribute("name");
/* 90 */         String value = reader.getAttribute("value");
/* 91 */         properties.setProperty(name, value);
/*    */       }
/* 93 */       reader.moveUp();
/*    */     }
/* 95 */     return properties;
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 44 */       defaultsField = Fields.find(Properties.class, "defaults");
/*    */     } catch (RuntimeException ex) {
/* 46 */       throw new ExceptionInInitializerError("Cannot access defaults field of Properties");
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.collections.PropertiesConverter
 * JD-Core Version:    0.6.0
 */