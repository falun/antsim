/*    */ package com.thoughtworks.xstream.converters.basic;
/*    */ 
/*    */ import java.text.ParseException;
/*    */ import java.util.Date;
/*    */ 
/*    */ /** @deprecated */
/*    */ public class ThreadSafeSimpleDateFormat extends com.thoughtworks.xstream.core.util.ThreadSafeSimpleDateFormat
/*    */ {
/*    */   public ThreadSafeSimpleDateFormat(String format, int initialPoolSize, int maxPoolSize)
/*    */   {
/* 28 */     super(format, initialPoolSize, maxPoolSize, true);
/*    */   }
/*    */ 
/*    */   public String format(Date date) {
/* 32 */     return super.format(date);
/*    */   }
/*    */ 
/*    */   public Date parse(String date) throws ParseException {
/* 36 */     return super.parse(date);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.basic.ThreadSafeSimpleDateFormat
 * JD-Core Version:    0.6.0
 */