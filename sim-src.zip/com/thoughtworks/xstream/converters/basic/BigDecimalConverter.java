/*    */ package com.thoughtworks.xstream.converters.basic;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ 
/*    */ public class BigDecimalConverter extends AbstractSingleValueConverter
/*    */ {
/*    */   public boolean canConvert(Class type)
/*    */   {
/* 25 */     return type.equals(BigDecimal.class);
/*    */   }
/*    */ 
/*    */   public Object fromString(String str) {
/* 29 */     return new BigDecimal(str);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.basic.BigDecimalConverter
 * JD-Core Version:    0.6.0
 */