/*    */ package com.thoughtworks.xstream.converters.basic;
/*    */ 
/*    */ public class LongConverter extends AbstractSingleValueConverter
/*    */ {
/*    */   public boolean canConvert(Class type)
/*    */   {
/* 23 */     return (type.equals(Long.TYPE)) || (type.equals(Long.class));
/*    */   }
/*    */ 
/*    */   public Object fromString(String str) {
/* 27 */     return Long.decode(str);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.basic.LongConverter
 * JD-Core Version:    0.6.0
 */