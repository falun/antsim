/*    */ package com.thoughtworks.xstream.converters.basic;
/*    */ 
/*    */ public class IntConverter extends AbstractSingleValueConverter
/*    */ {
/*    */   public boolean canConvert(Class type)
/*    */   {
/* 23 */     return (type.equals(Integer.TYPE)) || (type.equals(Integer.class));
/*    */   }
/*    */ 
/*    */   public Object fromString(String str) {
/* 27 */     long value = Long.decode(str).longValue();
/* 28 */     if ((value < -2147483648L) || (value > 4294967295L)) {
/* 29 */       throw new NumberFormatException("For input string: \"" + str + '"');
/*    */     }
/* 31 */     return new Integer((int)value);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.basic.IntConverter
 * JD-Core Version:    0.6.0
 */