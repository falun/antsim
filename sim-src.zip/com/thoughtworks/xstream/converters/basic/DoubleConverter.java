/*    */ package com.thoughtworks.xstream.converters.basic;
/*    */ 
/*    */ public class DoubleConverter extends AbstractSingleValueConverter
/*    */ {
/*    */   public boolean canConvert(Class type)
/*    */   {
/* 23 */     return (type.equals(Double.TYPE)) || (type.equals(Double.class));
/*    */   }
/*    */ 
/*    */   public Object fromString(String str) {
/* 27 */     return Double.valueOf(str);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.basic.DoubleConverter
 * JD-Core Version:    0.6.0
 */