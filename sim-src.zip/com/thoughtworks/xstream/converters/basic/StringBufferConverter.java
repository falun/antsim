/*    */ package com.thoughtworks.xstream.converters.basic;
/*    */ 
/*    */ public class StringBufferConverter extends AbstractSingleValueConverter
/*    */ {
/*    */   public Object fromString(String str)
/*    */   {
/* 22 */     return new StringBuffer(str);
/*    */   }
/*    */ 
/*    */   public boolean canConvert(Class type) {
/* 26 */     return type.equals(StringBuffer.class);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.basic.StringBufferConverter
 * JD-Core Version:    0.6.0
 */