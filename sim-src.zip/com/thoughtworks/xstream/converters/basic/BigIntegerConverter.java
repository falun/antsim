/*    */ package com.thoughtworks.xstream.converters.basic;
/*    */ 
/*    */ import java.math.BigInteger;
/*    */ 
/*    */ public class BigIntegerConverter extends AbstractSingleValueConverter
/*    */ {
/*    */   public boolean canConvert(Class type)
/*    */   {
/* 24 */     return type.equals(BigInteger.class);
/*    */   }
/*    */ 
/*    */   public Object fromString(String str) {
/* 28 */     return new BigInteger(str);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.basic.BigIntegerConverter
 * JD-Core Version:    0.6.0
 */