/*    */ package com.thoughtworks.xstream.converters.basic;
/*    */ 
/*    */ public class ByteConverter extends AbstractSingleValueConverter
/*    */ {
/*    */   public boolean canConvert(Class type)
/*    */   {
/* 23 */     return (type.equals(Byte.TYPE)) || (type.equals(Byte.class));
/*    */   }
/*    */ 
/*    */   public Object fromString(String str) {
/* 27 */     int value = Integer.decode(str).intValue();
/* 28 */     if ((value < -128) || (value > 255)) {
/* 29 */       throw new NumberFormatException("For input string: \"" + str + '"');
/*    */     }
/* 31 */     return new Byte((byte)value);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.basic.ByteConverter
 * JD-Core Version:    0.6.0
 */