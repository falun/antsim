/*    */ package com.thoughtworks.xstream.converters.basic;
/*    */ 
/*    */ public class StringBuilderConverter extends AbstractSingleValueConverter
/*    */ {
/*    */   public Object fromString(String str)
/*    */   {
/* 21 */     return new StringBuilder(str);
/*    */   }
/*    */ 
/*    */   public boolean canConvert(Class type) {
/* 25 */     return type.equals(StringBuilder.class);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.basic.StringBuilderConverter
 * JD-Core Version:    0.6.0
 */