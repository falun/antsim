/*    */ package com.thoughtworks.xstream.converters.basic;
/*    */ 
/*    */ public class FloatConverter extends AbstractSingleValueConverter
/*    */ {
/*    */   public boolean canConvert(Class type)
/*    */   {
/* 23 */     return (type.equals(Float.TYPE)) || (type.equals(Float.class));
/*    */   }
/*    */ 
/*    */   public Object fromString(String str) {
/* 27 */     return Float.valueOf(str);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.basic.FloatConverter
 * JD-Core Version:    0.6.0
 */