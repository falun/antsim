/*    */ package com.thoughtworks.xstream.converters.basic;
/*    */ 
/*    */ import com.thoughtworks.xstream.converters.ConversionException;
/*    */ import java.net.MalformedURLException;
/*    */ import java.net.URL;
/*    */ 
/*    */ public class URLConverter extends AbstractSingleValueConverter
/*    */ {
/*    */   public boolean canConvert(Class type)
/*    */   {
/* 27 */     return type.equals(URL.class);
/*    */   }
/*    */ 
/*    */   public Object fromString(String str) {
/*    */     try {
/* 32 */       return new URL(str); } catch (MalformedURLException e) {
/*    */     }
/* 34 */     throw new ConversionException(e);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.basic.URLConverter
 * JD-Core Version:    0.6.0
 */