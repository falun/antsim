/*    */ package com.thoughtworks.xstream.converters.basic;
/*    */ 
/*    */ import com.thoughtworks.xstream.converters.ConversionException;
/*    */ import java.util.UUID;
/*    */ 
/*    */ public class UUIDConverter extends AbstractSingleValueConverter
/*    */ {
/*    */   public boolean canConvert(Class type)
/*    */   {
/* 26 */     return type.equals(UUID.class);
/*    */   }
/*    */ 
/*    */   public Object fromString(String str) {
/*    */     try {
/* 31 */       return UUID.fromString(str); } catch (IllegalArgumentException e) {
/*    */     }
/* 33 */     throw new ConversionException("Cannot create UUID instance", e);
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.basic.UUIDConverter
 * JD-Core Version:    0.6.0
 */