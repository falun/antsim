/*    */ package com.thoughtworks.xstream.converters.basic;
/*    */ 
/*    */ import com.thoughtworks.xstream.converters.Converter;
/*    */ import com.thoughtworks.xstream.converters.MarshallingContext;
/*    */ import com.thoughtworks.xstream.converters.UnmarshallingContext;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*    */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*    */ 
/*    */ /** @deprecated */
/*    */ public abstract class AbstractBasicConverter
/*    */   implements Converter
/*    */ {
/*    */   protected abstract Object fromString(String paramString);
/*    */ 
/*    */   public abstract boolean canConvert(Class paramClass);
/*    */ 
/*    */   protected String toString(Object obj)
/*    */   {
/* 37 */     return obj.toString();
/*    */   }
/*    */ 
/*    */   public void marshal(Object source, HierarchicalStreamWriter writer, MarshallingContext context) {
/* 41 */     writer.setValue(toString(source));
/*    */   }
/*    */ 
/*    */   public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext context) {
/* 45 */     return fromString(reader.getValue());
/*    */   }
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.basic.AbstractBasicConverter
 * JD-Core Version:    0.6.0
 */