/*    */ package com.thoughtworks.xstream.converters.basic;
/*    */ 
/*    */ import com.thoughtworks.xstream.converters.SingleValueConverter;
/*    */ 
/*    */ public abstract class AbstractSingleValueConverter
/*    */   implements SingleValueConverter
/*    */ {
/*    */   public abstract boolean canConvert(Class paramClass);
/*    */ 
/*    */   public String toString(Object obj)
/*    */   {
/* 30 */     return obj == null ? null : obj.toString();
/*    */   }
/*    */ 
/*    */   public abstract Object fromString(String paramString);
/*    */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.basic.AbstractSingleValueConverter
 * JD-Core Version:    0.6.0
 */