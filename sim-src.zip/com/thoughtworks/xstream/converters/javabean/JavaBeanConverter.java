/*     */ package com.thoughtworks.xstream.converters.javabean;
/*     */ 
/*     */ import com.thoughtworks.xstream.alias.ClassMapper;
/*     */ import com.thoughtworks.xstream.converters.ConversionException;
/*     */ import com.thoughtworks.xstream.converters.Converter;
/*     */ import com.thoughtworks.xstream.converters.MarshallingContext;
/*     */ import com.thoughtworks.xstream.converters.UnmarshallingContext;
/*     */ import com.thoughtworks.xstream.io.ExtendedHierarchicalStreamWriterHelper;
/*     */ import com.thoughtworks.xstream.io.HierarchicalStreamReader;
/*     */ import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
/*     */ import com.thoughtworks.xstream.mapper.Mapper;
/*     */ 
/*     */ public class JavaBeanConverter
/*     */   implements Converter
/*     */ {
/*     */   private Mapper mapper;
/*     */   private BeanProvider beanProvider;
/*     */ 
/*     */   /** @deprecated */
/*     */   private String classAttributeIdentifier;
/*     */ 
/*     */   public JavaBeanConverter(Mapper mapper)
/*     */   {
/*  43 */     this(mapper, new BeanProvider());
/*     */   }
/*     */ 
/*     */   public JavaBeanConverter(Mapper mapper, BeanProvider beanProvider) {
/*  47 */     this.mapper = mapper;
/*  48 */     this.beanProvider = beanProvider;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public JavaBeanConverter(Mapper mapper, String classAttributeIdentifier)
/*     */   {
/*  55 */     this(mapper, new BeanProvider());
/*  56 */     this.classAttributeIdentifier = classAttributeIdentifier;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public JavaBeanConverter(ClassMapper classMapper, String classAttributeIdentifier)
/*     */   {
/*  63 */     this(classMapper, classAttributeIdentifier);
/*     */   }
/*     */ 
/*     */   public boolean canConvert(Class type)
/*     */   {
/*  71 */     return this.beanProvider.canInstantiate(type);
/*     */   }
/*     */ 
/*     */   public void marshal(Object source, HierarchicalStreamWriter writer, MarshallingContext context) {
/*  75 */     String classAttributeName = this.classAttributeIdentifier != null ? this.classAttributeIdentifier : this.mapper.aliasForSystemAttribute("class");
/*  76 */     this.beanProvider.visitSerializableProperties(source, new BeanProvider.Visitor(source, writer, classAttributeName, context) { private final Object val$source;
/*     */       private final HierarchicalStreamWriter val$writer;
/*     */       private final String val$classAttributeName;
/*     */       private final MarshallingContext val$context;
/*     */ 
/*  78 */       public boolean shouldVisit(String name, Class definedIn) { return JavaBeanConverter.this.mapper.shouldSerializeMember(definedIn, name); }
/*     */ 
/*     */       public void visit(String propertyName, Class fieldType, Class definedIn, Object newObj)
/*     */       {
/*  82 */         if (newObj != null)
/*  83 */           writeField(propertyName, fieldType, newObj, definedIn);
/*     */       }
/*     */ 
/*     */       private void writeField(String propertyName, Class fieldType, Object newObj, Class definedIn)
/*     */       {
/*  88 */         String serializedMember = JavaBeanConverter.this.mapper.serializedMember(this.val$source.getClass(), propertyName);
/*  89 */         ExtendedHierarchicalStreamWriterHelper.startNode(this.val$writer, serializedMember, fieldType);
/*  90 */         Class actualType = newObj.getClass();
/*  91 */         Class defaultType = JavaBeanConverter.this.mapper.defaultImplementationOf(fieldType);
/*  92 */         if ((!actualType.equals(defaultType)) && (this.val$classAttributeName != null)) {
/*  93 */           this.val$writer.addAttribute(this.val$classAttributeName, JavaBeanConverter.this.mapper.serializedClass(actualType));
/*     */         }
/*  95 */         this.val$context.convertAnother(newObj);
/*     */ 
/*  97 */         this.val$writer.endNode();
/*     */       } } );
/*     */   }
/*     */ 
/*     */   public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext context) {
/* 103 */     Object result = instantiateNewInstance(context);
/*     */ 
/* 105 */     while (reader.hasMoreChildren()) {
/* 106 */       reader.moveDown();
/*     */ 
/* 108 */       String propertyName = this.mapper.realMember(result.getClass(), reader.getNodeName());
/*     */ 
/* 110 */       boolean propertyExistsInClass = this.beanProvider.propertyDefinedInClass(propertyName, result.getClass());
/*     */ 
/* 112 */       if (propertyExistsInClass) {
/* 113 */         Class type = determineType(reader, result, propertyName);
/* 114 */         Object value = context.convertAnother(result, type);
/* 115 */         this.beanProvider.writeProperty(result, propertyName, value);
/* 116 */       } else if (this.mapper.shouldSerializeMember(result.getClass(), propertyName)) {
/* 117 */         throw new ConversionException("Property '" + propertyName + "' not defined in class " + result.getClass().getName());
/*     */       }
/*     */ 
/* 120 */       reader.moveUp();
/*     */     }
/*     */ 
/* 123 */     return result;
/*     */   }
/*     */ 
/*     */   private Object instantiateNewInstance(UnmarshallingContext context) {
/* 127 */     Object result = context.currentObject();
/* 128 */     if (result == null) {
/* 129 */       result = this.beanProvider.newInstance(context.getRequiredType());
/*     */     }
/* 131 */     return result;
/*     */   }
/*     */ 
/*     */   private Class determineType(HierarchicalStreamReader reader, Object result, String fieldName) {
/* 135 */     String classAttributeName = this.classAttributeIdentifier != null ? this.classAttributeIdentifier : this.mapper.aliasForSystemAttribute("class");
/* 136 */     String classAttribute = classAttributeName == null ? null : reader.getAttribute(classAttributeName);
/* 137 */     if (classAttribute != null) {
/* 138 */       return this.mapper.realClass(classAttribute);
/*     */     }
/* 140 */     return this.mapper.defaultImplementationOf(this.beanProvider.getPropertyType(result, fieldName));
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public static class DuplicateFieldException extends ConversionException
/*     */   {
/*     */     public DuplicateFieldException(String msg)
/*     */     {
/* 149 */       super();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.javabean.JavaBeanConverter
 * JD-Core Version:    0.6.0
 */