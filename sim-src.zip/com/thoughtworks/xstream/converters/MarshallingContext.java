package com.thoughtworks.xstream.converters;

public abstract interface MarshallingContext extends DataHolder
{
  public abstract void convertAnother(Object paramObject);

  public abstract void convertAnother(Object paramObject, Converter paramConverter);
}

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.MarshallingContext
 * JD-Core Version:    0.6.0
 */