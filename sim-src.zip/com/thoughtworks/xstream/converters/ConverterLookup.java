package com.thoughtworks.xstream.converters;

public abstract interface ConverterLookup
{
  public abstract Converter lookupConverterForType(Class paramClass);
}

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.ConverterLookup
 * JD-Core Version:    0.6.0
 */