package com.thoughtworks.xstream.converters;

public abstract interface ConverterMatcher
{
  public abstract boolean canConvert(Class paramClass);
}

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     com.thoughtworks.xstream.converters.ConverterMatcher
 * JD-Core Version:    0.6.0
 */