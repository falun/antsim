package net.miginfocom.layout;

public abstract class UnitConverter
{
  public static final int UNABLE = -87654312;

  public abstract int convertToPixels(float paramFloat1, String paramString, boolean paramBoolean, float paramFloat2, ContainerWrapper paramContainerWrapper, ComponentWrapper paramComponentWrapper);
}

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     net.miginfocom.layout.UnitConverter
 * JD-Core Version:    0.6.0
 */