package net.miginfocom.layout;

public abstract interface InCellGapProvider
{
  public abstract BoundSize getDefaultGap(ComponentWrapper paramComponentWrapper1, ComponentWrapper paramComponentWrapper2, int paramInt, String paramString, boolean paramBoolean);
}

/* Location:           C:\Users\Richard\Projects\Ants\sim-src\
 * Qualified Name:     net.miginfocom.layout.InCellGapProvider
 * JD-Core Version:    0.6.0
 */